# SMCM — Student Medical & Counselling Management System
## Project Guide for Product Managers

**Version:** 3.0  
**Stack:** React 19 + Vite (frontend) · Express 4 (API backend) · SQL Server 2019  
**Ports:** Frontend → `http://localhost:5174` · API → `http://localhost:3000`  
**DB:** `Health_Centre_Master` on SQL Server at `localhost:60471`

---

## How to Run

```
cd C:\SMCM
npm run dev          # starts both API server + frontend together
```

Or separately:
```
npm run server       # just the API (port 3000)
npm run client       # just the frontend (port 5174)
```

---

## Project Folder Map

```
C:\SMCM\
│
├── server\                   ← BACKEND (Node/Express API)
│   ├── index.js              ← ALL API routes (single file, ~900 lines)
│   ├── db.js                 ← SQL Server connection pool + query helpers
│   ├── middleware.js         ← Auth checks (requireAdmin, requirePermission)
│   ├── triage.js             ← Automated intake routing engine
│   ├── notify.js             ← In-app notification dispatcher
│   ├── config.js             ← (Legacy config, superseded by db.js hardcoded values)
│   ├── schema.sql            ← Full database schema (all CREATE TABLE statements)
│   ├── seed.sql              ← Sample/demo data for all tables
│   ├── setup-mssql.js        ← One-time DB setup script (run once to create tables)
│   └── setup.js              ← (Legacy SQLite setup, now unused)
│
├── src\                      ← FRONTEND (React)
│   │
│   ├── main.jsx              ← App entry point (mounts React into index.html)
│   ├── App.jsx               ← Router: maps URLs → page components
│   ├── index.css             ← Global CSS resets
│   │
│   ├── context\
│   │   └── AppContext.jsx    ← Global state: logged-in user, apiFetch(), toast()
│   │                           (Every page imports this to call the API)
│   │
│   ├── components\common\
│   │   ├── Toast.jsx         ← Success/error notification popups
│   │   ├── Modal.jsx         ← Reusable modal dialog wrapper
│   │   ├── StatusPill.jsx    ← Coloured status badge (e.g. "Pending", "Active")
│   │   └── Icons.jsx         ← SVG icon set
│   │
│   ├── utils\
│   │   └── urgency.js        ← Maps urgency levels (1-4) to colours/labels
│   │
│   ├── data\
│   │   └── mockData.js       ← Static fallback data (used only if API is down)
│   │
│   └── pages\
│       │
│       ├── auth\
│       │   └── Login.jsx     ← Login screen (email + password → JWT-less session)
│       │
│       ├── admin\            ← ADMIN PORTAL pages (staff/doctor view)
│       │   │
│       │   ├── AdminLayout.jsx          ← Sidebar + topbar shell wrapping all admin pages
│       │   ├── Dashboard.jsx            ← KPI cards, live queue, pending certs & concerns
│       │   ├── TodaysQueue.jsx          ← Today's appointment queue with status management
│       │   ├── Queue.jsx                ← Extended queue view (all statuses)
│       │   ├── Appointments.jsx         ← Full appointments list + create/cancel
│       │   ├── WalkIn.jsx               ← Register walk-in patients, issue token numbers
│       │   ├── Cases.jsx                ← Care case management (triage → crisis resolution)
│       │   ├── Consultation.jsx         ← Record consultation notes, diagnosis, prescriptions
│       │   ├── Records.jsx              ← View/add student health records
│       │   ├── AdminCertificates.jsx    ← Review & approve/reject certificate requests
│       │   ├── Referrals.jsx            ← Manage external/internal referrals
│       │   ├── Counselling.jsx          ← Counselling case list + session tracking
│       │   ├── CounsellingSetup.jsx     ← Configure counselling session templates
│       │   ├── AdminRaiseConcern.jsx    ← Admin view of student-raised concerns
│       │   ├── Compliance.jsx           ← Analytics & compliance reports (charts)
│       │   ├── AdminUsers.jsx           ← Manage admin/staff accounts & permissions
│       │   │
│       │   └── Config pages (System Configuration section):
│       │       ├── Config.jsx           ← Configuration hub (links to all master-data editors)
│       │       ├── HealthCentres.jsx    ← Add/edit health centre locations
│       │       ├── HCDetail.jsx         ← Health centre detail / provider assignments
│       │       ├── HealthCentreDetail.jsx  ← (Alternate detail view)
│       │       ├── MasterEditor.jsx     ← Generic CRUD editor for master tables
│       │       ├── CertTypes.jsx        ← Certificate type definitions
│       │       ├── ConcernTypes.jsx     ← Concern category definitions
│       │       └── ReferralDestinations.jsx  ← External referral destinations
│       │
│       └── student\          ← STUDENT PORTAL pages (student self-service)
│           ├── StudentLayout.jsx        ← Student portal nav shell
│           ├── StudentDashboard.jsx     ← Student home: upcoming appts, records, quick actions
│           ├── GetHelp.jsx              ← Guided intake flow (symptom → triage → booking)
│           ├── BookAppointment.jsx      ← Book a new appointment
│           ├── MyAppointments.jsx       ← View/cancel own appointments
│           ├── MyRecords.jsx            ← View own health records
│           ├── MyCertificates.jsx       ← Request & track certificates
│           ├── MyCases.jsx              ← View own care cases
│           ├── CounsellingPortal.jsx    ← Book / track counselling sessions
│           ├── RaiseConcern.jsx         ← Submit anonymous or named concern
│           └── CrisisScreen.jsx        ← Crisis support landing (24/7 resources)
│
├── index.html                ← HTML shell (React mounts here)
├── vite.config.js            ← Vite bundler config
├── package.json              ← Dependencies + npm scripts
└── PROJECT_GUIDE.md          ← This file
```

---

## Database Tables (what's stored where)

| Table | What it stores |
|-------|---------------|
| `users` | All accounts — students, doctors, admin staff |
| `appointments` | Every appointment booking (student + service + date/time + status) |
| `walk_in_tokens` | Walk-in registrations with token numbers |
| `cases` | Care cases from triage intake (linked to appointments) |
| `counselling_cases` | Counselling-specific cases and session logs |
| `records` | Consultation notes, diagnoses, prescriptions |
| `certificates` | Certificate requests and their approval status |
| `referrals` | Internal and external referral records |
| `concerns` | Student-raised concerns (anonymous or named) |
| `notifications` | In-app notifications per user |
| `settings` | System-wide config key-value pairs |
| `health_centres` | Campus health centre locations |
| `services` | Available health/counselling service types |
| `providers` | Doctors and counsellors with specialisations |
| `schedules` | Provider availability slots |
| `triage_rules` | Automated routing rules for intake engine |
| `certificate_types` | Certificate type definitions |
| `concern_categories` | Concern taxonomy |
| `holidays` | Clinic closures and non-working days |

---

## API Endpoints Summary (server/index.js)

| Method | Endpoint | What it does |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login with email + password |
| GET | `/api/stats` | Dashboard KPI counts |
| GET/POST | `/api/appointments` | List / create appointments |
| PATCH | `/api/appointments/:id` | Update appointment status |
| GET/POST | `/api/queue` | Today's queue |
| GET/POST | `/api/walk-in` | Walk-in list / register new |
| PATCH | `/api/walk-in/:id` | Update walk-in status |
| GET/POST | `/api/cases` | Care cases list / create |
| PATCH | `/api/cases/:id` | Update case status/notes |
| GET/POST | `/api/records` | Health records list / create |
| GET/POST | `/api/certificates` | Certificate requests list / create |
| PATCH | `/api/certificates/:id` | Approve / reject certificate |
| GET/POST | `/api/referrals` | Referrals list / create |
| GET/POST | `/api/counselling` | Counselling cases list / create |
| GET/POST | `/api/concerns` | Concerns list / submit |
| GET/POST | `/api/students` | Student list (admin use) |
| GET | `/api/notifications/me` | Current user's notifications |
| GET/PATCH | `/api/settings` | System settings read / update |
| GET | `/api/masters/:table` | Master data (services, centres, etc.) |
| POST | `/api/intake` | Triage intake submission |
| POST | `/api/crisis/:id/resolve` | Resolve a crisis case |

---

## User Roles & Access

| Role | Portal | Default password |
|------|--------|-----------------|
| `admin` / `doctor` | Admin Portal (`/dashboard`) | `admin@1234` |
| `student` | Student Portal (`/student/dashboard`) | `admin@1234` |

Login email: see `users` table in DB. Demo admin: `admin@sibm.edu`.

---

## Key Technical Decisions

| Decision | Reason |
|----------|--------|
| Sequential API calls (no `Promise.all`) | SQL Server 2019 rejects connection storms from parallel calls |
| `pool.min = 0` | Prevents eager pool creation before SQL Server is ready |
| `_poolPromise` guard in db.js | Prevents race condition where concurrent ECONNRESET handlers each try to create a new pool |
| No React StrictMode | StrictMode double-invokes useEffect in dev, doubling simultaneous API calls |
| `encrypt: true` in SQL config | SQL Server 2019 requires TLS handshake; `false` causes immediate ECONNRESET |

---

*Last updated: 2026-06-13*
