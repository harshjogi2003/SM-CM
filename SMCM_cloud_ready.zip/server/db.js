// MySQL connection layer (cloud-ready) — drop-in replacement for the MSSQL version.
// Reads connection details from environment variables (set these on Render).
import mysql from 'mysql2/promise';

const CONFIG = {
  host:     process.env.DB_HOST     || 'localhost',
  port:     parseInt(process.env.DB_PORT || '3306'),
  user:     process.env.DB_USER     || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME     || 'smcm',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  // Most free MySQL hosts (Aiven, Railway) require SSL. This enables it
  // without needing to ship a CA cert. Safe for these providers.
  ssl: process.env.DB_SSL === 'false' ? undefined : { rejectUnauthorized: false },
};

let _pool = null;
function getPool() {
  if (!_pool) _pool = mysql.createPool(CONFIG);
  return _pool;
}

// Auto-parse JSON-looking text columns so the rest of the app keeps working.
function parseRow(row) {
  if (!row) return null;
  const out = {};
  for (const [k, v] of Object.entries(row)) {
    if (typeof v === 'string' && v.length > 1 && (v[0] === '{' || v[0] === '[')) {
      try { out[k] = JSON.parse(v); } catch { out[k] = v; }
    } else {
      out[k] = v;
    }
  }
  return out;
}

// Stringify object params (the app passes arrays/objects for JSON columns).
function normParams(params) {
  return params.map(p =>
    (p !== null && p !== undefined && typeof p === 'object') ? JSON.stringify(p) : p
  );
}

export async function query(rawSql, params = []) {
  const [rows] = await getPool().execute(rawSql, normParams(params));
  return Array.isArray(rows) ? rows.map(parseRow) : [];
}

export async function queryOne(rawSql, params = []) {
  const rows = await query(rawSql, params);
  return rows[0] || null;
}

export async function run(rawSql, params = []) {
  const [result] = await getPool().execute(rawSql, normParams(params));
  return {
    insertId: result.insertId ?? null,
    affectedRows: result.affectedRows ?? 0,
  };
}

export async function getSetting(key) {
  const row = await queryOne('SELECT value_json FROM settings WHERE key_name = ?', [key]);
  return row ? row.value_json : null;
}

export async function testConnection() {
  try {
    await getPool().query('SELECT 1');
    console.log(`✅ MySQL ready  ${CONFIG.host}:${CONFIG.port} → ${CONFIG.database}`);
    return true;
  } catch (e) {
    console.error('❌ MySQL failed:', e.message);
    return false;
  }
}
