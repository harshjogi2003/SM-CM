import express from 'express';
import cors from 'cors';
import { query, queryOne, run, getSetting, testConnection } from './db.js';
import { requirePermission, requireAdmin } from './middleware.js';
import { evaluate } from './triage.js';
import { dispatch } from './notify.js';

const app = express();
app.use(cors());
app.use(express.json());

// ── HELPERS ───────────────────────────────────────────────────

async function appendCaseTimeline(case_id, entry) {
  if (!case_id) return;
  const c = await queryOne('SELECT timeline FROM cases WHERE id = ?', [parseInt(case_id)]);
  if (!c) return;
  const timeline = Array.isArray(c.timeline) ? c.timeline : [];
  timeline.push({ ts: new Date().toISOString(), ...entry });
  await run('UPDATE cases SET timeline = ?, updated_at = NOW() WHERE id = ?',
    [JSON.stringify(timeline), parseInt(case_id)]);
}

function safeUser(u) {
  if (!u) return {};
  const { password, ...safe } = u;
  return safe;
}

// ── AUTH ──────────────────────────────────────────────────────

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await queryOne(
      'SELECT * FROM users WHERE email = ? AND password = ? AND active = 1',
      [email, password]
    );
    if (!user) return res.status(401).json({ error: 'Invalid email or password' });
    res.json({ user: safeUser(user) });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── STATS ─────────────────────────────────────────────────────

app.get('/api/stats', async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const q = async (sql, p = []) => (await query(sql, p))[0];
    const [
      { totalStudents },
      { todayAppts },
      { pendingCerts },
      { activeCases },
      { openConcerns },
      { upcomingAppts },
      { totalAppointments },
      { completedAppointments },
      { activeCrisisCases },
      { openCases },
      { todayWalkins },
    ] = [
      await q("SELECT COUNT(*) AS totalStudents FROM users WHERE role='student' AND active=1"),
      await q("SELECT COUNT(*) AS todayAppts FROM appointments WHERE [date]=? AND status != 'cancelled'", [today]),
      await q("SELECT COUNT(*) AS pendingCerts FROM certificates WHERE status='pending'"),
      await q("SELECT COUNT(*) AS activeCases FROM counselling_cases WHERE status='active'"),
      await q("SELECT COUNT(*) AS openConcerns FROM concerns WHERE status='pending'"),
      await q("SELECT COUNT(*) AS upcomingAppts FROM appointments WHERE status='upcoming'"),
      await q('SELECT COUNT(*) AS totalAppointments FROM appointments'),
      await q("SELECT COUNT(*) AS completedAppointments FROM appointments WHERE status='completed'"),
      await q("SELECT COUNT(*) AS activeCrisisCases FROM cases WHERE crisis=1 AND current_status NOT IN ('closed','archived')"),
      await q("SELECT COUNT(*) AS openCases FROM cases WHERE current_status NOT IN ('closed','archived')"),
      await q('SELECT COUNT(*) AS todayWalkins FROM walk_in_tokens WHERE [date]=?', [today]),
    ];
    res.json({ totalStudents, todayAppts, pendingCerts, activeCases, openConcerns, upcomingAppts, totalAppointments, completedAppointments, activeCrisisCases, openCases, todayWalkins });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── APPOINTMENTS ──────────────────────────────────────────────

app.get('/api/appointments', async (req, res) => {
  try {
    const { student_id, status } = req.query;
    let sql = `SELECT a.*, u.name AS student_name, u.student_id AS s_id, u.program AS year,
      u.blood_group FROM appointments a LEFT JOIN users u ON a.student_id = u.id WHERE 1=1`;
    const params = [];
    if (student_id) { sql += ' AND a.student_id = ?'; params.push(parseInt(student_id)); }
    if (status) { sql += ' AND a.status = ?'; params.push(status); }
    sql += ' ORDER BY a.date DESC, a.time DESC';
    const rows = await query(sql, params);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/appointments', async (req, res) => {
  try {
    const { student_id, service, health_centre, doctor, provider_id, date, time, complaint, case_id, urgency } = req.body;
    if (!student_id || !service || !date || !time) return res.status(400).json({ error: 'Missing required fields' });
    const result = await run(
      `INSERT INTO appointments (student_id, service, health_centre, doctor, provider_id, date, time, status, complaint, notes, case_id, walk_in, urgency)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [parseInt(student_id), service, health_centre || 'SIBM Main Clinic', doctor || 'To be assigned',
       provider_id || null, date, time, 'upcoming', complaint || '', '', case_id || null, 0, urgency || 1]
    );
    const appt = await queryOne('SELECT * FROM appointments WHERE id = ?', [result.insertId]);
    if (case_id) await appendCaseTimeline(case_id, { type: 'appointment_booked', actor: 'student', summary: `Appointment booked for ${date} at ${time}` });
    await dispatch('appointment.booked', {
      recipient_user_id: parseInt(student_id),
      title: 'Appointment Confirmed',
      message: `Your ${service} appointment on ${date} at ${time} is confirmed.`,
      related_collection: 'appointments', related_id: result.insertId,
    });
    res.status(201).json(appt);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/appointments/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const prev = await queryOne('SELECT * FROM appointments WHERE id = ?', [id]);
    if (!prev) return res.status(404).json({ error: 'Not found' });
    const allowed = ['status','notes','doctor','date','time','complaint','urgency','provider_id'];
    const updates = Object.entries(req.body).filter(([k]) => allowed.includes(k));
    if (updates.length) {
      const sets = updates.map(([k]) => `${k} = ?`).join(', ');
      const vals = [...updates.map(([, v]) => v), id];
      await run(`UPDATE appointments SET ${sets} WHERE id = ?`, vals);
    }
    if (req.body.status === 'completed' && prev.case_id) {
      await appendCaseTimeline(prev.case_id, { type: 'appointment_completed', actor: 'admin', summary: 'Consultation completed' });
    }
    const updated = await queryOne('SELECT * FROM appointments WHERE id = ?', [id]);
    res.json(updated);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/appointments/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await run("UPDATE appointments SET status = 'cancelled' WHERE id = ?", [id]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── HEALTH RECORDS ────────────────────────────────────────────

app.get('/api/records', async (req, res) => {
  try {
    const { student_id } = req.query;
    let sql = `SELECT r.*, u.name AS student_name, u.student_id AS s_id, u.program AS year
      FROM health_records r LEFT JOIN users u ON r.student_id = u.id WHERE 1=1`;
    const params = [];
    if (student_id) { sql += ' AND r.student_id = ?'; params.push(parseInt(student_id)); }
    sql += ' ORDER BY r.date DESC';
    res.json(await query(sql, params));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/records', async (req, res) => {
  try {
    const { student_id, appointment_id, date, service, doctor, diagnosis, treatment, prescription, notes, vitals, case_id, confidentiality } = req.body;
    const result = await run(
      `INSERT INTO health_records (student_id, appointment_id, date, service, doctor, diagnosis, treatment, prescription, notes, vitals, case_id, confidentiality)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
      [parseInt(student_id), appointment_id || null, date, service, doctor,
       diagnosis || '', treatment || '', prescription || '', notes || '',
       JSON.stringify(vitals || {}), case_id || null, confidentiality || 'clinical']
    );
    if (appointment_id) {
      await run("UPDATE appointments SET status = 'completed' WHERE id = ?", [parseInt(appointment_id)]);
    }
    const record = await queryOne('SELECT * FROM health_records WHERE id = ?', [result.insertId]);
    res.status(201).json(record);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── CERTIFICATES ──────────────────────────────────────────────

app.get('/api/certificates', async (req, res) => {
  try {
    const { student_id } = req.query;
    let sql = `SELECT c.*, u.name AS student_name, u.student_id AS s_id, u.program AS year
      FROM certificates c LEFT JOIN users u ON c.student_id = u.id WHERE 1=1`;
    const params = [];
    if (student_id) { sql += ' AND c.student_id = ?'; params.push(parseInt(student_id)); }
    sql += ' ORDER BY c.created_at DESC';
    res.json(await query(sql, params));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/certificates', async (req, res) => {
  try {
    const { student_id, type, cert_type_id, reason, case_id } = req.body;
    if (!student_id || !type) return res.status(400).json({ error: 'Missing fields' });
    const result = await run(
      'INSERT INTO certificates (student_id, type, cert_type_id, status, reason, case_id) VALUES (?,?,?,?,?,?)',
      [parseInt(student_id), type, cert_type_id || null, 'pending', reason || '', case_id || null]
    );
    const cert = await queryOne('SELECT * FROM certificates WHERE id = ?', [result.insertId]);
    res.status(201).json(cert);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/certificates/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const cert = await queryOne('SELECT * FROM certificates WHERE id = ?', [id]);
    if (!cert) return res.status(404).json({ error: 'Not found' });
    const allowed = ['status','issued_on','valid_until','ref','admin_notes'];
    const updates = Object.entries(req.body).filter(([k]) => allowed.includes(k));
    if (updates.length) {
      const sets = updates.map(([k]) => `${k} = ?`).join(', ');
      await run(`UPDATE certificates SET ${sets} WHERE id = ?`, [...updates.map(([, v]) => v), id]);
    }
    const updated = await queryOne('SELECT * FROM certificates WHERE id = ?', [id]);
    if (req.body.status === 'active') {
      await dispatch('certificate.issued', {
        recipient_user_id: cert.student_id,
        title: 'Certificate Issued',
        message: `Your ${cert.type} (${req.body.ref || ''}) has been issued.`,
        related_collection: 'certificates', related_id: id,
      });
    } else if (req.body.status === 'rejected') {
      await dispatch('certificate.rejected', {
        recipient_user_id: cert.student_id,
        title: 'Certificate Request Rejected',
        message: `Your ${cert.type} request was not approved.`,
      });
    }
    res.json(updated);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── COUNSELLING ───────────────────────────────────────────────

app.get('/api/counselling', async (req, res) => {
  try {
    const { student_id } = req.query;
    let sql = `SELECT cc.*, u.name AS student_name, u.student_id AS s_id, u.program AS year
      FROM counselling_cases cc LEFT JOIN users u ON cc.student_id = u.id WHERE 1=1`;
    const params = [];
    if (student_id) { sql += ' AND cc.student_id = ?'; params.push(parseInt(student_id)); }
    sql += ' ORDER BY cc.created_at DESC';
    res.json(await query(sql, params));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/counselling', async (req, res) => {
  try {
    const { student_id, concern, urgency, description } = req.body;
    const existing = await queryOne(
      "SELECT id FROM counselling_cases WHERE student_id = ? AND status = 'active'",
      [parseInt(student_id)]
    );
    if (existing) return res.status(400).json({ error: 'You already have an active counselling case.' });
    const result = await run(
      `INSERT INTO counselling_cases (student_id, status, risk_level, sessions_completed, counsellor, concern, notes, urgency)
       VALUES (?,?,?,?,?,?,?,?)`,
      [parseInt(student_id), 'active', 'low', 0, 'Dr. Anjali Roy', concern || description || '', '', urgency || 1]
    );
    const student = await queryOne('SELECT name FROM users WHERE id = ?', [parseInt(student_id)]);
    await dispatch('counselling.created', {
      required_permission: 'counselling.read',
      title: 'New Counselling Request',
      message: `Student ${student?.name || ''} has requested counselling.`,
    });
    const cc = await queryOne('SELECT * FROM counselling_cases WHERE id = ?', [result.insertId]);
    res.status(201).json(cc);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/counselling/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const prev = await queryOne('SELECT * FROM counselling_cases WHERE id = ?', [id]);
    if (!prev) return res.status(404).json({ error: 'Not found' });
    const allowed = ['status','risk_level','sessions_completed','last_session','next_session','counsellor','notes','urgency'];
    const updates = Object.entries(req.body).filter(([k]) => allowed.includes(k));
    if (updates.length) {
      const sets = updates.map(([k]) => `${k} = ?`).join(', ');
      await run(`UPDATE counselling_cases SET ${sets} WHERE id = ?`, [...updates.map(([, v]) => v), id]);
    }
    if (req.body.next_session && req.body.next_session !== prev.next_session) {
      await dispatch('counselling.session_scheduled', {
        recipient_user_id: prev.student_id,
        title: 'Counselling Session Scheduled',
        message: `Your next counselling session is on ${req.body.next_session}.`,
      });
    }
    const updated = await queryOne('SELECT * FROM counselling_cases WHERE id = ?', [id]);
    res.json(updated);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── CONCERNS ─────────────────────────────────────────────────

app.get('/api/concerns', async (req, res) => {
  try {
    const { student_id } = req.query;
    let sql = `SELECT c.*, u.name AS student_name, u.student_id AS s_id, u.program AS year
      FROM concerns c LEFT JOIN users u ON c.student_id = u.id WHERE 1=1`;
    const params = [];
    if (student_id) { sql += ' AND c.student_id = ?'; params.push(parseInt(student_id)); }
    sql += ' ORDER BY c.created_at DESC';
    res.json(await query(sql, params));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/concerns', async (req, res) => {
  try {
    const { student_id, type, description, priority, anonymous } = req.body;
    if (!student_id || !type || !description) return res.status(400).json({ error: 'Missing fields' });
    const sla = priority === 'high' ? new Date(Date.now() + 2 * 60 * 60 * 1000) : null;
    const result = await run(
      `INSERT INTO concerns (student_id, type, description, priority, status, response, anonymous, sla_due_at)
       VALUES (?,?,?,?,?,?,?,?)`,
      [parseInt(student_id), type, description, priority || 'moderate', 'pending', '',
       anonymous ? 1 : 0, sla ? sla.toISOString().slice(0,19).replace('T',' ') : null]
    );
    await dispatch('concern.received', {
      required_permission: 'welfare.respond',
      title: 'New Student Concern',
      message: `A ${priority || 'moderate'} priority concern (${type}) has been submitted.`,
      related_collection: 'concerns', related_id: result.insertId,
    });
    const concern = await queryOne('SELECT * FROM concerns WHERE id = ?', [result.insertId]);
    res.status(201).json(concern);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/concerns/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const allowed = ['status','response','priority'];
    const updates = Object.entries(req.body).filter(([k]) => allowed.includes(k));
    if (updates.length) {
      const sets = updates.map(([k]) => `${k} = ?`).join(', ');
      await run(`UPDATE concerns SET ${sets} WHERE id = ?`, [...updates.map(([, v]) => v), id]);
    }
    const updated = await queryOne('SELECT * FROM concerns WHERE id = ?', [id]);
    res.json(updated);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── REFERRALS ─────────────────────────────────────────────────

app.get('/api/referrals', async (req, res) => {
  try {
    const { student_id } = req.query;
    let sql = `SELECT r.*, u.name AS student_name, u.student_id AS s_id, u.program AS year
      FROM referrals r LEFT JOIN users u ON r.student_id = u.id WHERE 1=1`;
    const params = [];
    if (student_id) { sql += ' AND r.student_id = ?'; params.push(parseInt(student_id)); }
    sql += ' ORDER BY r.date DESC';
    res.json(await query(sql, params));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/referrals', async (req, res) => {
  try {
    const { student_id, from_doctor, destination, reason, date, notes } = req.body;
    if (!student_id || !destination || !reason) return res.status(400).json({ error: 'Missing fields' });
    const result = await run(
      'INSERT INTO referrals (student_id, from_doctor, destination, reason, status, date, notes, is_external) VALUES (?,?,?,?,?,?,?,?)',
      [parseInt(student_id), from_doctor || 'Admin', destination, reason,
       'pending', date || new Date().toISOString().split('T')[0], notes || '', 1]
    );
    const ref = await queryOne('SELECT * FROM referrals WHERE id = ?', [result.insertId]);
    res.status(201).json(ref);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/referrals/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const allowed = ['status','notes','destination','reason','from_doctor'];
    const updates = Object.entries(req.body).filter(([k]) => allowed.includes(k));
    if (updates.length) {
      const sets = updates.map(([k]) => `${k} = ?`).join(', ');
      await run(`UPDATE referrals SET ${sets} WHERE id = ?`, [...updates.map(([, v]) => v), id]);
    }
    res.json(await queryOne('SELECT * FROM referrals WHERE id = ?', [id]));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── STUDENTS / USERS ──────────────────────────────────────────

app.get('/api/students', async (req, res) => {
  try {
    const rows = await query("SELECT id, name, email, role, student_id, program, semester, dob, blood_group, phone, emergency_contact_name, emergency_contact_phone, allergies, chronic_conditions, active FROM users WHERE role = 'student' AND active = 1");
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/users/:id/profile', async (req, res) => {
  try {
    const user = await queryOne('SELECT id, name, email, role, student_id, program, semester, dob, blood_group, phone, emergency_contact_name, emergency_contact_phone, allergies, chronic_conditions, permissions FROM users WHERE id = ?', [parseInt(req.params.id)]);
    if (!user) return res.status(404).json({ error: 'Not found' });
    res.json(user);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/users/:id/profile', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const allowed = ['emergency_contact_name','emergency_contact_phone','allergies','chronic_conditions','phone','blood_group'];
    const updates = Object.entries(req.body).filter(([k]) => allowed.includes(k));
    if (updates.length) {
      const sets = updates.map(([k]) => `${k} = ?`).join(', ');
      await run(`UPDATE users SET ${sets} WHERE id = ?`, [...updates.map(([, v]) => v), id]);
    }
    const user = await queryOne('SELECT id, name, email, role, student_id, program, semester, dob, blood_group, phone, emergency_contact_name, emergency_contact_phone, allergies, chronic_conditions FROM users WHERE id = ?', [id]);
    res.json(user);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── QUEUE ─────────────────────────────────────────────────────

app.get('/api/queue', async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const appts = await query(
      `SELECT a.*, u.name AS student_name, u.student_id AS s_id, u.program AS year, u.blood_group, u.allergies
       FROM appointments a LEFT JOIN users u ON a.student_id = u.id
       WHERE a.status IN ('upcoming','in_progress') ORDER BY a.urgency DESC, a.time ASC`
    );
    const walkins = await query(
      `SELECT w.*, u.name AS student_name, u.student_id AS s_id, u.program AS year, u.blood_group, u.allergies, 1 AS is_walkin
       FROM walk_in_tokens w LEFT JOIN users u ON w.student_id = u.id
       WHERE w.date = ? AND w.status != 'done' ORDER BY w.urgency DESC, w.created_at ASC`,
      [today]
    );
    const all = [...appts, ...walkins].sort((a, b) => {
      const ua = a.urgency || 1, ub = b.urgency || 1;
      if (ua !== ub) return ub - ua;
      if (a.status === 'in_progress') return -1;
      if (b.status === 'in_progress') return 1;
      return 0;
    });
    res.json(all);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── SLOTS ─────────────────────────────────────────────────────

app.get('/api/slots', async (req, res) => {
  try {
    const { provider_id, date } = req.query;
    if (!provider_id || !date) return res.status(400).json({ error: 'provider_id and date required' });

    const schedule = await queryOne('SELECT * FROM schedules WHERE provider_id = ?', [parseInt(provider_id)]);
    if (!schedule) return res.json([]);

    const dayNames = ['sun','mon','tue','wed','thu','fri','sat'];
    const d = new Date(date + 'T00:00:00');
    const dayKey = dayNames[d.getDay()];
    const windows = schedule.weekday_windows ? schedule.weekday_windows[dayKey] : null;
    if (!windows) return res.json([]);

    const slotMin = schedule.slot_duration_min || 20;
    const bufferMin = schedule.buffer_min || 5;
    const totalMin = slotMin + bufferMin;

    const allSlots = [];
    for (const window of windows.split(',')) {
      const [startStr, endStr] = window.trim().split('-');
      const [sh, sm] = startStr.split(':').map(Number);
      const [eh, em] = endStr.split(':').map(Number);
      let cur = sh * 60 + sm;
      const end = eh * 60 + em;
      while (cur + slotMin <= end) {
        const hh = String(Math.floor(cur / 60)).padStart(2, '0');
        const mm = String(cur % 60).padStart(2, '0');
        allSlots.push(`${hh}:${mm}`);
        cur += totalMin;
      }
    }

    const booked = await query(
      "SELECT time FROM appointments WHERE provider_id = ? AND date = ? AND status != 'cancelled'",
      [parseInt(provider_id), date]
    );
    const bookedTimes = new Set(booked.map(a => (a.time || '').substring(0, 5)));
    const leaveDates = schedule.leave_dates || [];
    const onLeave = leaveDates.includes(date);

    res.json(allSlots.map(t => ({ time: t, available: !bookedTimes.has(t) && !onLeave })));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── INTAKE / CASES ────────────────────────────────────────────

app.post('/api/intake', async (req, res) => {
  try {
    const { student_id, intake_category, symptoms, free_text, urgency_self_mark } = req.body;
    if (!student_id) return res.status(400).json({ error: 'student_id required' });

    const routing = await evaluate({
      intake_category, symptoms: symptoms || [],
      free_text: free_text || '', urgency_self_mark: urgency_self_mark || 'routine'
    });

    const service = await queryOne('SELECT * FROM services WHERE id = ?', [routing.route_to_service_id || 1]);
    const centre = await queryOne(
      'SELECT TOP 1 c.* FROM centres c JOIN providers p ON p.centre_id = c.id WHERE p.id IN (SELECT id FROM providers WHERE service_ids LIKE ?)',
      [`%${routing.route_to_service_id || 1}%`]
    );

    const intakeSummary = { intake_category, symptoms: symptoms || [], free_text: free_text || '', urgency_self_mark: urgency_self_mark || 'routine' };
    const timeline = [
      { ts: new Date().toISOString(), type: 'intake_submitted', actor: 'student', summary: `Intake: ${intake_category || 'general'}` },
      { ts: new Date().toISOString(), type: 'triaged', actor: 'system', summary: `Routed to ${service?.name || 'General Consultation'} (urgency: ${routing.urgency})` },
    ];
    const nextAction = routing.crisis
      ? { label: 'Crisis support being arranged', due_at: null }
      : { label: `Book ${service?.name || 'appointment'}`, due_at: null };

    const result = await run(
      `INSERT INTO cases (student_id, intake_summary, current_status, urgency, crisis, assigned_service_id, assigned_centre_id, timeline, next_action)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [parseInt(student_id), JSON.stringify(intakeSummary),
       routing.crisis ? 'escalated' : 'triaged',
       routing.urgency, routing.crisis ? 1 : 0,
       routing.route_to_service_id || null, centre?.id || null,
       JSON.stringify(timeline), JSON.stringify(nextAction)]
    );

    const caseRow = await queryOne('SELECT * FROM cases WHERE id = ?', [result.insertId]);

    if (routing.crisis) {
      const student = await queryOne('SELECT name FROM users WHERE id = ?', [parseInt(student_id)]);
      await dispatch('crisis.triggered', {
        required_permission: 'crisis.resolve',
        title: 'CRISIS ALERT',
        message: `Student ${student?.name || ''} has triggered a crisis alert.`,
        related_collection: 'cases', related_id: result.insertId,
      });
    } else {
      await dispatch('case.created', {
        recipient_user_id: parseInt(student_id),
        title: 'Your care request was received',
        message: `We have routed you to ${service?.name || 'our care team'}. ${routing.skip_booking ? 'Emergency support is being arranged.' : 'You can now book an appointment.'}`,
      });
    }

    res.status(201).json({ case: caseRow, routing, service, centre });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/cases', requireAdmin, async (req, res) => {
  try {
    const { status, crisis, student_id } = req.query;
    let sql = `SELECT c.*, u.name AS student_name, u.student_id AS s_id, u.program AS year
      FROM cases c LEFT JOIN users u ON c.student_id = u.id WHERE 1=1`;
    const params = [];
    if (status) { sql += ' AND c.current_status = ?'; params.push(status); }
    if (crisis === 'true') { sql += ' AND c.crisis = 1'; }
    if (student_id) { sql += ' AND c.student_id = ?'; params.push(parseInt(student_id)); }
    sql += ' ORDER BY c.created_at DESC';
    res.json(await query(sql, params));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/cases/student/:sid', async (req, res) => {
  try {
    const rows = await query(
      'SELECT * FROM cases WHERE student_id = ? ORDER BY created_at DESC',
      [parseInt(req.params.sid)]
    );
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/cases/:id/timeline', async (req, res) => {
  try {
    const c = await queryOne('SELECT timeline FROM cases WHERE id = ?', [parseInt(req.params.id)]);
    if (!c) return res.status(404).json({ error: 'Not found' });
    res.json(Array.isArray(c.timeline) ? c.timeline : []);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/cases/:id', requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const caseRow = await queryOne('SELECT * FROM cases WHERE id = ?', [id]);
    if (!caseRow) return res.status(404).json({ error: 'Not found' });

    const { admin_note, ...rest } = req.body;
    const allowed = ['current_status','urgency','crisis','assigned_service_id','assigned_centre_id','next_action'];
    const updates = Object.entries(rest).filter(([k]) => allowed.includes(k));

    let timeline = Array.isArray(caseRow.timeline) ? [...caseRow.timeline] : [];

    if (admin_note) {
      timeline.push({ ts: new Date().toISOString(), type: 'admin_note', actor: 'admin', summary: admin_note });
      updates.push(['timeline', JSON.stringify(timeline)]);
    }

    if (updates.length) {
      const sets = updates.map(([k]) => `${k} = ?`).join(', ');
      const vals = updates.map(([, v]) => v);
      await run(`UPDATE cases SET ${sets}, updated_at = NOW() WHERE id = ?`, [...vals, id]);
    }

    const updated = await queryOne('SELECT * FROM cases WHERE id = ?', [id]);
    res.json(updated);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── CRISIS ────────────────────────────────────────────────────

app.post('/api/crisis', async (req, res) => {
  try {
    const { student_id, case_id } = req.body;
    if (!student_id) return res.status(400).json({ error: 'student_id required' });

    let criseCaseId;

    if (case_id) {
      const existing = await queryOne('SELECT id FROM cases WHERE id = ?', [parseInt(case_id)]);
      if (existing) {
        await run(
          "UPDATE cases SET crisis = 1, urgency = 4, current_status = 'escalated', updated_at = NOW() WHERE id = ?",
          [parseInt(case_id)]
        );
        await appendCaseTimeline(case_id, { type: 'crisis_triggered', actor: 'student', summary: 'Crisis alert activated' });
        criseCaseId = parseInt(case_id);
      }
    }

    if (!criseCaseId) {
      const timeline = [{ ts: new Date().toISOString(), type: 'crisis_triggered', actor: 'student', summary: 'Student activated crisis pathway' }];
      const nextAction = { label: 'Crisis support being arranged', due_at: null };
      const result = await run(
        `INSERT INTO cases (student_id, intake_summary, current_status, urgency, crisis, timeline, next_action)
         VALUES (?,?,?,?,?,?,?)`,
        [parseInt(student_id),
         JSON.stringify({ intake_category: 'crisis', free_text: 'Student triggered crisis alert', urgency_self_mark: 'right_now', symptoms: [] }),
         'escalated', 4, 1, JSON.stringify(timeline), JSON.stringify(nextAction)]
      );
      criseCaseId = result.insertId;
    }

    const student = await queryOne('SELECT name FROM users WHERE id = ?', [parseInt(student_id)]);
    await dispatch('crisis.triggered', {
      required_permission: 'crisis.resolve',
      title: 'CRISIS ALERT',
      message: `URGENT: Student ${student?.name || ''} needs immediate support.`,
      related_collection: 'cases', related_id: criseCaseId,
    });

    const settings = await getSetting('institute');
    const emergencyContacts = settings?.emergency_contacts || {};

    res.status(201).json({ crisis_case_id: criseCaseId, emergency_contacts: emergencyContacts });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/crisis/:id/resolve', requirePermission('crisis.resolve'), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { review_summary } = req.body;
    if (!review_summary) return res.status(400).json({ error: 'review_summary is required' });

    const caseRow = await queryOne('SELECT * FROM cases WHERE id = ?', [id]);
    if (!caseRow) return res.status(404).json({ error: 'Not found' });

    const timeline = Array.isArray(caseRow.timeline) ? [...caseRow.timeline] : [];
    timeline.push({ ts: new Date().toISOString(), type: 'crisis_resolved', actor: 'admin', summary: `Crisis resolved. Review: ${review_summary}` });

    await run(
      "UPDATE cases SET crisis = 0, current_status = 'follow_up_pending', timeline = ?, updated_at = NOW() WHERE id = ?",
      [JSON.stringify(timeline), id]
    );

    const userId = parseInt(req.headers['x-user-id']);
    await run(
      'INSERT INTO audit_log (action, case_id, review_summary, user_id) VALUES (?,?,?,?)',
      ['crisis.resolve', id, review_summary, userId || null]
    );

    res.json(await queryOne('SELECT * FROM cases WHERE id = ?', [id]));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── WALK-IN ───────────────────────────────────────────────────

app.get('/api/walk-in', async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const rows = await query(
      `SELECT w.*, u.name AS student_name, u.student_id AS s_id, u.program AS year, u.blood_group
       FROM walk_in_tokens w LEFT JOIN users u ON w.student_id = u.id WHERE w.date = ? ORDER BY w.urgency DESC, w.token_number ASC`,
      [today]
    );
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/walk-in', async (req, res) => {
  try {
    const { student_id, service, service_id, reason, urgency } = req.body;
    const today = new Date().toISOString().split('T')[0];
    const [{ cnt }] = await query('SELECT COUNT(*) AS cnt FROM walk_in_tokens WHERE date = ?', [today]);
    const tokenNumber = (cnt || 0) + 1;

    let serviceName = service;
    if (!serviceName && service_id) {
      const svc = await queryOne('SELECT name FROM services WHERE id = ?', [parseInt(service_id)]);
      serviceName = svc?.name || 'General Consultation';
    }
    if (!serviceName) serviceName = 'General Consultation';

    const result = await run(
      'INSERT INTO walk_in_tokens (student_id, service, service_id, reason, urgency, status, date, token_number) VALUES (?,?,?,?,?,?,?,?)',
      [parseInt(student_id), serviceName, service_id ? parseInt(service_id) : null,
       reason || '', urgency ? parseInt(urgency) : 1, 'waiting', today, tokenNumber]
    );
    const token = await queryOne('SELECT * FROM walk_in_tokens WHERE id = ?', [result.insertId]);
    res.status(201).json(token);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/walk-in/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const allowed = ['status','service','urgency','reason'];
    const updates = Object.entries(req.body).filter(([k]) => allowed.includes(k));
    if (updates.length) {
      const sets = updates.map(([k]) => `${k} = ?`).join(', ');
      await run(`UPDATE walk_in_tokens SET ${sets} WHERE id = ?`, [...updates.map(([, v]) => v), id]);
    }
    res.json(await queryOne('SELECT * FROM walk_in_tokens WHERE id = ?', [id]));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── NOTIFICATIONS ─────────────────────────────────────────────

app.get('/api/notifications/me', async (req, res) => {
  try {
    const userId = parseInt(req.headers['x-user-id']);
    if (!userId) return res.json([]);
    const rows = await query(
      'SELECT * FROM notifications WHERE recipient_user_id = ? ORDER BY created_at DESC',
      [userId]
    );
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/notifications/:id/read', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await run('UPDATE notifications SET is_read = 1 WHERE id = ?', [id]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── MASTERS CRUD ──────────────────────────────────────────────

const MASTER_TABLE_MAP = {
  'centres':            { table: 'centres',            jsonCols: ['working_hours'] },
  'services':           { table: 'services',            jsonCols: [] },
  'providers':          { table: 'providers',           jsonCols: ['service_ids'] },
  'schedules':          { table: 'schedules',           jsonCols: ['weekday_windows','leave_dates'] },
  'triage-rules':       { table: 'triage_rules',        jsonCols: ['condition_json','action_json'] },
  'certificate-types':  { table: 'certificate_types',   jsonCols: [] },
  'concern-categories': { table: 'concern_categories',  jsonCols: [] },
  'holidays':           { table: 'holidays',            jsonCols: [] },
};

for (const [route, { table }] of Object.entries(MASTER_TABLE_MAP)) {
  const path = `/api/masters/${route}`;

  app.get(path, async (req, res) => {
    try {
      res.json(await query(`SELECT * FROM ${table}`));
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.post(path, requirePermission('masters.write'), async (req, res) => {
    try {
      const body = { ...req.body };
      const cols = Object.keys(body);
      const vals = cols.map(k => {
        const v = body[k];
        return (typeof v === 'object' && v !== null) ? JSON.stringify(v) : v;
      });
      const result = await run(
        `INSERT INTO ${table} (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`,
        vals
      );
      res.status(201).json(await queryOne(`SELECT * FROM ${table} WHERE id = ?`, [result.insertId]));
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.patch(`${path}/:id`, requirePermission('masters.write'), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = Object.entries(req.body).map(([k, v]) => [k, (typeof v === 'object' && v !== null) ? JSON.stringify(v) : v]);
      if (updates.length) {
        const sets = updates.map(([k]) => `${k} = ?`).join(', ');
        await run(`UPDATE ${table} SET ${sets} WHERE id = ?`, [...updates.map(([, v]) => v), id]);
      }
      res.json(await queryOne(`SELECT * FROM ${table} WHERE id = ?`, [id]));
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.delete(`${path}/:id`, requirePermission('masters.write'), async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      // Only tables with 'active' column support soft delete
      try {
        await run(`UPDATE ${table} SET active = 0 WHERE id = ?`, [id]);
      } catch {
        await run(`DELETE FROM ${table} WHERE id = ?`, [id]);
      }
      res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });
}

// ── SETTINGS ──────────────────────────────────────────────────

app.get('/api/settings', async (req, res) => {
  try {
    const rows = await query('SELECT key_name, value_json FROM settings');
    const result = {};
    for (const row of rows) {
      result[row.key_name] = row.value_json;
    }
    res.json(result);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/settings', requirePermission('settings.write'), async (req, res) => {
  try {
    for (const [key, value] of Object.entries(req.body)) {
      const existing = await queryOne('SELECT key_name FROM settings WHERE key_name = ?', [key]);
      if (existing) {
        await run('UPDATE settings SET value_json = ? WHERE key_name = ?', [JSON.stringify(value), key]);
      } else {
        await run('INSERT INTO settings (key_name, value_json) VALUES (?,?)', [key, JSON.stringify(value)]);
      }
    }
    const rows = await query('SELECT key_name, value_json FROM settings');
    const result = {};
    for (const row of rows) result[row.key_name] = row.value_json;
    res.json(result);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── ADMIN USERS ───────────────────────────────────────────────

app.get('/api/admin/users', requireAdmin, async (req, res) => {
  try {
    res.json(await query("SELECT id, name, email, role, permissions, active FROM users WHERE role = 'admin'"));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.patch('/api/admin/users/:id', requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { permissions, name } = req.body;
    const updates = [];
    const vals = [];
    if (permissions !== undefined) { updates.push('permissions = ?'); vals.push(JSON.stringify(permissions)); }
    if (name) { updates.push('name = ?'); vals.push(name); }
    if (updates.length) {
      await run(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, [...vals, id]);
    }
    const user = await queryOne('SELECT id, name, email, role, permissions, active FROM users WHERE id = ?', [id]);
    res.json(user);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── VERIFY CERT (public) ──────────────────────────────────────

app.get('/verify/cert/:ref', async (req, res) => {
  try {
    const cert = await queryOne("SELECT * FROM certificates WHERE ref = ? AND status = 'active'", [req.params.ref]);
    if (!cert) return res.status(404).json({ error: 'Certificate not found or invalid' });
    res.json({ valid: true, type: cert.type, issued_on: cert.issued_on, valid_until: cert.valid_until, ref: cert.ref });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── START ─────────────────────────────────────────────────────

const PORT = process.env.PORT || 3000;

testConnection().then(ok => {
  if (!ok) {
    console.error('Starting anyway — SQL Server unreachable, routes will retry on first request.');
  }
  app.listen(PORT, () => {
    console.log(`SMCM API v3.0 running at http://localhost:${PORT}`);
    console.log('Run node server/setup.js first if you have not set up the database.');
  });
});
