import { queryOne } from './db.js';

export function requirePermission(scope) {
  return async (req, res, next) => {
    const userId = parseInt(req.headers['x-user-id']);
    if (!userId) return res.status(401).json({ error: 'Not authenticated' });
    const user = await queryOne('SELECT id, role, permissions FROM users WHERE id = ? AND active = 1', [userId]);
    if (!user) return res.status(401).json({ error: 'User not found' });
    if (user.role === 'student') return next(); // students use role-based access
    const perms = user.permissions || [];
    if (!perms.includes(scope)) {
      return res.status(403).json({ error: `Requires permission: ${scope}` });
    }
    req.currentUser = user;
    next();
  };
}

export function requireAdmin(req, res, next) {
  const userId = parseInt(req.headers['x-user-id']);
  if (!userId) return res.status(401).json({ error: 'Not authenticated' });
  queryOne('SELECT id, role FROM users WHERE id = ? AND active = 1', [userId])
    .then(user => {
      if (!user || user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
      req.currentUser = user;
      next();
    })
    .catch(() => res.status(500).json({ error: 'Auth check failed' }));
}
