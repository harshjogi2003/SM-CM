import { run, query } from './db.js';

export async function dispatch(eventName, payload) {
  const base = {
    event: eventName,
    title: payload.title || eventName,
    message: payload.message || '',
    related_collection: payload.related_collection || null,
    related_id: payload.related_id || null,
  };

  try {
    if (payload.recipient_user_id) {
      await run(
        'INSERT INTO notifications (event, recipient_user_id, title, message, related_collection, related_id) VALUES (?,?,?,?,?,?)',
        [base.event, payload.recipient_user_id, base.title, base.message, base.related_collection, base.related_id]
      );
    } else if (payload.required_permission) {
      const admins = await query('SELECT id, permissions FROM users WHERE role = ? AND active = 1', ['admin']);
      for (const admin of admins) {
        const perms = admin.permissions || [];
        if (perms.includes(payload.required_permission)) {
          await run(
            'INSERT INTO notifications (event, recipient_user_id, title, message, related_collection, related_id) VALUES (?,?,?,?,?,?)',
            [base.event, admin.id, base.title, base.message, base.related_collection, base.related_id]
          );
        }
      }
    }
    console.log(`[notify] ${eventName}: ${base.title}`);
  } catch (e) {
    console.error(`[notify] Failed to dispatch ${eventName}:`, e.message);
  }
}
