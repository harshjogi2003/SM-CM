-- SMCM v3.0 Schema
-- Run via: node server/setup.js

CREATE DATABASE IF NOT EXISTS `smcm`;
USE `smcm`;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(120) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','student') NOT NULL DEFAULT 'student',
  student_id VARCHAR(20),
  program VARCHAR(100),
  semester VARCHAR(20),
  dob DATE,
  blood_group VARCHAR(5),
  phone VARCHAR(20),
  emergency_contact_name VARCHAR(100),
  emergency_contact_phone VARCHAR(20),
  allergies TEXT,
  chronic_conditions TEXT,
  permissions JSON,
  active TINYINT(1) DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS centres (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  location VARCHAR(200),
  working_hours JSON,
  contact_phone VARCHAR(30),
  active TINYINT(1) DEFAULT 1
);

CREATE TABLE IF NOT EXISTS services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  category VARCHAR(50),
  default_duration_min INT DEFAULT 20,
  requires_appointment TINYINT(1) DEFAULT 1,
  active TINYINT(1) DEFAULT 1
);

CREATE TABLE IF NOT EXISTS providers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  qualifications VARCHAR(200),
  specialty VARCHAR(100),
  centre_id INT,
  service_ids JSON,
  email VARCHAR(120),
  active TINYINT(1) DEFAULT 1,
  FOREIGN KEY (centre_id) REFERENCES centres(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS schedules (
  id INT AUTO_INCREMENT PRIMARY KEY,
  provider_id INT NOT NULL,
  weekday_windows JSON,
  slot_duration_min INT DEFAULT 20,
  buffer_min INT DEFAULT 5,
  max_walkin_per_session INT DEFAULT 2,
  leave_dates JSON,
  FOREIGN KEY (provider_id) REFERENCES providers(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS triage_rules (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  priority INT DEFAULT 1,
  active TINYINT(1) DEFAULT 1,
  condition_json JSON,
  action_json JSON
);

CREATE TABLE IF NOT EXISTS certificate_types (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  requires_encounter TINYINT(1) DEFAULT 1,
  default_validity_days INT DEFAULT 365,
  active TINYINT(1) DEFAULT 1
);

CREATE TABLE IF NOT EXISTS concern_categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  icon VARCHAR(10),
  default_urgency VARCHAR(20) DEFAULT 'moderate',
  active TINYINT(1) DEFAULT 1
);

CREATE TABLE IF NOT EXISTS holidays (
  id INT AUTO_INCREMENT PRIMARY KEY,
  date DATE NOT NULL,
  name VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
  key_name VARCHAR(100) PRIMARY KEY,
  value_json JSON
);

CREATE TABLE IF NOT EXISTS cases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  intake_summary JSON,
  current_status VARCHAR(50) DEFAULT 'new',
  urgency TINYINT DEFAULT 1,
  crisis TINYINT(1) DEFAULT 0,
  assigned_service_id INT,
  assigned_centre_id INT,
  timeline JSON,
  next_action JSON,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS appointments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  provider_id INT,
  service_id INT,
  centre_id INT,
  health_centre VARCHAR(100),
  service VARCHAR(100),
  doctor VARCHAR(120),
  date DATE,
  time VARCHAR(10),
  status VARCHAR(30) DEFAULT 'upcoming',
  complaint TEXT,
  notes TEXT,
  urgency TINYINT DEFAULT 1,
  walk_in TINYINT(1) DEFAULT 0,
  case_id INT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES users(id),
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS health_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  appointment_id INT,
  date DATE,
  service VARCHAR(100),
  doctor VARCHAR(120),
  diagnosis TEXT,
  treatment TEXT,
  prescription TEXT,
  notes TEXT,
  vitals JSON,
  case_id INT,
  confidentiality VARCHAR(30) DEFAULT 'clinical',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS certificates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  cert_type_id INT,
  type VARCHAR(100),
  status VARCHAR(30) DEFAULT 'pending',
  reason TEXT,
  issued_on DATE,
  valid_until DATE,
  ref VARCHAR(50),
  admin_notes TEXT,
  case_id INT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS counselling_cases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  status VARCHAR(30) DEFAULT 'active',
  risk_level VARCHAR(20) DEFAULT 'low',
  sessions_completed INT DEFAULT 0,
  last_session DATE,
  next_session DATE,
  counsellor VARCHAR(120),
  concern TEXT,
  description TEXT,
  notes TEXT,
  urgency TINYINT DEFAULT 1,
  case_id INT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS concerns (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  category_id INT,
  type VARCHAR(100),
  description TEXT,
  priority VARCHAR(20) DEFAULT 'moderate',
  status VARCHAR(30) DEFAULT 'pending',
  response TEXT,
  anonymous TINYINT(1) DEFAULT 0,
  case_id INT,
  sla_due_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS referrals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  from_doctor VARCHAR(120),
  destination VARCHAR(200),
  reason TEXT,
  status VARCHAR(30) DEFAULT 'pending',
  date DATE,
  notes TEXT,
  case_id INT,
  external TINYINT(1) DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS walk_in_tokens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  service VARCHAR(100),
  service_id INT,
  reason TEXT,
  urgency TINYINT DEFAULT 1,
  status VARCHAR(30) DEFAULT 'waiting',
  date DATE,
  token_number INT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  event VARCHAR(100),
  recipient_user_id INT,
  title VARCHAR(200),
  message TEXT,
  is_read TINYINT(1) DEFAULT 0,
  related_collection VARCHAR(50),
  related_id INT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  action VARCHAR(100),
  case_id INT,
  review_summary TEXT,
  user_id INT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
