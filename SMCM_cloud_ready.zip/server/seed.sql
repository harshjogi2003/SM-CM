-- SMCM v3.0 Seed Data for SIBM
-- Users: IDs 1=Super Admin, 2=Front Desk, 3-10=Students

INSERT INTO users (id, name, email, password, role, student_id, program, semester, dob, blood_group, phone, emergency_contact_name, emergency_contact_phone, allergies, chronic_conditions, permissions, active) VALUES
(1, 'Dr. Priya Sharma', 'admin@sibm.edu', 'admin123', 'admin', NULL, NULL, NULL, NULL, NULL, '+91 98765 43200', NULL, NULL, NULL, NULL, JSON_ARRAY('queue.view','consultation.write','records.read','records.write','certificate.issue','counselling.read','counselling.write','welfare.respond','welfare.unmask','masters.write','reports.view','settings.write','crisis.resolve','walkin.write'), 1),
(2, 'Kavita Desai', 'frontdesk@sibm.edu', 'front123', 'admin', NULL, NULL, NULL, NULL, NULL, '+91 98765 43201', NULL, NULL, NULL, NULL, JSON_ARRAY('queue.view','walkin.write','records.read','appointments.write'), 1),
(3, 'Rahul Jha', 'rahul@sibm.edu', 'student123', 'student', 'S0844', 'MBA', 'Sem 2', '2001-04-15', 'B+', '+91 98765 01234', 'Suresh Jha', '+91 98765 00001', 'Penicillin', 'None', NULL, 1),
(4, 'Priya Singh', 'priya@sibm.edu', 'student123', 'student', 'S0912', 'MBA', 'Sem 1', '2002-06-20', 'O+', '+91 98765 01235', 'Meena Singh', '+91 98765 00002', 'None', 'Asthma (mild)', NULL, 1),
(5, 'Arjun Mehta', 'arjun@sibm.edu', 'student123', 'student', 'S1023', 'BBA', 'Sem 3', '2003-01-10', 'A+', '+91 98765 01236', 'Vivek Mehta', '+91 98765 00003', 'Dust allergy', 'None', NULL, 1),
(6, 'Sneha Kapoor', 'sneha@sibm.edu', 'student123', 'student', 'S1105', 'MCA', 'Sem 2', '2001-11-25', 'B-', '+91 98765 01237', 'Rajesh Kapoor', '+91 98765 00004', 'Sulfa drugs', 'Type 2 Diabetes (controlled)', NULL, 1),
(7, 'Rohan Verma', 'rohan@sibm.edu', 'student123', 'student', 'S1187', 'MBA', 'Sem 4', '2000-09-08', 'O-', '+91 98765 01238', 'Sunita Verma', '+91 98765 00005', 'None', 'Hypertension (managed)', NULL, 1),
(8, 'Ananya Iyer', 'ananya@sibm.edu', 'student123', 'student', 'S1244', 'BCA', 'Sem 1', '2003-07-14', 'AB+', '+91 98765 01239', 'Krishnan Iyer', '+91 98765 00006', 'None', 'None', NULL, 1),
(9, 'Vikram Nair', 'vikram@sibm.edu', 'student123', 'student', 'S1301', 'MBA', 'Sem 3', '2001-03-22', 'A-', '+91 98765 01240', 'Pradeep Nair', '+91 98765 00007', 'Aspirin', 'None', NULL, 1),
(10, 'Deepika Rao', 'deepika@sibm.edu', 'student123', 'student', 'S1356', 'MCA', 'Sem 1', '2002-12-05', 'O+', '+91 98765 01241', 'Venkat Rao', '+91 98765 00008', 'None', 'Hypothyroidism (on medication)', NULL, 1);

-- Health Centres
INSERT INTO centres (id, name, location, working_hours, contact_phone, active) VALUES
(1, 'SIBM Main Clinic', 'Block A, Ground Floor', JSON_OBJECT('mon','09:00-17:00','tue','09:00-17:00','wed','09:00-17:00','thu','09:00-17:00','fri','09:00-17:00','sat','09:00-13:00','sun',NULL), '020-25671234', 1),
(2, 'Mental Health Centre', 'Block C, First Floor', JSON_OBJECT('mon','09:00-17:00','tue','09:00-17:00','wed','09:00-17:00','thu','09:00-17:00','fri','09:00-17:00','sat',NULL,'sun',NULL), '020-25671235', 1),
(3, 'Physiotherapy Unit', 'Sports Complex', JSON_OBJECT('mon','09:00-17:00','tue','09:00-17:00','wed','09:00-17:00','thu','09:00-17:00','fri','09:00-17:00','sat','09:00-13:00','sun',NULL), '020-25671236', 1),
(4, 'Eye & ENT Clinic', 'Block B, Second Floor', JSON_OBJECT('mon','09:00-17:00','tue',NULL,'wed','09:00-17:00','thu',NULL,'fri','09:00-17:00','sat',NULL,'sun',NULL), '020-25671237', 1);

-- Services
INSERT INTO services (id, name, category, default_duration_min, requires_appointment, active) VALUES
(1, 'General Consultation', 'medical', 20, 1, 1),
(2, 'Preventive Care & Screening', 'medical', 30, 1, 1),
(3, 'Emergency Assessment', 'medical', 30, 0, 1),
(4, 'Individual Counselling', 'counselling', 45, 1, 1),
(5, 'Group Therapy Session', 'counselling', 60, 1, 1),
(6, 'Physiotherapy', 'physiotherapy', 45, 1, 1),
(7, 'Ophthalmology', 'ophthalmology', 30, 1, 1),
(8, 'ENT Consultation', 'ent', 20, 1, 1);

-- Providers
INSERT INTO providers (id, name, qualifications, specialty, centre_id, service_ids, email, active) VALUES
(1, 'Dr. Sanjay Mehta', 'MBBS, MD (General Medicine)', 'General Medicine', 1, JSON_ARRAY(1,2,3), 'sanjay@sibm.edu', 1),
(2, 'Dr. Anjali Roy', 'MA Psychology, PhD Counselling', 'Counselling Psychology', 2, JSON_ARRAY(4,5), 'anjali@sibm.edu', 1),
(3, 'Dr. Ravi Kumar', 'MBBS, MS (Orthopaedics)', 'Orthopaedics & Emergency', 1, JSON_ARRAY(1,3,6), 'ravi@sibm.edu', 1),
(4, 'Dr. Meena Shah', 'BDS, MDS (Oral Surgery)', 'Dental Surgery', 1, JSON_ARRAY(1), 'meena@sibm.edu', 1),
(5, 'Dr. Pradeep Iyer', 'MBBS, DNB (Ophthalmology)', 'Ophthalmology & ENT', 4, JSON_ARRAY(7,8), 'pradeep@sibm.edu', 1);

-- Schedules
INSERT INTO schedules (id, provider_id, weekday_windows, slot_duration_min, buffer_min, max_walkin_per_session, leave_dates) VALUES
(1, 1, JSON_OBJECT('mon','09:00-13:00,14:00-17:00','tue','09:00-13:00,14:00-17:00','wed','09:00-13:00,14:00-17:00','thu','09:00-13:00,14:00-17:00','fri','09:00-13:00,14:00-17:00','sat','09:00-13:00','sun',NULL), 20, 5, 3, JSON_ARRAY()),
(2, 2, JSON_OBJECT('mon','10:00-13:00,14:00-17:00','tue','10:00-13:00,14:00-17:00','wed','10:00-13:00,14:00-17:00','thu','10:00-13:00,14:00-17:00','fri','10:00-13:00,14:00-17:00','sat',NULL,'sun',NULL), 45, 10, 1, JSON_ARRAY()),
(3, 3, JSON_OBJECT('mon','09:00-13:00,14:00-17:00','tue','09:00-13:00,14:00-17:00','wed','09:00-13:00,14:00-17:00','thu','09:00-13:00,14:00-17:00','fri','09:00-13:00,14:00-17:00','sat','09:00-13:00','sun',NULL), 30, 5, 2, JSON_ARRAY());

-- Triage Rules
INSERT INTO triage_rules (id, name, priority, active, condition_json, action_json) VALUES
(1, 'Crisis keyword', 100, 1, JSON_OBJECT('keywords_any', JSON_ARRAY('self-harm','suicide','end it','kill myself','want to die','hurt myself')), JSON_OBJECT('urgency',4,'crisis',true,'skip_booking',true,'route_to_service_id',4)),
(2, 'Mental health urgent', 80, 1, JSON_OBJECT('intake_category','mental_health','urgency_self_mark','right_now'), JSON_OBJECT('urgency',3,'crisis',false,'skip_booking',false,'route_to_service_id',4)),
(3, 'Unwell today with fever', 60, 1, JSON_OBJECT('intake_category','unwell','symptoms_any',JSON_ARRAY('fever'),'urgency_self_mark','today'), JSON_OBJECT('urgency',2,'crisis',false,'skip_booking',false,'route_to_service_id',1,'suggest_walkin',true)),
(4, 'Dental', 40, 1, JSON_OBJECT('intake_category','unwell','symptoms_any',JSON_ARRAY('dental')), JSON_OBJECT('urgency',1,'crisis',false,'skip_booking',false,'route_to_service_id',1)),
(5, 'Fallback', 1, 1, JSON_OBJECT(), JSON_OBJECT('urgency',1,'crisis',false,'skip_booking',false,'route_to_service_id',1));

-- Certificate Types
INSERT INTO certificate_types (id, name, requires_encounter, default_validity_days, active) VALUES
(1, 'Fitness Certificate', 1, 365, 1),
(2, 'Sick Leave Certificate', 1, 7, 1),
(3, 'Sports Fitness Certificate', 1, 180, 1),
(4, 'Medical Leave Certificate', 1, 30, 1),
(5, 'Specialist Referral Letter', 0, 14, 1);

-- Concern Categories
INSERT INTO concern_categories (id, name, icon, default_urgency, active) VALUES
(1, 'Academic Pressure', '📚', 'moderate', 1),
(2, 'Financial Stress', '💸', 'moderate', 1),
(3, 'Physical Health', '🏥', 'moderate', 1),
(4, 'Mental Health', '🧠', 'high', 1),
(5, 'Bullying / Harassment', '⚠️', 'high', 1),
(6, 'Substance Use', '🚨', 'high', 1),
(7, 'Relationship Issues', '💔', 'low', 1),
(8, 'Other', '📌', 'low', 1);

-- Settings
INSERT INTO settings (key_name, value_json) VALUES
('institute', JSON_OBJECT('institute_name','SIBM','office_hours','Mon-Sat 09:00-17:00','emergency_contacts',JSON_OBJECT('counsellor_oncall','+91 98765 43210','campus_security','+91 98765 43211','national_mental_health','iCall: 9152987821'),'booking_horizon_days',14,'min_lead_time_hours',24,'cancellation_lead_time_hours',2));

-- Appointments (8 realistic, student IDs 3-10)
INSERT INTO appointments (id, student_id, provider_id, service_id, centre_id, health_centre, service, doctor, date, time, status, complaint, notes, urgency, walk_in, case_id) VALUES
(1, 3, 1, 1, 1, 'SIBM Main Clinic', 'General Consultation', 'Dr. Sanjay Mehta', '2026-06-20', '10:00', 'upcoming', 'Seasonal fever and cold since 3 days', '', 1, 0, NULL),
(2, 3, 2, 4, 2, 'Mental Health Centre', 'Individual Counselling', 'Dr. Anjali Roy', '2026-04-15', '11:00', 'completed', 'Exam stress management', '', 1, 0, NULL),
(3, 3, 3, 3, 1, 'SIBM Main Clinic', 'Emergency Assessment', 'Dr. Ravi Kumar', '2026-04-27', '09:00', 'completed', 'Ankle injury during football', '', 2, 0, NULL),
(4, 4, 1, 1, 1, 'SIBM Main Clinic', 'General Consultation', 'Dr. Sanjay Mehta', '2026-06-21', '14:00', 'upcoming', 'Persistent headache and fatigue', '', 1, 0, NULL),
(5, 5, 4, 1, 1, 'SIBM Main Clinic', 'General Consultation', 'Dr. Meena Shah', '2026-06-19', '11:30', 'upcoming', 'Tooth pain upper right molar', '', 1, 0, NULL),
(6, 6, 2, 4, 2, 'Mental Health Centre', 'Individual Counselling', 'Dr. Anjali Roy', '2026-06-15', '10:00', 'completed', 'Anxiety and sleep issues', '', 2, 0, NULL),
(7, 7, 1, 1, 1, 'SIBM Main Clinic', 'General Consultation', 'Dr. Sanjay Mehta', '2026-05-10', '09:30', 'cancelled', 'Routine check-up for hypertension', '', 1, 0, NULL),
(8, 9, 5, 7, 4, 'Eye & ENT Clinic', 'Ophthalmology', 'Dr. Pradeep Iyer', '2026-06-18', '15:00', 'completed', 'Blurred vision and eye strain', '', 1, 0, NULL);

-- Health Records (5, linked to completed appointments)
INSERT INTO health_records (id, student_id, appointment_id, date, service, doctor, diagnosis, treatment, prescription, notes, vitals, case_id, confidentiality) VALUES
(1, 3, 3, '2026-04-27', 'Emergency Assessment', 'Dr. Ravi Kumar', 'Grade 1 sprain, left ankle', 'RICE protocol - Rest, Ice, Compression, Elevation', 'Ibuprofen 400mg TDS x 3 days, Diclofenac gel local application BD', 'Ice pack advised every 2 hours for first 24 hours. Follow up if pain persists beyond 5 days.', JSON_OBJECT('bp','118/76','temp','98.4','pulse','82','weight','68','height','175','spo2','99'), NULL, 'clinical'),
(2, 3, 2, '2026-04-15', 'Individual Counselling', 'Dr. Anjali Roy', 'Moderate anxiety, pre-examination stress with somatic symptoms', 'CBT techniques, breathing exercises, sleep hygiene counselling', 'Melatonin 3mg if sleep disrupted, Ashwagandha supplement OD', 'Student is motivated and responsive. Shared study schedule worksheet. Follow up in 2 weeks.', JSON_OBJECT('bp','120/78','temp','98.6','pulse','78','weight','68','height','175'), NULL, 'clinical'),
(3, 4, NULL, '2026-03-10', 'General Consultation', 'Dr. Sanjay Mehta', 'Acute viral fever with rhinitis', 'Supportive management, rest and hydration', 'Paracetamol 500mg TDS x 5 days, Cetirizine 10mg OD for 3 days, ORS', 'Rest for 2 days advised. Return if temperature above 103F.', JSON_OBJECT('bp','110/70','temp','100.2','pulse','92','weight','55','height','162','spo2','98'), NULL, 'clinical'),
(4, 6, 6, '2026-06-15', 'Individual Counselling', 'Dr. Anjali Roy', 'Generalised anxiety disorder, academic performance anxiety', 'Structured CBT, mindfulness based stress reduction techniques introduced', 'Escitalopram 5mg OD (discussed with consulting psychiatrist)', 'Referred for psychiatric assessment. Case escalated to high priority. Next session in 1 week.', JSON_OBJECT('bp','122/80','temp','98.2','pulse','88','weight','52','height','160'), NULL, 'clinical'),
(5, 9, 8, '2026-06-18', 'Ophthalmology', 'Dr. Pradeep Iyer', 'Computer Vision Syndrome with mild myopia progression', 'Prescribed corrective lenses, blue light filter glasses recommended', '2% Carboxymethylcellulose eye drops QID, warm compresses BD', '20-20-20 rule advised. New prescription: -1.75 D right, -2.00 D left. Review in 6 months.', JSON_OBJECT('bp','116/74','temp','98.4','pulse','72','weight','74','height','178'), NULL, 'clinical');

-- Certificates (3: 1 active, 1 pending, 1 expired)
INSERT INTO certificates (id, student_id, cert_type_id, type, status, reason, issued_on, valid_until, ref, admin_notes, case_id) VALUES
(1, 3, 1, 'Fitness Certificate', 'active', 'Annual fitness clearance for MBA sports activities', '2026-01-15', '2026-12-31', 'CERT-2026-001', 'Student passed all physical fitness parameters', NULL),
(2, 4, 2, 'Sick Leave Certificate', 'pending', 'Requesting sick leave certificate for 3 days absence due to viral fever', NULL, NULL, NULL, '', NULL),
(3, 3, 2, 'Sick Leave Certificate', 'expired', 'Viral fever - 3 days leave required', '2026-03-10', '2026-03-13', 'CERT-2026-002', '', NULL);

-- Counselling Cases (2)
INSERT INTO counselling_cases (id, student_id, status, risk_level, sessions_completed, last_session, next_session, counsellor, concern, description, notes, urgency, case_id) VALUES
(1, 3, 'active', 'moderate', 3, '2026-04-15', '2026-06-25', 'Dr. Anjali Roy', 'Exam anxiety and academic performance pressure', 'Student experiencing significant anxiety around upcoming placements and exams. Reports sleep disturbance and concentration issues.', 'Making steady progress. Coping strategies in place. Showing good insight.', 1, NULL),
(2, 6, 'active', 'high', 1, '2026-06-15', '2026-06-22', 'Dr. Anjali Roy', 'Generalised anxiety, social withdrawal and academic stress', 'Student reports persistent feelings of inadequacy, social isolation and academic underperformance. Referred for psychiatric evaluation.', 'Needs close monitoring. Psychiatric consult arranged. Family notified with student consent.', 2, NULL);

-- Concerns (3)
INSERT INTO concerns (id, student_id, category_id, type, description, priority, status, response, anonymous, case_id, sla_due_at) VALUES
(1, 3, 1, 'Academic Pressure', 'Feeling overwhelmed with three concurrent projects and upcoming semester exams. Difficulty sleeping and maintaining concentration during classes. Need academic counselling support.', 'high', 'pending', '', 0, NULL, DATE_ADD(NOW(), INTERVAL 2 HOUR)),
(2, 4, 2, 'Financial Stress', 'Scholarship disbursement has been delayed for 2 months. This is affecting my ability to purchase required textbooks and pay mess fees. Please help escalate.', 'moderate', 'reviewed', 'We have contacted the scholarship office. Your disbursement has been expedited and should reflect within 5 working days. Please follow up at the admin office with this reference.', 0, NULL, NULL),
(3, 5, 5, 'Bullying / Harassment', 'A senior student has been making inappropriate remarks about my work in group projects and publicly ridiculing my presentations. This is affecting my confidence significantly.', 'high', 'pending', '', 1, NULL, DATE_ADD(NOW(), INTERVAL 4 HOUR));

-- Referrals (2)
INSERT INTO referrals (id, student_id, from_doctor, destination, reason, status, date, notes, case_id, external) VALUES
(1, 3, 'Dr. Ravi Kumar', 'Kokilaben Dhirubhai Ambani Hospital, Pune', 'Follow-up physiotherapy for left ankle grade 1 sprain. MRI recommended to rule out ligament damage.', 'pending', '2026-04-28', 'Please bring previous consultation records. Insurance authorization number: KH-2026-4821', NULL, 1),
(2, 6, 'Dr. Anjali Roy', 'NIMHANS Outpatient Clinic, Pune Regional Centre', 'Psychiatric evaluation for generalised anxiety disorder. Student on waitlist. Refer for medication management and assessment.', 'completed', '2026-06-16', 'Patient seen and assessment completed. Escitalopram 5mg prescribed. Follow up in 4 weeks.', NULL, 1);
