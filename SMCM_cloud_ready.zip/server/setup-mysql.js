// Build the schema and seed data on the configured MySQL database.
// Run locally once after setting the DB_* env vars:  node server/setup-mysql.js
import mysql from 'mysql2/promise';
import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dir = dirname(fileURLToPath(import.meta.url));

const CONFIG = {
  host:     process.env.DB_HOST     || 'localhost',
  port:     parseInt(process.env.DB_PORT || '3306'),
  user:     process.env.DB_USER     || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME     || 'smcm',
  multipleStatements: true,
  ssl: process.env.DB_SSL === 'false' ? undefined : { rejectUnauthorized: false },
};

function loadSql(file) {
  let sql = readFileSync(join(__dir, file), 'utf8');
  // The hosted DB already exists; strip CREATE DATABASE / USE lines.
  sql = sql
    .split('\n')
    .filter(l => !/^\s*CREATE\s+DATABASE/i.test(l) && !/^\s*USE\s+/i.test(l))
    .join('\n');
  return sql;
}

async function main() {
  console.log(`Connecting to ${CONFIG.host}:${CONFIG.port}/${CONFIG.database} ...`);
  const conn = await mysql.createConnection(CONFIG);

  console.log('Creating tables...');
  await conn.query(loadSql('schema.sql'));

  const [[{ c }]] = await conn.query('SELECT COUNT(*) AS c FROM users');
  if (c > 0) {
    console.log('Data already present — skipping seed.');
  } else {
    console.log('Seeding data...');
    await conn.query(loadSql('seed.sql'));
    console.log('Seed complete.');
  }

  await conn.end();
  console.log('\nDone. Demo logins:');
  console.log('  Admin:   admin@sibm.edu / admin123');
  console.log('  Student: rahul@sibm.edu / student123');
}

main().catch(e => { console.error('Setup failed:', e.message); process.exit(1); });
