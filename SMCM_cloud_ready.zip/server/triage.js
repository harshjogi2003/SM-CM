import { query } from './db.js';

export async function evaluate(intake) {
  const { intake_category = '', symptoms = [], free_text = '', urgency_self_mark = 'routine' } = intake;
  const text = (free_text + ' ' + symptoms.join(' ')).toLowerCase();

  const rules = await query('SELECT * FROM triage_rules WHERE active = 1 ORDER BY priority DESC');

  for (const rule of rules) {
    const c = rule.condition_json || {};
    const a = rule.action_json || {};

    // Keyword check (crisis detection)
    if (c.keywords_any && c.keywords_any.length) {
      if (c.keywords_any.some(kw => text.includes(kw.toLowerCase()))) {
        return { ...a, matched_rule: rule.name };
      }
      continue; // keyword rule only fires on keyword match
    }

    // Fallback rule (empty condition object)
    if (Object.keys(c).length === 0) {
      return { ...a, matched_rule: rule.name };
    }

    let match = true;
    if (c.intake_category && c.intake_category !== intake_category) match = false;
    if (c.urgency_self_mark && c.urgency_self_mark !== urgency_self_mark) match = false;
    if (c.symptoms_any && c.symptoms_any.length) {
      if (!c.symptoms_any.some(s => symptoms.includes(s) || text.includes(s))) match = false;
    }
    if (match) return { ...a, matched_rule: rule.name };
  }

  return { urgency: 1, crisis: false, skip_booking: false, route_to_service_id: 1, matched_rule: 'default' };
}
