import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import Toast from './components/common/Toast';

import Login from './pages/auth/Login';

// Admin
import AdminLayout from './pages/admin/AdminLayout';
import Dashboard from './pages/admin/Dashboard';
import Queue from './pages/admin/Queue';
import Appointments from './pages/admin/Appointments';
import Consultation from './pages/admin/Consultation';
import Records from './pages/admin/Records';
import Referrals from './pages/admin/Referrals';
import Counselling from './pages/admin/Counselling';
import Compliance from './pages/admin/Compliance';
import AdminRaiseConcern from './pages/admin/AdminRaiseConcern';
import AdminCertificates from './pages/admin/AdminCertificates';
import Cases from './pages/admin/Cases';
import WalkIn from './pages/admin/WalkIn';
import Config from './pages/admin/Config';
import MasterEditor from './pages/admin/MasterEditor';
import AdminUsers from './pages/admin/AdminUsers';

// Student
import StudentLayout from './pages/student/StudentLayout';
import StudentDashboard from './pages/student/StudentDashboard';
import BookAppointment from './pages/student/BookAppointment';
import MyAppointments from './pages/student/MyAppointments';
import MyRecords from './pages/student/MyRecords';
import MyCertificates from './pages/student/MyCertificates';
import CounsellingPortal from './pages/student/CounsellingPortal';
import RaiseConcern from './pages/student/RaiseConcern';
import GetHelp from './pages/student/GetHelp';
import MyCases from './pages/student/MyCases';
import CrisisScreen from './pages/student/CrisisScreen';

function Guard({ role, children }) {
  const { user } = useApp();
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) return <Navigate to={user.role === 'admin' ? '/dashboard' : '/student/dashboard'} replace />;
  return children;
}

function Root() {
  const { user } = useApp();
  if (!user) return <Navigate to="/login" replace />;
  return <Navigate to={user.role === 'admin' ? '/dashboard' : '/student/dashboard'} replace />;
}

function ToastLayer() {
  const { toasts, removeToast } = useApp();
  return <Toast toasts={toasts} remove={removeToast} />;
}

function AppRoutes() {
  return (
    <>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Root />} />

        {/* Crisis screen — fullscreen, outside StudentLayout */}
        <Route path="/student/crisis" element={<Guard role="student"><CrisisScreen /></Guard>} />

        {/* Admin routes */}
        <Route path="/" element={<Guard role="admin"><AdminLayout /></Guard>}>
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="queue" element={<Queue />} />
          <Route path="appointments" element={<Appointments />} />
          <Route path="consultation/:id" element={<Consultation />} />
          <Route path="records" element={<Records />} />
          <Route path="referrals" element={<Referrals />} />
          <Route path="counselling" element={<Counselling />} />
          <Route path="compliance" element={<Compliance />} />
          <Route path="raise-concern" element={<AdminRaiseConcern />} />
          <Route path="certificates" element={<AdminCertificates />} />
          <Route path="cases" element={<Cases />} />
          <Route path="walkin" element={<WalkIn />} />
          <Route path="config" element={<Config />} />
          <Route path="config/:master" element={<MasterEditor />} />
          <Route path="admin-users" element={<AdminUsers />} />
        </Route>

        {/* Student routes */}
        <Route path="/student" element={<Guard role="student"><StudentLayout /></Guard>}>
          <Route path="dashboard" element={<StudentDashboard />} />
          <Route path="get-help" element={<GetHelp />} />
          <Route path="cases" element={<MyCases />} />
          <Route path="book" element={<BookAppointment />} />
          <Route path="appointments" element={<MyAppointments />} />
          <Route path="records" element={<MyRecords />} />
          <Route path="certificates" element={<MyCertificates />} />
          <Route path="counselling" element={<CounsellingPortal />} />
          <Route path="raise-concern" element={<RaiseConcern />} />
        </Route>

        <Route path="*" element={<Root />} />
      </Routes>
      <ToastLayer />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <AppRoutes />
      </AppProvider>
    </BrowserRouter>
  );
}
