const STATUS_CONFIG = {
  // Case statuses
  triaged:           { bg: '#DBEAFE', color: '#1D4ED8', label: 'Triaged' },
  escalated:         { bg: '#7F1D1D', color: '#FEF2F2', label: 'Escalated' },
  follow_up_pending: { bg: '#FFFBEB', color: '#92400E', label: 'Follow-up' },
  closed:            { bg: '#F3F4F6', color: '#6B7280', label: 'Closed' },
  archived:          { bg: '#F3F4F6', color: '#9CA3AF', label: 'Archived' },
  // Appointment statuses
  upcoming:          { bg: '#EFF6FF', color: '#2563EB', label: 'Upcoming' },
  in_progress:       { bg: '#FFFBEB', color: '#D97706', label: 'In Progress' },
  completed:         { bg: '#D1FAE5', color: '#059669', label: 'Completed' },
  cancelled:         { bg: '#F3F4F6', color: '#6B7280', label: 'Cancelled' },
  // Certificate statuses
  pending:           { bg: '#FEF3C7', color: '#D97706', label: 'Pending' },
  active:            { bg: '#D1FAE5', color: '#059669', label: 'Active' },
  expired:           { bg: '#F3F4F6', color: '#6B7280', label: 'Expired' },
  rejected:          { bg: '#FEF2F2', color: '#DC2626', label: 'Rejected' },
  // Counselling statuses
  open:              { bg: '#EFF6FF', color: '#2563EB', label: 'Open' },
  // Walk-in
  waiting:           { bg: '#EFF6FF', color: '#2563EB', label: 'Waiting' },
  done:              { bg: '#D1FAE5', color: '#059669', label: 'Done' },
  // Concern statuses
  reviewed:          { bg: '#D1FAE5', color: '#059669', label: 'Reviewed' },
  assigned:          { bg: '#DBEAFE', color: '#2563EB', label: 'Assigned' },
};

export default function StatusPill({ status, size = 'sm', style = {} }) {
  const cfg = STATUS_CONFIG[status] || { bg: '#F1F5F9', color: '#64748B', label: status };
  const fontSize = size === 'sm' ? 11 : size === 'md' ? 12.5 : 14;
  const padding  = size === 'sm' ? '2px 8px' : size === 'md' ? '4px 10px' : '5px 12px';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center',
      padding, borderRadius: 20, fontSize, fontWeight: 700,
      background: cfg.bg, color: cfg.color, whiteSpace: 'nowrap',
      letterSpacing: '0.01em',
      ...style,
    }}>
      {cfg.label}
    </span>
  );
}
