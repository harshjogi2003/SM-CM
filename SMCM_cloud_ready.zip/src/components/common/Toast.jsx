import { useApp } from '../../context/AppContext';
import { IconCheck, IconX, IconAlert, IconInfo } from './Icons';

const ICONS = {
  success: { icon: <IconCheck />, bg: '#D1FAE5', color: '#065F46' },
  error:   { icon: <IconX />,     bg: '#FEE2E2', color: '#991B1B' },
  warning: { icon: <IconAlert />, bg: '#FEF3C7', color: '#92400E' },
  info:    { icon: <IconInfo />,  bg: '#DBEAFE', color: '#1E40AF' },
};

export default function Toast() {
  const { toasts, removeToast } = useApp();
  if (!toasts.length) return null;

  return (
    <div style={{ position: 'fixed', bottom: 24, right: 24, zIndex: 999, display: 'flex', flexDirection: 'column', gap: 8 }}>
      {toasts.map(t => {
        const s = ICONS[t.type] || ICONS.success;
        return (
          <div key={t.id} style={{
            display: 'flex', alignItems: 'center', gap: 10,
            background: '#fff', border: '1px solid #E5E7EB', borderRadius: 10,
            padding: '10px 14px', boxShadow: '0 4px 16px rgba(15,23,42,.12)',
            animation: 'slideUp .2s', minWidth: 260, maxWidth: 380,
          }}>
            <div style={{ width: 28, height: 28, borderRadius: 8, background: s.bg, color: s.color, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              {s.icon}
            </div>
            <span style={{ fontSize: 13, fontWeight: 500, color: '#0F172A', flex: 1 }}>{t.msg}</span>
            <button onClick={() => removeToast(t.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9CA3AF', padding: 2 }}>
              <IconX size={14} />
            </button>
          </div>
        );
      })}
    </div>
  );
}
