import { createContext, useContext, useState, useCallback, useMemo } from 'react';

export const API = (import.meta.env.VITE_API_URL || 'http://localhost:3000') + '/api';
const AppContext = createContext(null);
export const useApp = () => useContext(AppContext);
let _tid = 0;

export function AppProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('smcm_user')) || null; } catch { return null; }
  });
  const [toasts, setToasts] = useState([]);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const toast = useCallback((msg, type = 'success') => {
    const id = ++_tid;
    setToasts(t => [...t, { id, msg, type }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3500);
  }, []);

  const removeToast = useCallback((id) => setToasts(t => t.filter(x => x.id !== id)), []);

  const login = useCallback((userData) => {
    setUser(userData);
    localStorage.setItem('smcm_user', JSON.stringify(userData));
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem('smcm_user');
  }, []);

  const apiFetch = useCallback(async (path, options = {}) => {
    const currentUser = (() => {
      try { return JSON.parse(localStorage.getItem('smcm_user')) || null; } catch { return null; }
    })();
    const headers = {
      'Content-Type': 'application/json',
      ...(currentUser?.id ? { 'x-user-id': String(currentUser.id) } : {}),
      ...(options.headers || {}),
    };
    const res = await fetch(`${API}${path}`, { ...options, headers });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  }, []);

  const value = useMemo(() => ({
    user, login, logout, toast, removeToast, toasts, sidebarOpen, setSidebarOpen, apiFetch,
  }), [user, login, logout, toast, removeToast, toasts, sidebarOpen, apiFetch]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
