// ═══ MOCK DATA — Student Medical & Counselling Module ═══

export const USERS = [
  { id: 'u1', name: 'Dr. Sarah Khan',    initials: 'SK', color: '#8B1011', role: 'admin',      email: 'sarah.khan@sibm.edu',      dept: 'Medical Administration', hc: 'Main Campus Clinic' },
  { id: 'u2', name: 'Dr. Marc Laurent',  initials: 'ML', color: '#2563EB', role: 'doctor',     email: 'marc.l@sibm.edu',          dept: 'General Medicine',        hc: 'Main Campus Clinic' },
  { id: 'u3', name: 'Ms. Anjali Rao',    initials: 'AR', color: '#7C3AED', role: 'counsellor', email: 'anjali.rao@sibm.edu',       dept: 'Student Counselling',     hc: 'Counselling Centre' },
  { id: 'u4', name: 'Prof. Anil Kumar',  initials: 'AK', color: '#D97706', role: 'faculty',    email: 'anil.k@sibm.edu',           dept: 'Operations Management' },
  { id: 'u5', name: 'Rahul Jha',         initials: 'RJ', color: '#DC2626', role: 'student',    email: 'rahul.jha@student.sibm.edu', studentId: 'S0844', year: 'MBA Sem 2', blood: 'O+', dob: '15 Mar 2002', allergies: 'None recorded', emergency: '+91 98765 43210' },
  { id: 'u6', name: 'Priya Das',         initials: 'PD', color: '#D97706', role: 'student',    email: 'priya.das@student.sibm.edu', studentId: 'S1152', year: 'BBA Sem 4', blood: 'B+', dob: '22 Jan 2004', allergies: 'Penicillin',    emergency: '+91 91234 56789' },
  { id: 'u7', name: 'Aditya Varma',      initials: 'AV', color: '#16A34A', role: 'student',    email: 'aditya.v@student.sibm.edu',  studentId: 'S1024', year: 'MBA Sem 2', blood: 'A+', dob: '08 Jul 2001', allergies: 'None recorded', emergency: '+91 87654 32109' },
  { id: 'u8', name: 'Meera Singh',       initials: 'MS', color: '#4F46E5', role: 'student',    email: 'meera.s@student.sibm.edu',   studentId: 'S1205', year: 'BBA Sem 6', blood: 'AB+',dob: '30 Nov 2002', allergies: 'Sulfa drugs',   emergency: '+91 76543 21098' },
];

export const HEALTH_CENTRES = [
  { id: 'hc1', name: 'Main Campus Clinic', code: 'MCC-001', type: 'Medical', campus: 'Bavdhan', icon: '🏥', color: '#2563EB', status: 'active', services: 12, staff: 6, waitingNow: 5, completedToday: 18, phone: '+91 20 2731 0001', timing: '8:00 AM – 8:00 PM', walkIn: true, hasEmergency: true, desc: 'Primary healthcare facility for all SIBM students offering general medicine, first aid, and basic diagnostics.' },
  { id: 'hc2', name: 'Counselling Centre', code: 'CC-002',  type: 'Counselling', campus: 'Bavdhan', icon: '💆', color: '#7C3AED', status: 'active', services: 8, staff: 4, waitingNow: 3, completedToday: 7, phone: '+91 20 2731 0002', timing: '9:00 AM – 6:00 PM', walkIn: false, hasEmergency: false, desc: 'Confidential counselling support for mental health, academic stress, personal challenges, and wellness.' },
  { id: 'hc3', name: 'Dental Unit',        code: 'DU-003',  type: 'Dental', campus: 'Bavdhan', icon: '🦷', color: '#0891B2', status: 'active', services: 6, staff: 3, waitingNow: 2, completedToday: 5, phone: '+91 20 2731 0003', timing: '10:00 AM – 5:00 PM', walkIn: false, hasEmergency: false, desc: 'Dental consultation, cleaning, and minor procedures for SIBM students and staff.' },
  { id: 'hc4', name: 'Emergency Ward',     code: 'EW-004',  type: 'Emergency', campus: 'Bavdhan', icon: '🚨', color: '#DC2626', status: 'active', services: 4, staff: 5, waitingNow: 1, completedToday: 3, phone: '+91 20 2731 9999', timing: '24 / 7', walkIn: true, hasEmergency: true, desc: '24×7 emergency care with trained paramedics and direct hospital referral capability.' },
];

export const HC_CATEGORIES = [
  { id: 'cat1', hcId: 'hc1', name: 'General Medicine', code: 'GM', icon: '💊', services: 4 },
  { id: 'cat2', hcId: 'hc1', name: 'Diagnostics',      code: 'DX', icon: '🔬', services: 3 },
  { id: 'cat3', hcId: 'hc1', name: 'First Aid',        code: 'FA', icon: '🩹', services: 2 },
  { id: 'cat4', hcId: 'hc1', name: 'Pharmacy',         code: 'PH', icon: '💉', services: 3 },
  { id: 'cat5', hcId: 'hc2', name: 'Individual',       code: 'IC', icon: '🧠', services: 3 },
  { id: 'cat6', hcId: 'hc2', name: 'Group Therapy',    code: 'GT', icon: '👥', services: 2 },
  { id: 'cat7', hcId: 'hc2', name: 'Crisis Support',   code: 'CS', icon: '🆘', services: 2 },
  { id: 'cat8', hcId: 'hc2', name: 'Wellness',         code: 'WL', icon: '🌱', services: 2 },
];

export const SERVICES = [
  { id: 'sv1', hcId: 'hc1', catId: 'cat1', name: 'General Consultation',   duration: 20, fee: 0,    available: true },
  { id: 'sv2', hcId: 'hc1', catId: 'cat1', name: 'BP & Blood Sugar Check', duration: 10, fee: 0,    available: true },
  { id: 'sv3', hcId: 'hc1', catId: 'cat2', name: 'Blood Test – CBC',       duration: 15, fee: 50,   available: true },
  { id: 'sv4', hcId: 'hc1', catId: 'cat3', name: 'First Aid',              duration: 10, fee: 0,    available: true },
  { id: 'sv5', hcId: 'hc2', catId: 'cat5', name: 'Individual Counselling', duration: 45, fee: 0,    available: true },
  { id: 'sv6', hcId: 'hc2', catId: 'cat6', name: 'Group Wellness Session', duration: 60, fee: 0,    available: true },
  { id: 'sv7', hcId: 'hc2', catId: 'cat7', name: 'Crisis Intervention',    duration: 60, fee: 0,    available: true },
  { id: 'sv8', hcId: 'hc3', catId: null,   name: 'Dental Consultation',    duration: 30, fee: 0,    available: true },
  { id: 'sv9', hcId: 'hc4', catId: null,   name: 'Emergency Assessment',   duration: 0,  fee: 0,    available: true },
];

export const QUEUE = [
  {
    id: 'q1', priority: 'crisis', studentId: 'u5', studentName: 'Rahul Jha', initials: 'RJ', color: '#DC2626',
    rollNo: 'S0844', year: 'MBA Sem 2', complaint: 'Severe headache, dizziness, disorientation',
    service: 'Emergency Assessment', hc: 'Emergency Ward', assignedTo: null,
    status: 'waiting', arrivedAt: '08:42 AM', waitMin: 18, type: 'Medical'
  },
  {
    id: 'q2', priority: 'urgent', studentId: 'u6', studentName: 'Priya Das', initials: 'PD', color: '#D97706',
    rollNo: 'S1152', year: 'BBA Sem 4', complaint: 'High anxiety, academic stress, sleep disturbance',
    service: 'Individual Counselling', hc: 'Counselling Centre', assignedTo: 'Ms. Anjali Rao',
    status: 'in-progress', arrivedAt: '09:01 AM', waitMin: 9, type: 'Counselling'
  },
  {
    id: 'q3', priority: 'routine', studentId: 'u7', studentName: 'Aditya Varma', initials: 'AV', color: '#16A34A',
    rollNo: 'S1024', year: 'MBA Sem 2', complaint: 'General checkup, follow-up on previous visit',
    service: 'General Consultation', hc: 'Main Campus Clinic', assignedTo: 'Dr. Marc Laurent',
    status: 'confirmed', arrivedAt: '09:30 AM', waitMin: 5, type: 'Medical'
  },
  {
    id: 'q4', priority: 'routine', studentId: 'u8', studentName: 'Meera Singh', initials: 'MS', color: '#4F46E5',
    rollNo: 'S1205', year: 'BBA Sem 6', complaint: 'Scheduled group wellness session',
    service: 'Group Wellness Session', hc: 'Counselling Centre', assignedTo: 'Ms. Anjali Rao',
    status: 'scheduled', arrivedAt: '10:15 AM', waitMin: 0, type: 'Counselling'
  },
  {
    id: 'q5', priority: 'routine', studentId: 'u5', studentName: 'Kevin Peters', initials: 'KP', color: '#EF4444',
    rollNo: 'S0982', year: 'BBA Sem 4', complaint: 'Dental consultation — teeth cleaning',
    service: 'Dental Consultation', hc: 'Dental Unit', assignedTo: 'Dr. Marc Laurent',
    status: 'completed', arrivedAt: '09:00 AM', waitMin: 7, type: 'Dental'
  },
];

export const APPOINTMENTS = [
  { id: 'ap1', studentName: 'Rahul Jha',   rollNo: 'S0844', service: 'General Consultation', hc: 'Main Campus Clinic', date: '29 Apr 2026', time: '10:00 AM', status: 'upcoming', type: 'Medical' },
  { id: 'ap2', studentName: 'Priya Das',    rollNo: 'S1152', service: 'Individual Counselling', hc: 'Counselling Centre', date: '29 Apr 2026', time: '11:00 AM', status: 'upcoming', type: 'Counselling' },
  { id: 'ap3', studentName: 'Aditya Varma', rollNo: 'S1024', service: 'BP & Blood Sugar Check', hc: 'Main Campus Clinic', date: '28 Apr 2026', time: '09:30 AM', status: 'completed', type: 'Medical' },
  { id: 'ap4', studentName: 'Meera Singh',  rollNo: 'S1205', service: 'Dental Consultation', hc: 'Dental Unit', date: '27 Apr 2026', time: '02:00 PM', status: 'completed', type: 'Dental' },
  { id: 'ap5', studentName: 'Rahul Jha',   rollNo: 'S0844', service: 'Individual Counselling', hc: 'Counselling Centre', date: '30 Apr 2026', time: '03:00 PM', status: 'upcoming', type: 'Counselling' },
];

export const RECORDS = [
  {
    id: 'r1', studentId: 'u5', studentName: 'Rahul Jha', rollNo: 'S0844', date: '27 Apr 2026',
    service: 'Emergency Assessment', hc: 'Emergency Ward', doctor: 'Dr. Sarah Khan',
    diagnosis: 'Hypertensive urgency with tension headache', prescription: 'Tab. Amlodipine 5mg OD × 5 days. Oral rehydration.',
    vitals: { bp: '148/95', pulse: '96', temp: '38.2', spo2: '97', wt: '68', ht: '172' },
    outcome: 'Follow-up Required', followUpDate: '04 May 2026', certIssued: true, certType: 'Medical Certificate', referral: false,
    notes: 'Student presented with severe headache. BP elevated. Started on medication. Advised rest for 2 days.',
  },
  {
    id: 'r2', studentId: 'u5', studentName: 'Rahul Jha', rollNo: 'S0844', date: '22 Mar 2026',
    service: 'General Consultation', hc: 'Main Campus Clinic', doctor: 'Dr. Marc Laurent',
    diagnosis: 'Viral URTI — mild', prescription: 'Tab. Paracetamol 500mg TDS × 3 days. Steam inhalation.',
    vitals: { bp: '118/78', pulse: '82', temp: '37.4', spo2: '99', wt: '68', ht: '172' },
    outcome: 'Treated & Released', followUpDate: null, certIssued: false, certType: null, referral: false,
  },
  {
    id: 'r3', studentId: 'u6', studentName: 'Priya Das', rollNo: 'S1152', date: '27 Apr 2026',
    service: 'Individual Counselling', hc: 'Counselling Centre', doctor: 'Ms. Anjali Rao',
    diagnosis: 'Academic stress with anxiety features', prescription: 'CBT techniques. Sleep hygiene advice.',
    vitals: null,
    outcome: 'Follow-up Required', followUpDate: '10 May 2026', certIssued: false, certType: null, referral: false,
  },
];

export const CERTIFICATES = [
  { id: 'cert1', studentId: 'u5', rollNo: 'S0844', studentName: 'Rahul Jha', type: 'Medical Certificate', issuedBy: 'Dr. Sarah Khan', issuedOn: '27 Apr 2026', validFor: '2 days', reason: 'Hypertensive urgency — rest advised', status: 'active', ref: 'CERT-2026-044' },
  { id: 'cert2', studentId: 'u5', rollNo: 'S0844', studentName: 'Rahul Jha', type: 'Return-to-Class Note', issuedBy: 'Dr. Marc Laurent', issuedOn: '24 Mar 2026', validFor: '1 day', reason: 'Post-URTI recovery', status: 'expired', ref: 'CERT-2026-031' },
  { id: 'cert3', studentId: 'u7', rollNo: 'S1024', studentName: 'Aditya Varma', type: 'Sports Clearance', issuedBy: 'Dr. Marc Laurent', issuedOn: '20 Apr 2026', validFor: 'Academic Year', reason: 'Annual clearance for inter-college sports', status: 'active', ref: 'CERT-2026-039' },
];

export const CERT_TYPES = [
  { id: 'ct1', name: 'Medical Certificate',    code: 'MC',  desc: 'For absence due to illness',       daysValid: 2,   requiresDoctor: true },
  { id: 'ct2', name: 'Return-to-Class Note',   code: 'RC',  desc: 'Post-recovery class clearance',    daysValid: 1,   requiresDoctor: true },
  { id: 'ct3', name: 'Sports Clearance',       code: 'SC',  desc: 'Medical clearance for sports',     daysValid: 365, requiresDoctor: true },
  { id: 'ct4', name: 'Referral Letter',        code: 'RL',  desc: 'Letter to external specialist',    daysValid: 30,  requiresDoctor: true },
  { id: 'ct5', name: 'Fitness Certificate',    code: 'FC',  desc: 'General fitness declaration',      daysValid: 180, requiresDoctor: true },
  { id: 'ct6', name: 'Counselling Summary',    code: 'CS',  desc: 'Non-clinical counselling summary', daysValid: 90,  requiresDoctor: false },
];

export const REFERRAL_DESTINATIONS = [
  { id: 'rd1', name: 'Ruby Hall Clinic',          type: 'Multi-specialty Hospital',  distance: '3.2 km', contact: '+91 20 6645 5000', specialty: ['Cardiology', 'Neurology', 'General Medicine'] },
  { id: 'rd2', name: 'Sahyadri Hospital',          type: 'Multi-specialty Hospital',  distance: '5.8 km', contact: '+91 20 4060 2800', specialty: ['Orthopedics', 'Psychiatry', 'ENT'] },
  { id: 'rd3', name: 'NIMHANS – Pune Branch',      type: 'Mental Health Institute',   distance: '8.1 km', contact: '+91 20 2553 0000', specialty: ['Psychiatry', 'Psychology', 'Neurology'] },
  { id: 'rd4', name: 'Dr. Kiran Dental Care',      type: 'Dental Clinic',             distance: '1.4 km', contact: '+91 98765 00001', specialty: ['Dentistry', 'Orthodontics'] },
];

export const CONCERN_TYPES = [
  { id: 'cnt1', name: 'Academic Distress',    icon: '📚', severity: 'moderate', autoAlert: true,  desc: 'Persistent poor performance, missed exams, academic anxiety' },
  { id: 'cnt2', name: 'Emotional Crisis',     icon: '😔', severity: 'high',     autoAlert: true,  desc: 'Visible emotional distress, self-harm risk, suicidal ideation' },
  { id: 'cnt3', name: 'Physical Illness',     icon: '🤒', severity: 'low',      autoAlert: false, desc: 'Recurring illness, chronic condition requiring monitoring' },
  { id: 'cnt4', name: 'Substance Abuse',      icon: '⚠️', severity: 'high',     autoAlert: true,  desc: 'Suspected drug or alcohol misuse' },
  { id: 'cnt5', name: 'Social Isolation',     icon: '🏠', severity: 'moderate', autoAlert: false, desc: 'Withdrawn behaviour, absence from social or academic activities' },
  { id: 'cnt6', name: 'Financial Hardship',   icon: '💸', severity: 'low',      autoAlert: false, desc: 'Inability to meet basic needs affecting academic performance' },
];

export const COUNSELLING_CASES = [
  { id: 'cc1', studentName: 'Priya Das',   rollNo: 'S1152', counsellor: 'Ms. Anjali Rao', type: 'Individual', sessions: 3, status: 'active',   opened: '15 Mar 2026', nextSession: '05 May 2026', concern: 'Academic Distress', risk: 'moderate' },
  { id: 'cc2', studentName: 'Meera Singh', rollNo: 'S1205', counsellor: 'Ms. Anjali Rao', type: 'Group',      sessions: 5, status: 'active',   opened: '10 Feb 2026', nextSession: '29 Apr 2026', concern: 'Social Isolation',  risk: 'low' },
  { id: 'cc3', studentName: 'Rahul Jha',   rollNo: 'S0844', counsellor: 'Ms. Anjali Rao', type: 'Individual', sessions: 2, status: 'on-hold',  opened: '01 Apr 2026', nextSession: null,          concern: 'Emotional Crisis',  risk: 'high' },
  { id: 'cc4', studentName: 'Aditya Varma',rollNo: 'S1024', counsellor: 'Ms. Anjali Rao', type: 'Individual', sessions: 6, status: 'closed',   opened: '10 Jan 2026', nextSession: null,          concern: 'Academic Distress', risk: 'low' },
];

export const FOLLOW_UPS = [
  { id: 'fu1', studentName: 'Rahul Jha',   rollNo: 'S0844', date: '04 May 2026', type: 'Medical',     status: 'upcoming', note: 'BP monitoring follow-up' },
  { id: 'fu2', studentName: 'Priya Das',   rollNo: 'S1152', date: '29 Apr 2026', type: 'Counselling', status: 'today',    note: 'Session 4 — CBT progress review' },
  { id: 'fu3', studentName: 'Kevin Peters',rollNo: 'S0982', date: '25 Apr 2026', type: 'Dental',      status: 'overdue',  note: 'Post-cleaning check, overdue by 4 days' },
];

export const ANALYTICS_VISITS = [
  { day: 'Mon', medical: 12, counselling: 6, dental: 3 },
  { day: 'Tue', medical: 15, counselling: 8, dental: 4 },
  { day: 'Wed', medical: 10, counselling: 7, dental: 2 },
  { day: 'Thu', medical: 18, counselling: 9, dental: 5 },
  { day: 'Fri', medical: 14, counselling: 11, dental: 3 },
  { day: 'Sat', medical: 7,  counselling: 5,  dental: 1 },
  { day: 'Sun', medical: 5,  counselling: 3,  dental: 0 },
];

export const ANALYTICS_OUTCOMES = [
  { name: 'Treated & Released', value: 52, color: '#10B981' },
  { name: 'Follow-up Required', value: 28, color: '#8B1011' },
  { name: 'Referred',           value: 12, color: '#3B82F6' },
  { name: 'Emergency Escalated',value: 8,  color: '#DC2626' },
];

export const STUDENT_MY_APPOINTMENTS = (userId) => APPOINTMENTS.filter(a => a.studentName === (USERS.find(u => u.id === userId)?.name));
export const STUDENT_MY_CERTS = (userId) => CERTIFICATES.filter(c => c.studentId === userId);
export const STUDENT_MY_RECORDS = (userId) => RECORDS.filter(r => r.studentId === userId);

export const TIME_SLOTS = ['09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM', '02:00 PM', '02:30 PM', '03:00 PM', '03:30 PM', '04:00 PM'];
export const BOOKED_SLOTS = ['09:30 AM', '10:30 AM', '03:00 PM'];
