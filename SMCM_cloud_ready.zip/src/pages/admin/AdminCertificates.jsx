import { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';

const STATUS_STYLE = {
  pending:  { bg: '#FEF3C7', color: '#D97706', label: 'Pending' },
  approved: { bg: '#DBEAFE', color: '#2563EB', label: 'Approved' },
  active:   { bg: '#ECFDF5', color: '#059669', label: 'Issued' },
  expired:  { bg: '#F1F5F9', color: '#64748B', label: 'Expired' },
  rejected: { bg: '#FEF2F2', color: '#DC2626', label: 'Rejected' },
};

const inputStyle = {
  width: '100%', padding: '8px 11px', borderRadius: 7,
  border: '1.5px solid #E2E8F0', fontSize: 12.5, boxSizing: 'border-box',
  background: '#fff', color: '#0F172A', outline: 'none',
};

export default function AdminCertificates() {
  const { apiFetch, toast } = useApp();
  const [certs, setCerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('pending');
  const [issuing, setIssuing] = useState(null);
  const [issueForm, setIssueForm] = useState({ issued_on: '', valid_until: '', admin_notes: '' });
  const [actionInProgress, setActionInProgress] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try { setCerts(await apiFetch('/certificates')); }
    catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const approve = async (cert) => {
    setActionInProgress(true);
    const today = new Date().toISOString().split('T')[0];
    const validUntil = issueForm.valid_until || (() => { const d = new Date(); d.setFullYear(d.getFullYear() + 1); return d.toISOString().split('T')[0]; })();
    const ref = `CERT-${new Date().getFullYear()}-${String(cert.id).padStart(4, '0')}`;
    try {
      await apiFetch(`/certificates/${cert.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'active', issued_on: issueForm.issued_on || today, valid_until: validUntil, ref, admin_notes: issueForm.admin_notes }),
      });
      toast(`Certificate issued for ${cert.student_name}`);
      setIssuing(null);
      setIssueForm({ issued_on: '', valid_until: '', admin_notes: '' });
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setActionInProgress(false); }
  };

  const reject = async (cert) => {
    if (!window.confirm(`Reject the certificate request from ${cert.student_name}?`)) return;
    setActionInProgress(true);
    try {
      await apiFetch(`/certificates/${cert.id}`, { method: 'PATCH', body: JSON.stringify({ status: 'rejected' }) });
      toast('Certificate request rejected');
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setActionInProgress(false); }
  };

  const filtered = filter === 'all' ? certs : certs.filter(c => c.status === filter);
  const counts = {
    all: certs.length,
    pending:  certs.filter(c => c.status === 'pending').length,
    active:   certs.filter(c => c.status === 'active').length,
    expired:  certs.filter(c => c.status === 'expired').length,
    rejected: certs.filter(c => c.status === 'rejected').length,
  };

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Medical Certificates</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Review and issue student certificate requests</div>
        </div>
      </div>

      {/* Filter tabs with counts */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, background: '#F8FAFC', padding: '4px', borderRadius: 9, width: 'fit-content', border: '1px solid #E2E8F0' }}>
        {[
          { key: 'pending',  label: 'Pending' },
          { key: 'active',   label: 'Issued' },
          { key: 'rejected', label: 'Rejected' },
          { key: 'expired',  label: 'Expired' },
          { key: 'all',      label: 'All' },
        ].map(t => (
          <button
            key={t.key} onClick={() => setFilter(t.key)}
            style={{
              padding: '6px 14px', borderRadius: 7, border: 'none', cursor: 'pointer',
              fontWeight: 600, fontSize: 12.5,
              background: filter === t.key ? '#fff' : 'transparent',
              color: filter === t.key ? '#0F172A' : '#64748B',
              boxShadow: filter === t.key ? '0 1px 4px rgba(0,0,0,.08)' : 'none',
              display: 'flex', alignItems: 'center', gap: 6,
            }}
          >
            {t.label}
            <span style={{ fontSize: 10.5, background: filter === t.key ? '#E2E8F0' : '#E2E8F0', color: '#64748B', padding: '1px 6px', borderRadius: 9, fontWeight: 700 }}>
              {counts[t.key] ?? counts.all}
            </span>
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ padding: 40, color: '#94A3B8', fontSize: 13, textAlign: 'center' }}>Loading certificates...</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#94A3B8' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>—</div>
          <div style={{ fontWeight: 600, fontSize: 14 }}>No {filter === 'all' ? '' : filter} certificates</div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filtered.map(c => {
            const ss = STATUS_STYLE[c.status] || STATUS_STYLE.pending;
            return (
              <div key={c.id} style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, overflow: 'hidden' }}>
                <div style={{ padding: '16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 5, flexWrap: 'wrap' }}>
                      <span style={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>{c.student_name}</span>
                      <span style={{ fontSize: 12, color: '#94A3B8' }}>{c.s_id}</span>
                      {c.year && <span style={{ fontSize: 12, color: '#94A3B8' }}>{c.year}</span>}
                      <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 600, background: ss.bg, color: ss.color }}>{ss.label}</span>
                    </div>
                    <div style={{ fontWeight: 700, fontSize: 13.5, color: '#0F172A', marginBottom: 4 }}>{c.type}</div>
                    {c.reason && <div style={{ fontSize: 12.5, color: '#64748B' }}>Reason: {c.reason}</div>}
                    {c.ref && (
                      <div style={{ fontSize: 12, color: '#94A3B8', marginTop: 4, display: 'flex', gap: 14 }}>
                        <span>Ref: <strong style={{ color: '#374151' }}>{c.ref}</strong></span>
                        {c.issued_on && <span>Issued: {c.issued_on}</span>}
                        {c.valid_until && <span>Valid until: {c.valid_until}</span>}
                      </div>
                    )}
                    <div style={{ fontSize: 11.5, color: '#94A3B8', marginTop: 4 }}>
                      Requested: {c.created_at ? new Date(c.created_at).toLocaleDateString('en-IN') : '—'}
                    </div>
                  </div>

                  {c.status === 'pending' && (
                    <div style={{ display: 'flex', gap: 8, marginLeft: 20, flexShrink: 0 }}>
                      <button
                        onClick={() => { setIssuing(issuing === c.id ? null : c.id); setIssueForm({ issued_on: '', valid_until: '', admin_notes: '' }); }}
                        style={{ padding: '7px 16px', background: '#059669', color: '#fff', border: 'none', borderRadius: 7, fontSize: 12.5, fontWeight: 600, cursor: 'pointer' }}
                      >
                        Issue
                      </button>
                      <button
                        onClick={() => reject(c)} disabled={actionInProgress}
                        style={{ padding: '7px 14px', background: '#FEF2F2', color: '#DC2626', border: '1px solid #FECACA', borderRadius: 7, fontSize: 12.5, fontWeight: 600, cursor: 'pointer' }}
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </div>

                {/* Inline issue form */}
                {issuing === c.id && (
                  <div style={{ borderTop: '1px solid #E2E8F0', padding: '16px 20px', background: '#F0FDF4' }}>
                    <div style={{ fontWeight: 700, fontSize: 12.5, color: '#0F172A', marginBottom: 12 }}>Issue Certificate</div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 2fr', gap: 12, marginBottom: 12 }}>
                      <div>
                        <label style={{ display: 'block', fontSize: 11.5, fontWeight: 700, color: '#64748B', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Issue Date</label>
                        <input type="date" value={issueForm.issued_on} onChange={e => setIssueForm(f => ({ ...f, issued_on: e.target.value }))} style={inputStyle} />
                      </div>
                      <div>
                        <label style={{ display: 'block', fontSize: 11.5, fontWeight: 700, color: '#64748B', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Valid Until</label>
                        <input type="date" value={issueForm.valid_until} onChange={e => setIssueForm(f => ({ ...f, valid_until: e.target.value }))} style={inputStyle} />
                      </div>
                      <div>
                        <label style={{ display: 'block', fontSize: 11.5, fontWeight: 700, color: '#64748B', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Admin Notes</label>
                        <input value={issueForm.admin_notes} onChange={e => setIssueForm(f => ({ ...f, admin_notes: e.target.value }))} placeholder="Optional notes..." style={inputStyle} />
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button
                        onClick={() => approve(c)} disabled={actionInProgress}
                        style={{ padding: '8px 18px', background: '#059669', color: '#fff', border: 'none', borderRadius: 7, fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }}
                      >
                        {actionInProgress ? 'Issuing...' : 'Confirm & Issue'}
                      </button>
                      <button
                        onClick={() => setIssuing(null)}
                        style={{ padding: '8px 14px', background: '#fff', color: '#374151', border: '1px solid #E2E8F0', borderRadius: 7, fontSize: 12.5, cursor: 'pointer' }}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
