import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { useState, useEffect } from 'react';

const NAV = [
  {
    section: 'Overview',
    items: [
      { label: 'Dashboard',           path: '/dashboard',    icon: '▣' },
    ],
  },
  {
    section: 'Clinical',
    items: [
      { label: "Today's Queue",       path: '/queue',        icon: '⊞' },
      { label: 'Appointments',        path: '/appointments', icon: '◷' },
      { label: 'Cases',               path: '/cases',        icon: '◈' },
      { label: 'Walk-in',             path: '/walkin',       icon: '↗' },
      { label: 'Consultation',        path: '/consultation', icon: '⚕', hidden: true },
      { label: 'Medical Records',     path: '/records',      icon: '≡' },
      { label: 'Certificates',        path: '/certificates', icon: '◻' },
      { label: 'Referrals',           path: '/referrals',    icon: '⇄' },
    ],
  },
  {
    section: 'Support',
    items: [
      { label: 'Counselling',         path: '/counselling',  icon: '◎' },
      { label: 'Student Concerns',    path: '/raise-concern',icon: '!' },
    ],
  },
  {
    section: 'Reports',
    items: [
      { label: 'Analytics',           path: '/compliance',   icon: '↑' },
    ],
  },
  {
    section: 'System',
    items: [
      { label: 'Configuration',       path: '/config',       icon: '◌' },
      { label: 'Users & Permissions', path: '/admin-users',  icon: '◷' },
    ],
  },
];

const BREADCRUMB_MAP = {
  '/dashboard':    'Dashboard',
  '/queue':        "Today's Queue",
  '/appointments': 'Appointments',
  '/cases':        'Cases',
  '/walkin':       'Walk-in Tokens',
  '/records':      'Medical Records',
  '/certificates': 'Certificates',
  '/referrals':    'Referrals',
  '/counselling':  'Counselling Cases',
  '/raise-concern':'Student Concerns',
  '/compliance':   'Analytics & Reports',
  '/consultation': 'Consultation',
  '/config':       'Configuration',
  '/admin-users':  'Users & Permissions',
};

function getInitials(name = '') {
  return name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
}

export default function AdminLayout() {
  const { user, logout, apiFetch } = useApp();
  const navigate = useNavigate();
  const location = useLocation();

  const [crisisCount, setCrisisCount] = useState(0);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNotifDot, setShowNotifDot] = useState(false);

  const currentPath = '/' + location.pathname.split('/')[1];
  const breadcrumb = BREADCRUMB_MAP[currentPath] || 'Admin Portal';

  useEffect(() => {
    (async () => {
      try {
        const s = await apiFetch('/stats');
        setCrisisCount(s.activeCrisisCases || 0);
      } catch {}
      try {
        const ns = await apiFetch('/notifications/me');
        const u = (ns || []).filter(n => !n.is_read).length;
        setUnreadCount(u);
        setShowNotifDot(u > 0);
      } catch {}
    })();
  }, [location.pathname, apiFetch]);

  const S = {
    sidebar: {
      width: 240, flexShrink: 0, background: '#0F172A',
      display: 'flex', flexDirection: 'column', overflowY: 'auto',
    },
    logoBox: {
      padding: '22px 20px 18px', borderBottom: '1px solid rgba(255,255,255,.06)',
    },
    logoInner: {
      display: 'flex', alignItems: 'center', gap: 11,
    },
    logoIcon: {
      width: 38, height: 38, borderRadius: 10, background: '#2563EB',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontWeight: 900, fontSize: 18, color: '#fff', flexShrink: 0, letterSpacing: '-0.02em',
    },
    userBox: {
      padding: '14px 20px', borderBottom: '1px solid rgba(255,255,255,.06)',
      display: 'flex', alignItems: 'center', gap: 10,
    },
    avatar: {
      width: 34, height: 34, borderRadius: '50%', background: '#1D4ED8',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontWeight: 700, fontSize: 12.5, color: '#fff', flexShrink: 0,
    },
    sectionLabel: {
      padding: '10px 20px 4px', fontSize: 10, fontWeight: 700,
      color: '#334155', textTransform: 'uppercase', letterSpacing: '0.08em',
    },
  };

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden', background: '#F8FAFC', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Sidebar */}
      <aside style={S.sidebar}>
        {/* Logo */}
        <div style={S.logoBox}>
          <div style={S.logoInner}>
            <div style={S.logoIcon}>+</div>
            <div>
              <div style={{ fontWeight: 800, fontSize: 14.5, color: '#F8FAFC', letterSpacing: '-0.03em' }}>SMCM</div>
              <div style={{ fontSize: 10.5, color: '#475569', marginTop: 1 }}>Admin Portal · v3.0</div>
            </div>
          </div>
        </div>

        {/* User */}
        {user && (
          <div style={S.userBox}>
            <div style={S.avatar}>{getInitials(user.name)}</div>
            <div style={{ minWidth: 0, flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 12.5, color: '#F1F5F9', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user.name}</div>
              <div style={{ fontSize: 11, color: '#475569', marginTop: 1 }}>
                {Array.isArray(user.permissions) && user.permissions.length > 3 ? 'Super Admin' : 'Staff'}
              </div>
            </div>
          </div>
        )}

        {/* Nav */}
        <nav style={{ flex: 1, padding: '8px 0' }}>
          {NAV.map(group => (
            <div key={group.section} style={{ marginBottom: 4 }}>
              <div style={S.sectionLabel}>{group.section}</div>
              {group.items.filter(i => !i.hidden).map(item => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  style={({ isActive }) => ({
                    display: 'flex', alignItems: 'center', gap: 10,
                    padding: '7.5px 20px', fontSize: 13, fontWeight: isActive ? 600 : 400,
                    color: isActive ? '#fff' : '#64748B',
                    background: isActive ? 'rgba(37,99,235,0.18)' : 'transparent',
                    borderLeft: `3px solid ${isActive ? '#2563EB' : 'transparent'}`,
                    textDecoration: 'none', transition: 'all .12s',
                  })}
                >
                  <span style={{ fontSize: 14, width: 18, textAlign: 'center', flexShrink: 0, color: 'inherit', opacity: 0.85 }}>{item.icon}</span>
                  <span style={{ flex: 1 }}>{item.label}</span>
                  {item.path === '/cases' && crisisCount > 0 && (
                    <span style={{ background: '#DC2626', color: '#fff', borderRadius: '50%', width: 18, height: 18, fontSize: 10, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      {crisisCount > 9 ? '9+' : crisisCount}
                    </span>
                  )}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>

        {/* Logout */}
        <div style={{ padding: '14px 20px', borderTop: '1px solid rgba(255,255,255,.06)' }}>
          <button
            onClick={() => { logout(); navigate('/login'); }}
            style={{
              width: '100%', padding: '8px 14px', background: 'rgba(255,255,255,.05)',
              color: '#64748B', border: '1px solid rgba(255,255,255,.07)', borderRadius: 8,
              cursor: 'pointer', fontSize: 12.5, fontWeight: 600,
              display: 'flex', alignItems: 'center', gap: 8, transition: 'all .15s',
            }}
          >
            <span style={{ fontSize: 13 }}>←</span>
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Topbar */}
        <header style={{
          height: 54, background: '#fff', borderBottom: '1px solid #E2E8F0',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0 28px', flexShrink: 0,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
            <span style={{ color: '#94A3B8', fontSize: 12 }}>Admin</span>
            <span style={{ color: '#CBD5E1', fontSize: 14 }}>›</span>
            <span style={{ fontWeight: 700, color: '#0F172A', fontSize: 13.5 }}>{breadcrumb}</span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {/* Quick stats pill */}
            {crisisCount > 0 && (
              <button
                onClick={() => navigate('/cases?filter=crisis')}
                style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px', background: '#FEF2F2', border: '1px solid #FECACA', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontWeight: 700, color: '#DC2626' }}
              >
                ● {crisisCount} CRISIS
              </button>
            )}

            {/* Notifications */}
            <button
              style={{ position: 'relative', background: 'none', border: '1px solid #E2E8F0', borderRadius: 8, cursor: 'pointer', padding: '6px 10px', color: '#64748B', fontSize: 14 }}
              onClick={() => navigate('/cases')}
              title="Notifications"
            >
              ◷
              {showNotifDot && (
                <span style={{ position: 'absolute', top: 4, right: 4, width: 7, height: 7, borderRadius: '50%', background: '#EF4444', border: '1.5px solid #fff' }} />
              )}
            </button>

            {/* Refresh */}
            <button
              onClick={() => window.location.reload()}
              style={{ padding: '6px 12px', background: '#F1F5F9', border: '1px solid #E2E8F0', borderRadius: 8, cursor: 'pointer', fontSize: 12.5, color: '#475569', fontWeight: 500 }}
            >
              Refresh
            </button>

            {/* User avatar */}
            {user && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 10px', background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 8 }}>
                <div style={{ width: 26, height: 26, borderRadius: '50%', background: '#2563EB', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 10.5, color: '#fff' }}>
                  {getInitials(user.name)}
                </div>
                <span style={{ fontSize: 12.5, fontWeight: 600, color: '#374151' }}>{user.name.split(' ')[0]}</span>
              </div>
            )}
          </div>
        </header>

        {/* Crisis banner */}
        {crisisCount > 0 && (
          <div
            onClick={() => navigate('/cases?filter=crisis')}
            style={{
              background: '#DC2626', color: '#fff',
              padding: '9px 28px', display: 'flex', alignItems: 'center', gap: 12,
              fontSize: 13, fontWeight: 700, cursor: 'pointer', flexShrink: 0,
              letterSpacing: '-0.01em',
            }}
          >
            <span style={{ fontSize: 16 }}>!</span>
            {crisisCount} ACTIVE CRISIS CASE{crisisCount > 1 ? 'S' : ''} — Immediate attention required
            <span style={{ marginLeft: 'auto', fontSize: 12, opacity: 0.85 }}>Click to review →</span>
          </div>
        )}

        {/* Page content */}
        <main style={{ flex: 1, overflowY: 'auto' }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
