import { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';

const STATUS_STYLE = {
  pending:  { bg: '#FEF3C7', color: '#D97706', label: 'Pending' },
  assigned: { bg: '#EFF6FF', color: '#2563EB', label: 'Assigned' },
  reviewed: { bg: '#ECFDF5', color: '#059669', label: 'Responded' },
  closed:   { bg: '#F1F5F9', color: '#64748B', label: 'Closed' },
};
const PRIORITY_STYLE = {
  low:      { bg: '#F0FDF4', color: '#166534', borderColor: '#059669' },
  moderate: { bg: '#FFFBEB', color: '#92400E', borderColor: '#D97706' },
  high:     { bg: '#FEF2F2', color: '#991B1B', borderColor: '#DC2626' },
};

export default function AdminRaiseConcern() {
  const { apiFetch, toast } = useApp();
  const [concerns, setConcerns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('pending');
  const [responding, setResponding] = useState(null);
  const [response, setResponse] = useState('');
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try { setConcerns(await apiFetch('/concerns')); }
    catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const updateConcern = async (id, status, resp) => {
    setSaving(true);
    try {
      await apiFetch(`/concerns/${id}`, { method: 'PATCH', body: JSON.stringify({ status, response: resp }) });
      toast('Concern updated');
      setResponding(null);
      setResponse('');
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setSaving(false); }
  };

  const filtered = filter === 'all' ? concerns : concerns.filter(c => c.status === filter);
  const counts = {
    all:      concerns.length,
    pending:  concerns.filter(c => c.status === 'pending').length,
    reviewed: concerns.filter(c => c.status === 'reviewed').length,
    closed:   concerns.filter(c => c.status === 'closed').length,
  };

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Student Concerns</h1>
        <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Review and respond to issues raised by students</div>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 20 }}>
        {[
          { label: 'Pending',   val: counts.pending,  color: '#D97706', bg: '#FFFBEB' },
          { label: 'Responded', val: counts.reviewed, color: '#059669', bg: '#ECFDF5' },
          { label: 'Closed',    val: counts.closed,   color: '#64748B', bg: '#F1F5F9' },
          { label: 'Total',     val: counts.all,      color: '#2563EB', bg: '#EFF6FF' },
        ].map(s => (
          <div key={s.label} style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, padding: '14px 18px' }}>
            <div style={{ fontSize: 11.5, color: '#94A3B8', fontWeight: 600, marginBottom: 6 }}>{s.label}</div>
            <div style={{ fontSize: 26, fontWeight: 800, color: s.color, letterSpacing: '-0.02em' }}>{s.val}</div>
          </div>
        ))}
      </div>

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, background: '#F8FAFC', padding: '4px', borderRadius: 9, width: 'fit-content', border: '1px solid #E2E8F0' }}>
        {['pending', 'reviewed', 'closed', 'all'].map(s => (
          <button
            key={s} onClick={() => setFilter(s)}
            style={{
              padding: '6px 14px', borderRadius: 7, border: 'none', cursor: 'pointer',
              fontWeight: 600, fontSize: 12.5,
              background: filter === s ? '#fff' : 'transparent',
              color: filter === s ? '#0F172A' : '#64748B',
              boxShadow: filter === s ? '0 1px 4px rgba(0,0,0,.08)' : 'none',
              display: 'flex', alignItems: 'center', gap: 6,
            }}
          >
            {s.charAt(0).toUpperCase() + s.slice(1)}
            <span style={{ fontSize: 10.5, background: '#E2E8F0', color: '#64748B', padding: '1px 6px', borderRadius: 9, fontWeight: 700 }}>
              {counts[s] ?? counts.all}
            </span>
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ padding: 40, color: '#94A3B8', fontSize: 13, textAlign: 'center' }}>Loading concerns...</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#94A3B8' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>—</div>
          <div style={{ fontWeight: 600, fontSize: 14 }}>No {filter} concerns</div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filtered.map(c => {
            const ss = STATUS_STYLE[c.status] || STATUS_STYLE.pending;
            const ps = PRIORITY_STYLE[c.priority] || PRIORITY_STYLE.moderate;
            return (
              <div key={c.id} style={{
                background: '#fff', border: '1px solid #E2E8F0',
                borderLeft: `4px solid ${ps.borderColor}`, borderRadius: 10,
              }}>
                <div style={{ padding: '16px 20px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6, flexWrap: 'wrap' }}>
                        <span style={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>
                          {c.anonymous ? 'Anonymous Student' : c.student_name}
                        </span>
                        {!c.anonymous && <span style={{ fontSize: 12, color: '#94A3B8' }}>{c.s_id}</span>}
                        <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 600, background: ps.bg, color: ps.color }}>
                          {c.priority} priority
                        </span>
                        <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 600, background: ss.bg, color: ss.color }}>
                          {ss.label}
                        </span>
                      </div>
                      <div style={{ fontWeight: 700, fontSize: 13.5, color: '#0F172A', marginBottom: 5 }}>{c.type}</div>
                      <div style={{ fontSize: 13, color: '#374151', lineHeight: 1.5 }}>{c.description}</div>
                    </div>
                    <div style={{ fontSize: 11.5, color: '#94A3B8', flexShrink: 0, marginLeft: 16 }}>
                      {c.created_at ? new Date(c.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) : ''}
                    </div>
                  </div>

                  {/* SLA indicator */}
                  {c.sla_due_at && c.status === 'pending' && (
                    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '3px 10px', background: '#FEF2F2', border: '1px solid #FECACA', borderRadius: 6, fontSize: 11.5, color: '#DC2626', fontWeight: 600, marginBottom: 8 }}>
                      SLA: {new Date(c.sla_due_at).toLocaleString('en-IN', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' })}
                    </div>
                  )}

                  {/* Existing response */}
                  {c.response && (
                    <div style={{ padding: '10px 14px', background: '#F0FDF4', border: '1px solid #A7F3D0', borderRadius: 8, marginTop: 10 }}>
                      <div style={{ fontSize: 11.5, fontWeight: 700, color: '#059669', marginBottom: 3, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Response</div>
                      <div style={{ fontSize: 13, color: '#374151', lineHeight: 1.5 }}>{c.response}</div>
                    </div>
                  )}

                  {/* Respond / close actions */}
                  {c.status !== 'closed' && (
                    <div style={{ marginTop: 12 }}>
                      {responding === c.id ? (
                        <div>
                          <textarea
                            value={response} onChange={e => setResponse(e.target.value)}
                            rows={3} placeholder="Type your response to this concern..."
                            style={{ width: '100%', padding: '9px 12px', borderRadius: 8, border: '1.5px solid #E2E8F0', fontSize: 13, resize: 'vertical', boxSizing: 'border-box', marginBottom: 10, lineHeight: 1.5 }}
                          />
                          <div style={{ display: 'flex', gap: 8 }}>
                            <button
                              onClick={() => updateConcern(c.id, 'reviewed', response)} disabled={saving || !response.trim()}
                              style={{ padding: '7px 16px', background: '#059669', color: '#fff', border: 'none', borderRadius: 7, fontSize: 12.5, fontWeight: 600, cursor: 'pointer' }}
                            >
                              {saving ? '...' : 'Send Response'}
                            </button>
                            <button
                              onClick={() => updateConcern(c.id, 'closed', response)} disabled={saving}
                              style={{ padding: '7px 14px', background: '#F1F5F9', color: '#475569', border: '1px solid #E2E8F0', borderRadius: 7, fontSize: 12.5, fontWeight: 600, cursor: 'pointer' }}
                            >
                              Close Concern
                            </button>
                            <button onClick={() => { setResponding(null); setResponse(''); }} style={{ padding: '7px 14px', background: '#fff', color: '#64748B', border: '1px solid #E2E8F0', borderRadius: 7, fontSize: 12.5, cursor: 'pointer' }}>
                              Cancel
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          onClick={() => { setResponding(c.id); setResponse(c.response || ''); }}
                          style={{ padding: '7px 14px', background: '#EFF6FF', color: '#2563EB', border: '1px solid #BFDBFE', borderRadius: 7, fontSize: 12.5, fontWeight: 600, cursor: 'pointer' }}
                        >
                          {c.response ? 'Edit Response' : 'Respond'}
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
