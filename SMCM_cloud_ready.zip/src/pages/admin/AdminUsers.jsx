import { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';

const ALL_PERMISSIONS = [
  { scope: 'queue.view', label: 'View Queue', category: 'Clinical' },
  { scope: 'walkin.write', label: 'Register Walk-ins', category: 'Clinical' },
  { scope: 'consultation.write', label: 'Write Consultations', category: 'Clinical' },
  { scope: 'records.read', label: 'Read Health Records', category: 'Clinical' },
  { scope: 'records.write', label: 'Write Health Records', category: 'Clinical' },
  { scope: 'appointments.write', label: 'Manage Appointments', category: 'Clinical' },
  { scope: 'certificate.issue', label: 'Issue Certificates', category: 'Certificates' },
  { scope: 'counselling.read', label: 'Read Counselling Cases', category: 'Counselling' },
  { scope: 'counselling.write', label: 'Write Counselling Cases', category: 'Counselling' },
  { scope: 'welfare.respond', label: 'Respond to Concerns', category: 'Welfare' },
  { scope: 'welfare.unmask', label: 'Unmask Anonymous Concerns', category: 'Welfare' },
  { scope: 'crisis.resolve', label: 'Resolve Crisis Cases', category: 'Crisis' },
  { scope: 'reports.view', label: 'View Reports & Analytics', category: 'Reports' },
  { scope: 'masters.write', label: 'Edit Master Data', category: 'System' },
  { scope: 'settings.write', label: 'Modify System Settings', category: 'System' },
];

const PRESETS = {
  'Super Admin': ALL_PERMISSIONS.map(p => p.scope),
  'Front Desk':  ['queue.view','walkin.write','records.read','appointments.write'],
  'Doctor':      ['queue.view','consultation.write','records.read','records.write','certificate.issue','walkin.write'],
  'Counsellor':  ['counselling.read','counselling.write','welfare.respond','crisis.resolve'],
  'Reports Viewer': ['reports.view'],
};

const CATEGORIES = [...new Set(ALL_PERMISSIONS.map(p => p.category))];

export default function AdminUsers() {
  const { apiFetch, toast } = useApp();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState(null);
  const [pendingPerms, setPendingPerms] = useState({});
  const [saving, setSaving] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiFetch('/admin/users');
      setUsers(data);
      const permsMap = {};
      data.forEach(u => { permsMap[u.id] = u.permissions || []; });
      setPendingPerms(permsMap);
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setLoading(false);
    }
  }, [apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const togglePerm = (userId, scope) => {
    setPendingPerms(prev => {
      const cur = prev[userId] || [];
      return {
        ...prev,
        [userId]: cur.includes(scope) ? cur.filter(x => x !== scope) : [...cur, scope],
      };
    });
  };

  const applyPreset = (userId, preset) => {
    setPendingPerms(prev => ({ ...prev, [userId]: [...PRESETS[preset]] }));
  };

  const saveUser = async (userId) => {
    setSaving(userId);
    try {
      await apiFetch(`/admin/users/${userId}`, { method: 'PATCH', body: JSON.stringify({ permissions: pendingPerms[userId] }) });
      toast('Permissions saved');
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setSaving(null); }
  };

  return (
    <div style={{ padding: '24px 28px', maxWidth: 900 }}>
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0 }}>Admin Users & Permissions</h1>
        <div style={{ color: '#6B7280', fontSize: 12.5, marginTop: 4 }}>Manage admin accounts and permission sets</div>
      </div>

      {loading ? (
        <div style={{ color: '#6B7280' }}>Loading users…</div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {users.map(u => {
            const isOpen = expandedId === u.id;
            const perms = pendingPerms[u.id] || [];
            return (
              <div key={u.id} style={{ background: '#fff', border: '1px solid #E5E7EB', borderRadius: 10, overflow: 'hidden' }}>
                {/* Row */}
                <div style={{ padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer' }} onClick={() => setExpandedId(isOpen ? null : u.id)}>
                  <div style={{ width: 38, height: 38, borderRadius: '50%', background: '#7C1D1D', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13, flexShrink: 0 }}>
                    {u.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>{u.name}</div>
                    <div style={{ fontSize: 12, color: '#6B7280' }}>{u.email} · {perms.length} permission{perms.length !== 1 ? 's' : ''}</div>
                  </div>
                  <span style={{ fontSize: 13, color: '#9CA3AF' }}>{isOpen ? '▲' : '▼'}</span>
                </div>

                {/* Expanded permissions */}
                {isOpen && (
                  <div style={{ borderTop: '1px solid #F1F5F9', padding: '16px 18px' }}>
                    {/* Presets */}
                    <div style={{ marginBottom: 14 }}>
                      <div style={{ fontSize: 12, fontWeight: 700, color: '#374151', marginBottom: 8 }}>Quick Presets</div>
                      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                        {Object.keys(PRESETS).map(preset => (
                          <button key={preset} onClick={() => applyPreset(u.id, preset)}
                            style={{ padding: '5px 12px', background: '#F1F5F9', color: '#374151', border: '1px solid #E5E7EB', borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
                            {preset}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Permissions by category */}
                    {CATEGORIES.map(cat => (
                      <div key={cat} style={{ marginBottom: 12 }}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>{cat}</div>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                          {ALL_PERMISSIONS.filter(p => p.category === cat).map(p => {
                            const active = perms.includes(p.scope);
                            return (
                              <button key={p.scope} onClick={() => togglePerm(u.id, p.scope)}
                                style={{ padding: '5px 12px', borderRadius: 6, border: `1.5px solid ${active ? '#EF4444' : '#E5E7EB'}`, background: active ? '#FEF2F2' : '#F8FAFC', color: active ? '#DC2626' : '#6B7280', fontSize: 12, fontWeight: active ? 700 : 400, cursor: 'pointer' }}>
                                {active ? '✓ ' : ''}{p.label}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}

                    <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
                      <button onClick={() => saveUser(u.id)} disabled={saving === u.id}
                        style={{ padding: '9px 20px', background: '#EF4444', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
                        {saving === u.id ? 'Saving…' : 'Save Permissions'}
                      </button>
                      <button onClick={() => setPendingPerms(prev => ({ ...prev, [u.id]: u.permissions || [] }))}
                        style={{ padding: '9px 20px', background: '#F3F4F6', color: '#374151', border: 'none', borderRadius: 8, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>
                        Reset
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
