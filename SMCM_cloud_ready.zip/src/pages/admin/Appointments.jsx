import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const STATUS_STYLE = {
  upcoming:    { bg: '#EFF6FF', color: '#2563EB' },
  in_progress: { bg: '#FFFBEB', color: '#D97706' },
  completed:   { bg: '#D1FAE5', color: '#059669' },
  cancelled:   { bg: '#F3F4F6', color: '#6B7280' },
};

export default function Appointments() {
  const { apiFetch, toast } = useApp();
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try { setAppointments(await apiFetch('/appointments')); }
    catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const updateStatus = async (id, status) => {
    try {
      await apiFetch(`/appointments/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) });
      toast('Status updated');
      load();
    } catch (e) { toast(e.message, 'error'); }
  };

  let filtered = appointments;
  if (filter !== 'all') filtered = filtered.filter(a => a.status === filter);
  if (search) filtered = filtered.filter(a => a.student_name?.toLowerCase().includes(search.toLowerCase()) || a.service?.toLowerCase().includes(search.toLowerCase()));

  const counts = { all: appointments.length, upcoming: appointments.filter(a => a.status === 'upcoming').length, in_progress: appointments.filter(a => a.status === 'in_progress').length, completed: appointments.filter(a => a.status === 'completed').length, cancelled: appointments.filter(a => a.status === 'cancelled').length };

  return (
    <div style={{ padding: '24px 28px', maxWidth: 1100 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0 }}>All Appointments</h1>
          <div style={{ color: '#6B7280', fontSize: 12.5, marginTop: 4 }}>Manage and review all student appointments</div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 12, marginBottom: 18, alignItems: 'center' }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by student or service…"
          style={{ padding: '8px 14px', borderRadius: 8, border: '1.5px solid #D1D5DB', fontSize: 13, width: 240 }} />
        <div style={{ display: 'flex', gap: 6, background: '#F8FAFC', padding: 4, borderRadius: 8 }}>
          {['all', 'upcoming', 'in_progress', 'completed', 'cancelled'].map(s => (
            <button key={s} onClick={() => setFilter(s)} style={{ padding: '5px 12px', borderRadius: 6, border: 'none', cursor: 'pointer', fontWeight: 600, fontSize: 12, background: filter === s ? '#fff' : 'transparent', color: filter === s ? '#0F172A' : '#6B7280', boxShadow: filter === s ? '0 1px 3px rgba(0,0,0,.07)' : 'none' }}>
              {s === 'in_progress' ? 'In Progress' : s.charAt(0).toUpperCase() + s.slice(1)} <span style={{ marginLeft: 3, fontSize: 10.5, background: '#E5E7EB', padding: '1px 5px', borderRadius: 8 }}>{counts[s]}</span>
            </button>
          ))}
        </div>
      </div>

      {loading ? <div style={{ color: '#6B7280' }}>Loading…</div> : filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px 0', color: '#9CA3AF' }}>No appointments found</div>
      ) : (
        <div style={{ background: '#fff', border: '1px solid #E5E7EB', borderRadius: 10, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#F8FAFC', borderBottom: '1px solid #E5E7EB' }}>
                {['Student', 'Service', 'Health Centre', 'Doctor', 'Date & Time', 'Status', 'Actions'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 12, fontWeight: 700, color: '#6B7280', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(a => {
                const ss = STATUS_STYLE[a.status] || STATUS_STYLE.upcoming;
                return (
                  <tr key={a.id} style={{ borderBottom: '1px solid #F1F5F9' }}>
                    <td style={{ padding: '12px 16px' }}>
                      <div style={{ fontWeight: 600, fontSize: 13 }}>{a.student_name}</div>
                      <div style={{ fontSize: 11.5, color: '#6B7280' }}>{a.s_id}</div>
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: 13, color: '#374151' }}>{a.service}</td>
                    <td style={{ padding: '12px 16px', fontSize: 12.5, color: '#6B7280' }}>{a.health_centre}</td>
                    <td style={{ padding: '12px 16px', fontSize: 12.5, color: '#374151' }}>{a.doctor}</td>
                    <td style={{ padding: '12px 16px', fontSize: 12.5, color: '#374151' }}>{a.date}<br /><span style={{ color: '#9CA3AF', fontSize: 11.5 }}>{a.time}</span></td>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ padding: '3px 10px', borderRadius: 10, fontSize: 11.5, fontWeight: 600, background: ss.bg, color: ss.color }}>{a.status}</span>
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button onClick={() => navigate(`/consultation/${a.id}`)} style={{ padding: '4px 10px', background: '#EFF6FF', color: '#2563EB', border: 'none', borderRadius: 6, fontSize: 11.5, cursor: 'pointer', fontWeight: 600 }}>Consult</button>
                        {a.status === 'upcoming' && <button onClick={() => updateStatus(a.id, 'completed')} style={{ padding: '4px 10px', background: '#ECFDF5', color: '#059669', border: 'none', borderRadius: 6, fontSize: 11.5, cursor: 'pointer', fontWeight: 600 }}>Done</button>}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
