import { useState, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { urgencyColor, urgencyLabel, urgencyBg, urgencyText } from '../../utils/urgency';

const STATUS_STYLE = {
  triaged:          { bg: '#EFF6FF', color: '#2563EB', label: 'Triaged' },
  escalated:        { bg: '#FEF2F2', color: '#DC2626', label: 'Escalated' },
  in_consultation:  { bg: '#FFFBEB', color: '#D97706', label: 'In Consultation' },
  follow_up_pending:{ bg: '#F5F3FF', color: '#7C3AED', label: 'Follow-up Pending' },
  closed:           { bg: '#ECFDF5', color: '#059669', label: 'Closed' },
  archived:         { bg: '#F1F5F9', color: '#64748B', label: 'Archived' },
};

const CATEGORY_LABELS = {
  unwell: 'Physical Health', mental_health: 'Mental Health',
  certificate: 'Certificate', followup: 'Follow-up', crisis: 'Crisis', general: 'General',
};

const STATUSES = ['triaged','escalated','in_consultation','follow_up_pending','closed','archived'];

export default function Cases() {
  const { apiFetch, toast } = useApp();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState(searchParams.get('filter') || 'all');
  const [expandedId, setExpandedId] = useState(null);
  const [noteText, setNoteText] = useState('');
  const [savingNote, setSavingNote] = useState(false);
  const [crisisModal, setCrisisModal] = useState(null);
  const [reviewSummary, setReviewSummary] = useState('');
  const [resolvingCrisis, setResolvingCrisis] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try { setCases(await apiFetch('/cases')); }
    catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const crisisCases = cases.filter(c => c.crisis && !['closed','archived'].includes(c.current_status));

  const filtered = cases.filter(c => {
    if (activeFilter === 'open') return !['closed','archived'].includes(c.current_status);
    if (activeFilter === 'urgent') return (c.urgency || 1) >= 2;
    if (activeFilter === 'crisis') return c.crisis;
    if (activeFilter === 'closed') return ['closed','archived'].includes(c.current_status);
    return true;
  });

  const updateStatus = async (id, current_status) => {
    try {
      await apiFetch(`/cases/${id}`, { method: 'PATCH', body: JSON.stringify({ current_status }) });
      toast('Status updated');
      load();
    } catch (e) { toast(e.message, 'error'); }
  };

  const saveNote = async (id) => {
    if (!noteText.trim()) return;
    setSavingNote(true);
    try {
      await apiFetch(`/cases/${id}`, { method: 'PATCH', body: JSON.stringify({ admin_note: noteText }) });
      toast('Note saved');
      setNoteText('');
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setSavingNote(false); }
  };

  const resolveCrisis = async () => {
    if (!reviewSummary.trim()) { toast('Review summary is required', 'error'); return; }
    setResolvingCrisis(true);
    try {
      await apiFetch(`/crisis/${crisisModal}/resolve`, { method: 'POST', body: JSON.stringify({ review_summary: reviewSummary }) });
      toast('Crisis resolved');
      setCrisisModal(null);
      setReviewSummary('');
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setResolvingCrisis(false); }
  };

  const TABS = [
    { id: 'all',    label: 'All',      count: cases.length },
    { id: 'open',   label: 'Open',     count: cases.filter(c => !['closed','archived'].includes(c.current_status)).length },
    { id: 'urgent', label: 'Urgent',   count: cases.filter(c => (c.urgency||1) >= 2).length },
    { id: 'crisis', label: 'Crisis',   count: crisisCases.length },
    { id: 'closed', label: 'Closed',   count: cases.filter(c => ['closed','archived'].includes(c.current_status)).length },
  ];

  const inputStyle = { width: '100%', padding: '8px 11px', borderRadius: 7, border: '1.5px solid #E2E8F0', fontSize: 12.5, boxSizing: 'border-box', background: '#fff', outline: 'none' };

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Care Cases</h1>
        <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Student care requests, triage outcomes and case management</div>
      </div>

      {/* Crisis banner */}
      {crisisCases.length > 0 && (
        <div
          onClick={() => setActiveFilter('crisis')}
          style={{ background: '#DC2626', color: '#fff', borderRadius: 10, padding: '12px 20px', marginBottom: 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer' }}
        >
          <div>
            <div style={{ fontWeight: 800, fontSize: 13.5 }}>
              {crisisCases.length} Active Crisis Case{crisisCases.length > 1 ? 's' : ''}
            </div>
            <div style={{ fontSize: 12, opacity: 0.85, marginTop: 2 }}>Immediate attention required</div>
          </div>
          <span style={{ fontSize: 12, fontWeight: 600, opacity: 0.9 }}>View →</span>
        </div>
      )}

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 18, background: '#F1F5F9', borderRadius: 10, padding: 4 }}>
        {TABS.map(tab => (
          <button
            key={tab.id} onClick={() => setActiveFilter(tab.id)}
            style={{
              flex: 1, padding: '7px 10px', borderRadius: 7, border: 'none', fontWeight: 600, fontSize: 12.5,
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              background: activeFilter === tab.id ? '#fff' : 'transparent',
              color: activeFilter === tab.id ? '#0F172A' : '#64748B',
              boxShadow: activeFilter === tab.id ? '0 1px 3px rgba(0,0,0,.08)' : 'none',
            }}
          >
            {tab.label}
            {tab.count > 0 && (
              <span style={{
                background: tab.id === 'crisis' ? '#DC2626' : '#E2E8F0',
                color: tab.id === 'crisis' ? '#fff' : '#374151',
                borderRadius: 10, padding: '1px 6px', fontSize: 10, fontWeight: 700,
              }}>
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ padding: 40, color: '#94A3B8', fontSize: 13, textAlign: 'center' }}>Loading cases...</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#94A3B8' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>—</div>
          <div style={{ fontWeight: 600, fontSize: 14 }}>No {activeFilter} cases</div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {filtered.map(c => {
            const uColor = urgencyColor(c.urgency);
            const catLabel = CATEGORY_LABELS[c.intake_summary?.intake_category] || 'General';
            const isOpen = expandedId === c.id;
            const ss = STATUS_STYLE[c.current_status] || STATUS_STYLE.triaged;

            return (
              <div key={c.id} style={{
                background: '#fff', border: '1px solid #E2E8F0',
                borderLeft: `4px solid ${c.crisis ? '#DC2626' : uColor}`,
                borderRadius: 10, overflow: 'hidden',
              }}>
                {/* Row */}
                <div
                  style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer' }}
                  onClick={() => setExpandedId(isOpen ? null : c.id)}
                >
                  <div style={{ width: 10, height: 10, borderRadius: '50%', background: c.crisis ? '#DC2626' : uColor, flexShrink: 0 }} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', marginBottom: 4 }}>
                      <span style={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>{c.student_name || 'Student'}</span>
                      <span style={{ fontSize: 12, color: '#94A3B8' }}>{c.s_id}</span>
                      <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 600, background: ss.bg, color: ss.color }}>{ss.label}</span>
                      {c.crisis && <span style={{ padding: '2px 9px', borderRadius: 20, background: '#7F1D1D', color: '#FEF2F2', fontSize: 10, fontWeight: 700 }}>CRISIS</span>}
                    </div>
                    <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
                      <span style={{ fontSize: 12, color: '#374151' }}>{catLabel}</span>
                      <span style={{ fontSize: 12, color: uColor, fontWeight: 600 }}>{urgencyLabel(c.urgency)} priority</span>
                      <span style={{ fontSize: 12, color: '#94A3B8' }}>Case #{c.id} · {new Date(c.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</span>
                    </div>
                  </div>
                  <span style={{ fontSize: 12, color: '#CBD5E1' }}>{isOpen ? '▲' : '▼'}</span>
                </div>

                {/* Expanded panel */}
                {isOpen && (
                  <div style={{ borderTop: '1px solid #F1F5F9', padding: '18px 20px', background: '#F8FAFC' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 16 }}>
                      {/* Timeline */}
                      <div>
                        <div style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }}>Case Timeline</div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxHeight: 200, overflowY: 'auto' }}>
                          {(c.timeline || []).length === 0 ? (
                            <div style={{ fontSize: 12.5, color: '#94A3B8' }}>No events recorded</div>
                          ) : (c.timeline || []).map((evt, i) => (
                            <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                              <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#CBD5E1', marginTop: 6, flexShrink: 0 }} />
                              <div>
                                <div style={{ fontSize: 12.5, color: '#374151', lineHeight: 1.4 }}>{evt.summary}</div>
                                <div style={{ fontSize: 11, color: '#94A3B8', marginTop: 2 }}>
                                  {new Date(evt.ts).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                                  {evt.actor && <span style={{ marginLeft: 4 }}>· {evt.actor}</span>}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Actions */}
                      <div>
                        <div style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }}>Actions</div>
                        <div style={{ marginBottom: 12 }}>
                          <label style={{ display: 'block', fontSize: 11.5, fontWeight: 600, color: '#64748B', marginBottom: 5 }}>Update Status</label>
                          <select
                            value={c.current_status}
                            onChange={e => updateStatus(c.id, e.target.value)}
                            style={inputStyle}
                          >
                            {STATUSES.map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
                          </select>
                        </div>
                        <div style={{ marginBottom: 10 }}>
                          <label style={{ display: 'block', fontSize: 11.5, fontWeight: 600, color: '#64748B', marginBottom: 5 }}>Add Internal Note</label>
                          <textarea
                            value={noteText} onChange={e => setNoteText(e.target.value)} rows={2}
                            placeholder="Add an internal note..."
                            style={{ ...inputStyle, resize: 'vertical', lineHeight: 1.5 }}
                          />
                        </div>
                        <div style={{ display: 'flex', gap: 8 }}>
                          <button
                            onClick={() => saveNote(c.id)} disabled={savingNote || !noteText.trim()}
                            style={{ padding: '7px 16px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 7, fontWeight: 600, fontSize: 12.5, cursor: 'pointer' }}
                          >
                            {savingNote ? 'Saving...' : 'Save Note'}
                          </button>
                          {c.crisis && (
                            <button
                              onClick={() => setCrisisModal(c.id)}
                              style={{ padding: '7px 16px', background: '#059669', color: '#fff', border: 'none', borderRadius: 7, fontWeight: 700, fontSize: 12.5, cursor: 'pointer' }}
                            >
                              Resolve Crisis
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Intake summary */}
                    {c.intake_summary && (
                      <div style={{ padding: '10px 14px', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 8, fontSize: 12.5, color: '#374151', lineHeight: 1.5 }}>
                        <strong style={{ color: '#0F172A' }}>Intake:</strong>{' '}
                        {c.intake_summary.intake_category || 'general'} · {c.intake_summary.urgency_self_mark || 'routine'} urgency
                        {c.intake_summary.free_text && ` · "${c.intake_summary.free_text}"`}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Crisis resolve modal */}
      {crisisModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,0.55)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 20 }}>
          <div style={{ background: '#fff', borderRadius: 12, width: '100%', maxWidth: 480, padding: '28px', boxShadow: '0 20px 60px rgba(0,0,0,0.2)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
              <div style={{ fontSize: 16, fontWeight: 800, color: '#0F172A', letterSpacing: '-0.02em' }}>Resolve Crisis Case #{crisisModal}</div>
              <button onClick={() => { setCrisisModal(null); setReviewSummary(''); }} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 20, color: '#94A3B8', lineHeight: 1 }}>×</button>
            </div>
            <div style={{ fontSize: 13, color: '#64748B', marginBottom: 18, lineHeight: 1.5 }}>
              Provide a review summary before resolving this crisis. This is logged in the audit trail.
            </div>
            <textarea
              value={reviewSummary} onChange={e => setReviewSummary(e.target.value)} rows={4} required
              placeholder="Describe: who was contacted, what support was provided, follow-up plan..."
              style={{ width: '100%', padding: '10px 14px', borderRadius: 8, border: '1.5px solid #E2E8F0', fontSize: 13, resize: 'vertical', boxSizing: 'border-box', marginBottom: 18, lineHeight: 1.5 }}
            />
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => { setCrisisModal(null); setReviewSummary(''); }} style={{ flex: 1, padding: '10px', background: '#F1F5F9', color: '#475569', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>Cancel</button>
              <button
                onClick={resolveCrisis} disabled={resolvingCrisis || !reviewSummary.trim()}
                style={{ flex: 1, padding: '10px', background: resolvingCrisis ? '#86EFAC' : '#059669', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, cursor: 'pointer' }}
              >
                {resolvingCrisis ? 'Resolving...' : 'Confirm Resolution'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
