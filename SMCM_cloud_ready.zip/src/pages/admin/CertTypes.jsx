import { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';

const EMPTY_FORM = { name: '', code: '', description: '', days_valid: '', requires_doctor: true, active: true };

const inputStyle = { width: '100%', padding: '9px 13px', borderRadius: 8, border: '1.5px solid #E2E8F0', fontSize: 13, boxSizing: 'border-box', background: '#fff', color: '#0F172A', outline: 'none' };
const labelStyle = { display: 'block', fontSize: 12, fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 5 };

export default function CertTypes() {
  const { apiFetch, toast } = useApp();
  const [types, setTypes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    try { setTypes(await apiFetch('/masters/certificate-types')); }
    catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const openNew  = () => { setEditItem(null); setForm(EMPTY_FORM); setShowModal(true); };
  const openEdit = (item) => { setEditItem(item); setForm({ ...item, days_valid: String(item.days_valid || '') }); setShowModal(true); };

  const save = async (e) => {
    e.preventDefault();
    if (!form.name) { toast('Name is required', 'error'); return; }
    setSubmitting(true);
    try {
      const payload = { ...form, days_valid: form.days_valid ? parseInt(form.days_valid) : null };
      if (editItem) {
        await apiFetch(`/masters/certificate-types/${editItem.id}`, { method: 'PATCH', body: JSON.stringify(payload) });
        toast('Certificate type updated');
      } else {
        await apiFetch('/masters/certificate-types', { method: 'POST', body: JSON.stringify(payload) });
        toast('Certificate type added');
      }
      setShowModal(false);
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setSubmitting(false); }
  };

  const remove = async (id, name) => {
    if (!window.confirm(`Delete "${name}"?`)) return;
    try {
      await apiFetch(`/masters/certificate-types/${id}`, { method: 'DELETE' });
      toast('Certificate type removed');
      load();
    } catch (e) { toast(e.message, 'error'); }
  };

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Certificate Types</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Configure certificates and documents issued by the health centre</div>
        </div>
        <button onClick={openNew} style={{ padding: '9px 18px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
          + Add Type
        </button>
      </div>

      {loading ? (
        <div style={{ color: '#94A3B8', fontSize: 13 }}>Loading...</div>
      ) : types.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '48px', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, color: '#94A3B8' }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 8 }}>No certificate types configured</div>
          <button onClick={openNew} style={{ padding: '8px 20px', background: '#059669', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600, fontSize: 13 }}>Add First</button>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))', gap: 14 }}>
          {types.map(ct => (
            <div key={ct.id} style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, padding: '18px 20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 8, background: '#EFF6FF', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#2563EB', fontWeight: 800, fontSize: 12 }}>
                    {ct.code || ct.name?.charAt(0) || 'C'}
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 13.5, color: '#0F172A' }}>{ct.name}</div>
                    <div style={{ fontSize: 11.5, color: '#94A3B8', marginTop: 1 }}>
                      Valid: {ct.days_valid === 365 ? '1 year' : ct.days_valid === 180 ? '6 months' : ct.days_valid === 90 ? '3 months' : ct.days_valid ? `${ct.days_valid} days` : 'No expiry'}
                    </div>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <button onClick={() => openEdit(ct)} style={{ padding: '4px 10px', background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 6, fontSize: 11.5, fontWeight: 600, cursor: 'pointer', color: '#374151' }}>Edit</button>
                  <button onClick={() => remove(ct.id, ct.name)} style={{ padding: '4px 10px', background: '#FEF2F2', border: '1px solid #FECACA', borderRadius: 6, fontSize: 11.5, fontWeight: 600, cursor: 'pointer', color: '#DC2626' }}>Del</button>
                </div>
              </div>
              {ct.description && <div style={{ fontSize: 12.5, color: '#64748B', marginBottom: 10, lineHeight: 1.4 }}>{ct.description}</div>}
              <div style={{ display: 'flex', gap: 6 }}>
                <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 700, background: ct.requires_doctor ? '#FFF1F2' : '#F5F3FF', color: ct.requires_doctor ? '#9F1239' : '#7C3AED' }}>
                  {ct.requires_doctor ? 'Doctor Required' : 'Counsellor OK'}
                </span>
                <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 700, background: ct.active !== 0 ? '#ECFDF5' : '#F1F5F9', color: ct.active !== 0 ? '#059669' : '#64748B' }}>
                  {ct.active !== 0 ? 'Active' : 'Inactive'}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 20 }}>
          <div style={{ background: '#fff', borderRadius: 14, width: '100%', maxWidth: 480, padding: '28px', boxShadow: '0 20px 60px rgba(0,0,0,.2)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 20 }}>
              <div style={{ fontSize: 17, fontWeight: 800, color: '#0F172A' }}>{editItem ? 'Edit Certificate Type' : 'Add Certificate Type'}</div>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', border: 'none', fontSize: 22, color: '#94A3B8', cursor: 'pointer', lineHeight: 1 }}>×</button>
            </div>
            <form onSubmit={save}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                <div>
                  <label style={labelStyle}>Name *</label>
                  <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required placeholder="e.g. Medical Certificate" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Code</label>
                  <input value={form.code || ''} onChange={e => setForm(f => ({ ...f, code: e.target.value }))} placeholder="e.g. MC" maxLength={6} style={inputStyle} />
                </div>
              </div>
              <div style={{ marginBottom: 14 }}>
                <label style={labelStyle}>Description</label>
                <input value={form.description || ''} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Brief description" style={inputStyle} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 20 }}>
                <div>
                  <label style={labelStyle}>Valid For (days)</label>
                  <input type="number" value={form.days_valid} onChange={e => setForm(f => ({ ...f, days_valid: e.target.value }))} placeholder="e.g. 2" min={1} style={inputStyle} />
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingTop: 20 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 13 }}>
                    <input type="checkbox" checked={form.requires_doctor} onChange={e => setForm(f => ({ ...f, requires_doctor: e.target.checked }))} />
                    Requires Doctor
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 13 }}>
                    <input type="checkbox" checked={form.active} onChange={e => setForm(f => ({ ...f, active: e.target.checked }))} />
                    Active
                  </label>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button type="button" onClick={() => setShowModal(false)} style={{ flex: 1, padding: '10px', background: '#F1F5F9', color: '#374151', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer', fontSize: 13 }}>Cancel</button>
                <button type="submit" disabled={submitting} style={{ flex: 2, padding: '10px', background: submitting ? '#93C5FD' : '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, cursor: submitting ? 'not-allowed' : 'pointer', fontSize: 13 }}>
                  {submitting ? 'Saving...' : editItem ? 'Save Changes' : 'Add Type'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
