import {
  BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis,
  Tooltip, ResponsiveContainer, Legend, LineChart, Line,
} from 'recharts';
import { useState } from 'react';
import { useApp } from '../../context/AppContext';

const MONTHLY_DATA = [
  { month: 'Jan', medical: 88,  counselling: 41, dental: 18 },
  { month: 'Feb', medical: 72,  counselling: 55, dental: 22 },
  { month: 'Mar', medical: 110, counselling: 48, dental: 30 },
  { month: 'Apr', medical: 98,  counselling: 63, dental: 25 },
];

const WEEKLY_DATA = [
  { day: 'Mon', medical: 24, counselling: 9, dental: 5 },
  { day: 'Tue', medical: 31, counselling: 14, dental: 8 },
  { day: 'Wed', medical: 18, counselling: 11, dental: 3 },
  { day: 'Thu', medical: 28, counselling: 16, dental: 7 },
  { day: 'Fri', medical: 22, counselling: 12, dental: 4 },
];

const CERT_ISSUED = [
  { name: 'Medical Certificate',  value: 42, color: '#2563EB' },
  { name: 'Return-to-Class Note', value: 31, color: '#7C3AED' },
  { name: 'Sports Clearance',     value: 14, color: '#0891B2' },
  { name: 'Referral Letter',      value: 9,  color: '#D97706' },
  { name: 'Fitness Certificate',  value: 7,  color: '#059669' },
];

const COMPLIANCE_ITEMS = [
  { area: 'Confidentiality Policy', status: 'compliant',    last: 'Jan 2026', next: 'Jan 2027' },
  { area: 'Emergency Protocol',     status: 'compliant',    last: 'Mar 2026', next: 'Mar 2027' },
  { area: 'Staff Certification',    status: 'compliant',    last: 'Feb 2026', next: 'Aug 2026' },
  { area: 'Pharmacy Records',       status: 'review-due',   last: 'Oct 2025', next: 'Apr 2026' },
  { area: 'Student Data Audit',     status: 'review-due',   last: 'Nov 2025', next: 'May 2026' },
  { area: 'Crisis Response Drill',  status: 'compliant',    last: 'Feb 2026', next: 'Aug 2026' },
];

const STATUS_MAP = {
  compliant:        { color: '#059669', bg: '#ECFDF5', label: 'Compliant' },
  'review-due':     { color: '#D97706', bg: '#FFFBEB', label: 'Review Due' },
  'non-compliant':  { color: '#DC2626', bg: '#FEF2F2', label: 'Non-Compliant' },
};

const KPI = [
  { label: 'Total Visits (Apr)',  value: '186',  color: '#2563EB', bg: '#EFF6FF',  trend: '+14%', up: true },
  { label: 'Avg Wait Time',       value: '12m',  color: '#7C3AED', bg: '#F5F3FF',  trend: '-3m',  up: false },
  { label: 'Certs Issued (Apr)',  value: '103',  color: '#0891B2', bg: '#ECFEFF',  trend: '+8%',  up: true },
  { label: 'Referrals Out',       value: '9',    color: '#D97706', bg: '#FFFBEB',  trend: null },
  { label: 'Crisis Incidents',    value: '4',    color: '#DC2626', bg: '#FEF2F2',  trend: '+2',   up: false },
  { label: 'Compliance Score',    value: '83%',  color: '#059669', bg: '#ECFDF5',  trend: '+5%',  up: true },
];

function Card({ children, style }) {
  return (
    <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, ...style }}>
      {children}
    </div>
  );
}

function CardHeader({ title, subtitle }) {
  return (
    <div style={{ padding: '14px 20px', borderBottom: '1px solid #F1F5F9', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <span style={{ fontWeight: 700, fontSize: 13, color: '#0F172A' }}>{title}</span>
      {subtitle && <span style={{ fontSize: 12, color: '#94A3B8' }}>{subtitle}</span>}
    </div>
  );
}

export default function Compliance() {
  const { toast } = useApp();

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Analytics & Reports</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Service metrics, usage trends and regulatory compliance</div>
        </div>
        <button
          onClick={() => toast('Generating PDF report...')}
          style={{ padding: '9px 18px', background: '#F1F5F9', color: '#475569', border: '1px solid #E2E8F0', borderRadius: 8, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}
        >
          Export Report
        </button>
      </div>

      {/* KPI grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6,1fr)', gap: 12, marginBottom: 24 }}>
        {KPI.map(k => (
          <div key={k.label} style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, padding: '14px 16px' }}>
            <div style={{ fontSize: 11, color: '#94A3B8', fontWeight: 600, marginBottom: 8, lineHeight: 1.3 }}>{k.label}</div>
            <div style={{ fontSize: 24, fontWeight: 800, color: k.color, letterSpacing: '-0.02em', marginBottom: 4 }}>{k.value}</div>
            {k.trend && (
              <div style={{ fontSize: 11, color: k.up ? '#059669' : '#DC2626', fontWeight: 600 }}>
                {k.up ? '▲' : '▼'} {k.trend}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        {/* Monthly bar chart */}
        <Card>
          <CardHeader title="Monthly Visit Breakdown" subtitle="Medical · Counselling · Dental" />
          <div style={{ padding: '16px 20px 20px', height: 240 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={MONTHLY_DATA} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #E2E8F0', boxShadow: '0 4px 12px rgba(0,0,0,.08)' }} />
                <Legend iconType="square" iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="medical"     name="Medical"     fill="#2563EB" radius={[3,3,0,0]} />
                <Bar dataKey="counselling" name="Counselling" fill="#7C3AED" radius={[3,3,0,0]} />
                <Bar dataKey="dental"      name="Dental"      fill="#0891B2" radius={[3,3,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Cert pie chart */}
        <Card>
          <CardHeader title="Certificates Issued by Type" />
          <div style={{ padding: '16px 20px 20px', height: 240 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={CERT_ISSUED} cx="50%" cy="50%" outerRadius={80} paddingAngle={3} dataKey="value">
                  {CERT_ISSUED.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #E2E8F0' }} formatter={(v, n) => [`${v} issued`, n]} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11 }} formatter={v => <span style={{ fontSize: 11 }}>{v}</span>} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      {/* Weekly line chart */}
      <Card style={{ marginBottom: 16 }}>
        <CardHeader title="This Week — Daily Volume" subtitle="Last 5 working days" />
        <div style={{ padding: '16px 20px 20px', height: 210 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={WEEKLY_DATA} margin={{ top: 4, right: 16, left: -16, bottom: 0 }}>
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #E2E8F0' }} />
              <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11 }} />
              <Line type="monotone" dataKey="medical"     name="Medical"     stroke="#2563EB" strokeWidth={2} dot={{ r: 3, fill: '#2563EB' }} />
              <Line type="monotone" dataKey="counselling" name="Counselling" stroke="#7C3AED" strokeWidth={2} dot={{ r: 3, fill: '#7C3AED' }} />
              <Line type="monotone" dataKey="dental"      name="Dental"      stroke="#0891B2" strokeWidth={2} dot={{ r: 3, fill: '#0891B2' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>

      {/* Compliance checklist */}
      <Card>
        <CardHeader
          title="Regulatory Compliance"
          subtitle={`${COMPLIANCE_ITEMS.filter(c => c.status === 'compliant').length}/${COMPLIANCE_ITEMS.length} areas compliant`}
        />
        <div>
          {/* Table header */}
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1.2fr 1fr 1fr 1.5fr', gap: 12, padding: '10px 20px', background: '#F8FAFC', borderBottom: '1px solid #E2E8F0' }}>
            {['Compliance Area','Status','Last Reviewed','Next Due','Action'].map(h => (
              <div key={h} style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{h}</div>
            ))}
          </div>
          {COMPLIANCE_ITEMS.map((item, i) => {
            const sm = STATUS_MAP[item.status];
            return (
              <div key={i} style={{ display: 'grid', gridTemplateColumns: '2fr 1.2fr 1fr 1fr 1.5fr', gap: 12, padding: '12px 20px', borderBottom: i < COMPLIANCE_ITEMS.length - 1 ? '1px solid #F1F5F9' : 'none', alignItems: 'center' }}>
                <div style={{ fontWeight: 600, fontSize: 13, color: '#0F172A' }}>{item.area}</div>
                <div>
                  <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 600, background: sm.bg, color: sm.color }}>{sm.label}</span>
                </div>
                <div style={{ fontSize: 12.5, color: '#64748B' }}>{item.last}</div>
                <div style={{ fontSize: 12.5, color: item.status !== 'compliant' ? '#DC2626' : '#94A3B8', fontWeight: item.status !== 'compliant' ? 700 : 400 }}>{item.next}</div>
                <div>
                  <button
                    onClick={() => toast(`${item.area} marked as reviewed.`)}
                    style={{ padding: '5px 12px', background: '#F1F5F9', color: '#475569', border: '1px solid #E2E8F0', borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}
                  >
                    Mark Reviewed
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
