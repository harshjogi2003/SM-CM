import { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';

const SEVERITY_MAP = {
  high:     { color: '#DC2626', bg: '#FEF2F2', border: '#FECACA', label: 'High Priority' },
  moderate: { color: '#D97706', bg: '#FFFBEB', border: '#FDE68A', label: 'Moderate' },
  low:      { color: '#059669', bg: '#ECFDF5', border: '#A7F3D0', label: 'Low' },
};

const EMPTY_FORM = { name: '', icon: '', severity: 'moderate', auto_alert: false, description: '', active: true };
const inputStyle = { width: '100%', padding: '9px 13px', borderRadius: 8, border: '1.5px solid #E2E8F0', fontSize: 13, boxSizing: 'border-box', background: '#fff', color: '#0F172A', outline: 'none' };
const labelStyle = { display: 'block', fontSize: 12, fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 5 };

export default function ConcernTypes() {
  const { apiFetch, toast } = useApp();
  const [types, setTypes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    try { setTypes(await apiFetch('/masters/concern-categories')); }
    catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const openNew  = () => { setEditItem(null); setForm(EMPTY_FORM); setShowModal(true); };
  const openEdit = (item) => { setEditItem(item); setForm({ ...item }); setShowModal(true); };

  const save = async (e) => {
    e.preventDefault();
    if (!form.name) { toast('Name is required', 'error'); return; }
    setSubmitting(true);
    try {
      if (editItem) {
        await apiFetch(`/masters/concern-categories/${editItem.id}`, { method: 'PATCH', body: JSON.stringify(form) });
        toast('Concern category updated');
      } else {
        await apiFetch('/masters/concern-categories', { method: 'POST', body: JSON.stringify(form) });
        toast('Concern category added');
      }
      setShowModal(false);
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setSubmitting(false); }
  };

  const remove = async (id, name) => {
    if (!window.confirm(`Delete "${name}"?`)) return;
    try {
      await apiFetch(`/masters/concern-categories/${id}`, { method: 'DELETE' });
      toast('Concern category removed');
      load();
    } catch (e) { toast(e.message, 'error'); }
  };

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Concern Categories</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Configure concern categories available to students</div>
        </div>
        <button onClick={openNew} style={{ padding: '9px 18px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
          + Add Category
        </button>
      </div>

      {/* Info callout */}
      <div style={{ background: '#EFF6FF', border: '1px solid #BFDBFE', borderRadius: 9, padding: '10px 16px', fontSize: 12.5, color: '#1D4ED8', marginBottom: 20 }}>
        Categories marked <strong>Auto-Alert</strong> will immediately notify counselling staff when submitted by a student.
      </div>

      {loading ? (
        <div style={{ color: '#94A3B8', fontSize: 13 }}>Loading...</div>
      ) : types.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '48px', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, color: '#94A3B8' }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 8 }}>No concern categories configured</div>
          <button onClick={openNew} style={{ padding: '8px 20px', background: '#D97706', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600, fontSize: 13 }}>Add First</button>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(290px,1fr))', gap: 14 }}>
          {types.map(ct => {
            const sm = SEVERITY_MAP[ct.severity] || SEVERITY_MAP.moderate;
            return (
              <div key={ct.id} style={{ background: '#fff', borderLeft: `4px solid ${sm.color}`, border: `1px solid ${sm.border}`, borderLeftWidth: 4, borderRadius: 12, padding: '18px 20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    {ct.icon && <span style={{ fontSize: 22 }}>{ct.icon}</span>}
                    <div>
                      <div style={{ fontWeight: 800, fontSize: 14, color: '#0F172A' }}>{ct.name}</div>
                      <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11.5, fontWeight: 700, background: sm.bg, color: sm.color }}>{sm.label}</span>
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button onClick={() => openEdit(ct)} style={{ padding: '4px 10px', background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 6, fontSize: 11.5, fontWeight: 600, cursor: 'pointer', color: '#374151' }}>Edit</button>
                    <button onClick={() => remove(ct.id, ct.name)} style={{ padding: '4px 10px', background: '#FEF2F2', border: '1px solid #FECACA', borderRadius: 6, fontSize: 11.5, fontWeight: 600, cursor: 'pointer', color: '#DC2626' }}>Del</button>
                  </div>
                </div>
                {ct.description && <div style={{ fontSize: 12.5, color: '#64748B', marginBottom: 8, lineHeight: 1.4 }}>{ct.description}</div>}
                {ct.auto_alert && (
                  <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 700, background: '#FEF2F2', color: '#DC2626' }}>Auto-Alert</span>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 20 }}>
          <div style={{ background: '#fff', borderRadius: 14, width: '100%', maxWidth: 460, padding: '28px', boxShadow: '0 20px 60px rgba(0,0,0,.2)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 20 }}>
              <div style={{ fontSize: 17, fontWeight: 800, color: '#0F172A' }}>{editItem ? 'Edit Category' : 'Add Concern Category'}</div>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', border: 'none', fontSize: 22, color: '#94A3B8', cursor: 'pointer', lineHeight: 1 }}>×</button>
            </div>
            <form onSubmit={save}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 80px', gap: 14, marginBottom: 14 }}>
                <div>
                  <label style={labelStyle}>Name *</label>
                  <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required placeholder="e.g. Academic Distress" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Icon</label>
                  <input value={form.icon || ''} onChange={e => setForm(f => ({ ...f, icon: e.target.value }))} placeholder="!" maxLength={4} style={inputStyle} />
                </div>
              </div>
              <div style={{ marginBottom: 14 }}>
                <label style={labelStyle}>Description</label>
                <textarea value={form.description || ''} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={2} placeholder="Brief description for students..." style={{ ...inputStyle, resize: 'vertical' }} />
              </div>
              <div style={{ marginBottom: 14 }}>
                <label style={labelStyle}>Severity</label>
                <div style={{ display: 'flex', gap: 8 }}>
                  {['low', 'moderate', 'high'].map(s => (
                    <button key={s} type="button" onClick={() => setForm(f => ({ ...f, severity: s }))}
                      style={{ flex: 1, padding: '8px', borderRadius: 8, border: `1.5px solid ${form.severity === s ? SEVERITY_MAP[s].color : '#E2E8F0'}`, background: form.severity === s ? SEVERITY_MAP[s].bg : '#fff', color: form.severity === s ? SEVERITY_MAP[s].color : '#64748B', cursor: 'pointer', fontSize: 13, fontWeight: 700 }}>
                      {SEVERITY_MAP[s].label}
                    </button>
                  ))}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 16, marginBottom: 22 }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 13 }}>
                  <input type="checkbox" checked={form.auto_alert} onChange={e => setForm(f => ({ ...f, auto_alert: e.target.checked }))} />
                  Auto-Alert Staff
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 13 }}>
                  <input type="checkbox" checked={form.active} onChange={e => setForm(f => ({ ...f, active: e.target.checked }))} />
                  Active
                </label>
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button type="button" onClick={() => setShowModal(false)} style={{ flex: 1, padding: '10px', background: '#F1F5F9', color: '#374151', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer', fontSize: 13 }}>Cancel</button>
                <button type="submit" disabled={submitting} style={{ flex: 2, padding: '10px', background: submitting ? '#93C5FD' : '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, cursor: submitting ? 'not-allowed' : 'pointer', fontSize: 13 }}>
                  {submitting ? 'Saving...' : editItem ? 'Save Changes' : 'Add Category'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
