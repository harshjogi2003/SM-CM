import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const MASTER_CARDS = [
  { key: 'centres',            label: 'Health Centres',        icon: '+', desc: 'Campus health centres and locations', path: '/config/centres' },
  { key: 'services',           label: 'Services',              icon: '⚕', desc: 'Available health and counselling services', path: '/config/services' },
  { key: 'providers',          label: 'Providers',             icon: '◎', desc: 'Doctors, counsellors, and specialists', path: '/config/providers' },
  { key: 'schedules',          label: 'Schedules',             icon: '◷', desc: 'Provider hours and slot configuration', path: '/config/schedules' },
  { key: 'triage-rules',       label: 'Triage Rules',          icon: '→', desc: 'Automated intake routing and escalation', path: '/config/triage-rules' },
  { key: 'certificate-types',  label: 'Certificate Types',     icon: '◻', desc: 'Available certificate and document types', path: '/config/certificate-types' },
  { key: 'concern-categories', label: 'Concern Categories',    icon: '!', desc: 'Student concern classification taxonomy', path: '/config/concern-categories' },
  { key: 'holidays',           label: 'Holidays & Closures',   icon: '◌', desc: 'Clinic holidays and non-working days', path: '/config/holidays' },
  { key: 'settings',           label: 'General Settings',      icon: '◌', desc: 'Institute info, booking rules, emergency contacts', path: '/config/settings' },
  { key: 'admin-users',        label: 'Users & Permissions',   icon: '◷', desc: 'Admin accounts and permission sets', path: '/admin-users' },
];

export default function Config() {
  const { apiFetch } = useApp();
  const navigate = useNavigate();
  const [counts, setCounts] = useState({});

  useEffect(() => {
    const apiKeys = ['centres','services','providers','schedules','triage-rules','certificate-types','concern-categories','holidays'];
    (async () => {
      const c = {};
      for (const k of apiKeys) {
        try {
          const data = await apiFetch(`/masters/${k}`);
          c[k] = Array.isArray(data) ? data.length : 0;
        } catch {}
      }
      setCounts(c);
    })();
  }, [apiFetch]);

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>System Configuration</h1>
        <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Manage master data, settings, and system configuration</div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        {MASTER_CARDS.map(card => (
          <div
            key={card.key}
            onClick={() => navigate(card.path)}
            style={{
              background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12,
              padding: '22px', cursor: 'pointer', transition: 'box-shadow .15s, border-color .15s',
            }}
            onMouseEnter={e => { e.currentTarget.style.boxShadow = '0 4px 16px rgba(0,0,0,.08)'; e.currentTarget.style.borderColor = '#2563EB'; }}
            onMouseLeave={e => { e.currentTarget.style.boxShadow = 'none'; e.currentTarget.style.borderColor = '#E2E8F0'; }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
              <div style={{ width: 38, height: 38, borderRadius: 9, background: '#EFF6FF', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, color: '#2563EB', fontWeight: 900 }}>
                {card.icon}
              </div>
              {counts[card.key] !== undefined && (
                <span style={{ background: '#F1F5F9', color: '#64748B', borderRadius: 6, padding: '2px 8px', fontSize: 11, fontWeight: 700 }}>
                  {counts[card.key]}
                </span>
              )}
            </div>
            <div style={{ fontWeight: 800, fontSize: 13.5, color: '#0F172A', marginBottom: 5, letterSpacing: '-0.01em' }}>{card.label}</div>
            <div style={{ fontSize: 12.5, color: '#64748B', marginBottom: 14, lineHeight: 1.4 }}>{card.desc}</div>
            <span style={{ fontSize: 12, color: '#2563EB', fontWeight: 700 }}>Manage →</span>
          </div>
        ))}
      </div>
    </div>
  );
}
