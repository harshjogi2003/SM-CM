import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const VITAL_DEFS = [
  { key: 'temp',  label: 'Temperature',    unit: '°C',   placeholder: '37.0' },
  { key: 'bp',    label: 'Blood Pressure', unit: 'mmHg', placeholder: '120/80' },
  { key: 'pulse', label: 'Pulse',          unit: 'bpm',  placeholder: '72' },
  { key: 'spo2',  label: 'SpO₂',           unit: '%',    placeholder: '98' },
  { key: 'wt',    label: 'Weight',         unit: 'kg',   placeholder: '65' },
  { key: 'ht',    label: 'Height',         unit: 'cm',   placeholder: '170' },
];

const STAGES = [
  'Intake Recorded',
  'Vitals Captured',
  'Consultation Active',
  'Disposition Set',
  'Output Issued',
  'Case Closed',
];

const inputStyle = {
  width: '100%', padding: '9px 12px', borderRadius: 7,
  border: '1.5px solid #E2E8F0', fontSize: 13, boxSizing: 'border-box',
  background: '#fff', color: '#0F172A', outline: 'none',
};

const labelStyle = {
  display: 'block', fontSize: 11.5, fontWeight: 700, color: '#64748B',
  textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 5,
};

export default function Consultation() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { apiFetch, toast, user } = useApp();

  const [appointment, setAppointment] = useState(null);
  const [student, setStudent] = useState(null);
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [stage, setStage] = useState(2);

  const [vitals, setVitals] = useState({ temp: '', bp: '', pulse: '', spo2: '', wt: '', ht: '' });
  const [subjective, setSubjective] = useState('');
  const [objective, setObjective] = useState('');
  const [assessment, setAssessment] = useState('');
  const [plan, setPlan] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [prescription, setPrescription] = useState('');
  const [severity, setSeverity] = useState('Mild');
  const [outcome, setOutcome] = useState('Treated & Released');
  const [followUpDate, setFollowUpDate] = useState('');
  const [outputDoc, setOutputDoc] = useState('None');
  const [consent, setConsent] = useState(true);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    async function load() {
      try {
        const appts = await apiFetch('/appointments');
        const appt = appts.find(a => String(a.id) === String(id));
        if (!appt) { toast('Appointment not found', 'error'); navigate('/queue'); return; }
        setAppointment(appt);
        setSubjective(appt.complaint || '');
        const recs = await apiFetch(`/records?student_id=${appt.student_id}`);
        setRecords(recs.slice(0, 5));
        const profileRes = await apiFetch(`/users/${appt.student_id}/profile`);
        setStudent(profileRes);
      } catch (e) {
        toast(e.message, 'error');
      } finally {
        setLoading(false);
      }
    }
    if (id) load(); else setLoading(false);
  }, [id, apiFetch, toast, navigate]);

  const handleComplete = async () => {
    if (!appointment) return;
    setSaving(true);
    try {
      await apiFetch('/records', {
        method: 'POST',
        body: JSON.stringify({
          student_id: appointment.student_id,
          appointment_id: appointment.id,
          date: new Date().toISOString().split('T')[0],
          service: appointment.service,
          doctor: appointment.doctor,
          diagnosis: `${assessment || ''}\n${diagnosis}`.trim() || 'Consultation completed',
          treatment: plan || '',
          prescription,
          notes: [objective && `Objective: ${objective}`, notes].filter(Boolean).join('\n'),
          vitals,
          case_id: appointment.case_id || null,
        }),
      });
      await apiFetch(`/appointments/${appointment.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'completed' }),
      });
      setStage(5);
      toast('Consultation completed. Record saved.', 'success');
      setTimeout(() => navigate('/queue'), 1200);
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div style={{ padding: 40, color: '#64748B', fontSize: 13 }}>Loading consultation...</div>;

  const getInitials = (name = '') => name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();

  return (
    <div style={{ display: 'flex', height: 'calc(100vh - 54px)', overflow: 'hidden', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Left patient panel */}
      <aside style={{ width: 260, flexShrink: 0, background: '#fff', borderRight: '1px solid #E2E8F0', display: 'flex', flexDirection: 'column', overflowY: 'auto' }}>
        {/* Back */}
        <div style={{ padding: '14px 18px', borderBottom: '1px solid #E2E8F0' }}>
          <button
            onClick={() => navigate('/queue')}
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#2563EB', fontSize: 13, fontWeight: 600, padding: 0, display: 'flex', alignItems: 'center', gap: 6 }}
          >
            ← Back to Queue
          </button>
        </div>

        {/* Patient identity */}
        <div style={{ padding: '20px 18px', borderBottom: '1px solid #F1F5F9' }}>
          <div style={{ width: 52, height: 52, borderRadius: '50%', background: '#2563EB', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 18, color: '#fff', marginBottom: 14 }}>
            {appointment ? getInitials(appointment.student_name || '') : '?'}
          </div>
          <div style={{ fontWeight: 800, fontSize: 15, color: '#0F172A' }}>{appointment?.student_name || '—'}</div>
          <div style={{ fontSize: 12, color: '#64748B', marginTop: 2 }}>{appointment?.s_id} · {appointment?.year}</div>
          <div style={{ marginTop: 10, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {student?.blood_group && <span style={{ padding: '2px 8px', background: '#FEF2F2', color: '#DC2626', borderRadius: 4, fontSize: 11, fontWeight: 700 }}>{student.blood_group}</span>}
            {student?.allergies && student.allergies !== 'None' && <span style={{ padding: '2px 8px', background: '#FFFBEB', color: '#D97706', borderRadius: 4, fontSize: 11 }}>Allergy: {student.allergies}</span>}
          </div>
        </div>

        {/* Clinical details */}
        <div style={{ padding: '14px 18px', borderBottom: '1px solid #F1F5F9' }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>Current Visit</div>
          {[
            ['Service', appointment?.service],
            ['Doctor', appointment?.doctor],
            ['Date', appointment?.date],
            ['Time', appointment?.time],
          ].map(([l, v]) => (
            <div key={l} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontSize: 12, color: '#94A3B8' }}>{l}</span>
              <span style={{ fontSize: 12, color: '#0F172A', fontWeight: 600, maxWidth: 140, textAlign: 'right', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{v || '—'}</span>
            </div>
          ))}
        </div>

        {/* Medical info */}
        {student && (
          <div style={{ padding: '14px 18px', borderBottom: '1px solid #F1F5F9' }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>Medical Info</div>
            {[
              ['DOB', student.dob],
              ['Blood', student.blood_group],
              ['Phone', student.phone],
              ['Emergency', student.emergency_contact_name],
              ['Conditions', student.chronic_conditions],
            ].map(([l, v]) => v ? (
              <div key={l} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                <span style={{ fontSize: 11.5, color: '#94A3B8' }}>{l}</span>
                <span style={{ fontSize: 11.5, color: '#374151', maxWidth: 140, textAlign: 'right', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{v}</span>
              </div>
            ) : null)}
          </div>
        )}

        {/* Visit history */}
        <div style={{ padding: '14px 18px', flex: 1 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>Previous Visits</div>
          {records.length === 0 ? (
            <div style={{ fontSize: 12, color: '#94A3B8' }}>No previous records</div>
          ) : records.map((r, i) => (
            <div key={r.id} style={{ display: 'flex', gap: 10, marginBottom: 12, alignItems: 'flex-start' }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#CBD5E1', marginTop: 5, flexShrink: 0 }} />
              <div>
                <div style={{ fontSize: 12, color: '#64748B' }}>{r.date}</div>
                <div style={{ fontSize: 12.5, fontWeight: 600, color: '#374151' }}>{r.service}</div>
                <div style={{ fontSize: 11.5, color: '#94A3B8', marginTop: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 190 }}>{r.diagnosis}</div>
              </div>
            </div>
          ))}
        </div>
      </aside>

      {/* Center — SOAP form */}
      <main style={{ flex: 1, overflowY: 'auto', background: '#F8FAFC', padding: '24px 28px' }}>
        <div style={{ marginBottom: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h2 style={{ fontSize: 18, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>
              Consultation — {appointment?.student_name}
            </h2>
            <div style={{ fontSize: 12.5, color: '#94A3B8', marginTop: 3 }}>
              {appointment?.service} · {user?.name || 'Clinician'} · {new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
            </div>
          </div>
          <span style={{ padding: '4px 12px', borderRadius: 20, background: '#FFFBEB', color: '#D97706', fontSize: 12, fontWeight: 700, border: '1px solid #FDE68A' }}>In Progress</span>
        </div>

        {/* Vitals */}
        <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, padding: '18px 20px', marginBottom: 16 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: '#0F172A', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 14 }}>Vitals</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6,1fr)', gap: 12 }}>
            {VITAL_DEFS.map(vd => (
              <div key={vd.key}>
                <label style={labelStyle}>{vd.label}</label>
                <div style={{ position: 'relative' }}>
                  <input
                    value={vitals[vd.key]}
                    onChange={e => setVitals(p => ({ ...p, [vd.key]: e.target.value }))}
                    placeholder={vd.placeholder}
                    style={{ ...inputStyle, paddingRight: vd.unit.length > 2 ? 40 : 32 }}
                  />
                  <span style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', fontSize: 10, color: '#94A3B8', fontWeight: 600 }}>{vd.unit}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* SOAP notes */}
        <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, padding: '18px 20px', marginBottom: 16 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: '#0F172A', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 14 }}>SOAP Notes</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            {[
              { key: 'S', label: 'Subjective — Chief Complaint', val: subjective, set: setSubjective, placeholder: 'Patient reports...' },
              { key: 'O', label: 'Objective — Observations', val: objective, set: setObjective, placeholder: 'On examination...' },
              { key: 'A', label: 'Assessment — Diagnosis', val: assessment, set: setAssessment, placeholder: 'Impression: ...' },
              { key: 'P', label: 'Plan — Treatment', val: plan, set: setPlan, placeholder: 'Advised: ...' },
            ].map(s => (
              <div key={s.key}>
                <label style={labelStyle}><span style={{ color: '#2563EB', fontWeight: 800 }}>{s.key}</span> — {s.label.split(' — ')[1]}</label>
                <textarea
                  value={s.val} onChange={e => s.set(e.target.value)} placeholder={s.placeholder} rows={3}
                  style={{ ...inputStyle, resize: 'vertical', lineHeight: 1.5 }}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Clinical assessment */}
        <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, padding: '18px 20px', marginBottom: 16 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: '#0F172A', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 14 }}>Clinical Assessment</div>
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 2fr 1fr', gap: 14, marginBottom: 14 }}>
            <div>
              <label style={labelStyle}>Formal Diagnosis</label>
              <textarea value={diagnosis} onChange={e => setDiagnosis(e.target.value)} rows={2} style={{ ...inputStyle, resize: 'vertical' }} placeholder="ICD-10 / clinical diagnosis..." />
            </div>
            <div>
              <label style={labelStyle}>Prescription / Treatment Plan</label>
              <textarea value={prescription} onChange={e => setPrescription(e.target.value)} rows={2} style={{ ...inputStyle, resize: 'vertical' }} placeholder="Medications, dosage, duration..." />
            </div>
            <div>
              <label style={labelStyle}>Severity</label>
              <select value={severity} onChange={e => setSeverity(e.target.value)} style={inputStyle}>
                {['Mild','Moderate','Severe','Critical'].map(o => <option key={o}>{o}</option>)}
              </select>
              <div style={{ marginTop: 10 }}>
                <label style={labelStyle}>Consent Obtained</label>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 2 }}>
                  <input type="checkbox" checked={consent} onChange={e => setConsent(e.target.checked)} id="consent-chk" style={{ width: 16, height: 16 }} />
                  <label htmlFor="consent-chk" style={{ fontSize: 13, color: '#374151', cursor: 'pointer' }}>{consent ? 'Yes' : 'No'}</label>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Disposition */}
        <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, padding: '18px 20px' }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: '#0F172A', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 14 }}>Disposition</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 14 }}>
            <div>
              <label style={labelStyle}>Outcome</label>
              <select value={outcome} onChange={e => setOutcome(e.target.value)} style={inputStyle}>
                {['Treated & Released','Follow-up Required','Referred to Specialist','Emergency Escalated','Admitted'].map(o => <option key={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Follow-up Date</label>
              <input type="date" value={followUpDate} onChange={e => setFollowUpDate(e.target.value)} style={inputStyle} />
            </div>
            <div>
              <label style={labelStyle}>Output Document</label>
              <select value={outputDoc} onChange={e => setOutputDoc(e.target.value)} style={inputStyle}>
                {['None','Medical Certificate','Return-to-Class Note','Referral Letter','Fitness Certificate'].map(o => <option key={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label style={labelStyle}>Staff Notes</label>
              <input value={notes} onChange={e => setNotes(e.target.value)} placeholder="Internal notes..." style={inputStyle} />
            </div>
          </div>
        </div>
      </main>

      {/* Right — actions + workflow */}
      <aside style={{ width: 240, flexShrink: 0, background: '#fff', borderLeft: '1px solid #E2E8F0', display: 'flex', flexDirection: 'column', overflowY: 'auto', padding: '20px 16px' }}>
        {/* Workflow stages */}
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }}>Workflow</div>
          {STAGES.map((s, i) => (
            <div key={s} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginBottom: 10 }}>
              <div style={{
                width: 22, height: 22, borderRadius: '50%', flexShrink: 0, marginTop: 1,
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700,
                background: i < stage ? '#ECFDF5' : i === stage ? '#EFF6FF' : '#F1F5F9',
                color: i < stage ? '#059669' : i === stage ? '#2563EB' : '#94A3B8',
                border: i === stage ? '1.5px solid #BFDBFE' : '1.5px solid transparent',
              }}>
                {i < stage ? '✓' : i + 1}
              </div>
              <span style={{ fontSize: 12, color: i === stage ? '#2563EB' : i < stage ? '#059669' : '#94A3B8', fontWeight: i === stage ? 700 : 400, paddingTop: 2 }}>{s}</span>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>Actions</div>
          <button
            onClick={handleComplete} disabled={saving}
            style={{ width: '100%', padding: '10px 14px', background: saving ? '#86EFAC' : '#059669', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: saving ? 'not-allowed' : 'pointer' }}
          >
            {saving ? 'Saving...' : 'Complete Consultation'}
          </button>
          <button
            onClick={() => toast('Certificate generation coming from Records.')}
            style={{ width: '100%', padding: '9px 14px', background: '#EFF6FF', color: '#2563EB', border: '1px solid #BFDBFE', borderRadius: 8, fontWeight: 600, fontSize: 12.5, cursor: 'pointer' }}
          >
            Issue Certificate
          </button>
          <button
            onClick={() => toast('Referral created.')}
            style={{ width: '100%', padding: '9px 14px', background: '#F1F5F9', color: '#475569', border: '1px solid #E2E8F0', borderRadius: 8, fontWeight: 600, fontSize: 12.5, cursor: 'pointer' }}
          >
            Refer to Specialist
          </button>
          <button
            onClick={() => { if (window.confirm('Escalate this case to the crisis team?')) toast('Escalated to crisis team!'); }}
            style={{ width: '100%', padding: '9px 14px', background: '#FEF2F2', color: '#DC2626', border: '1px solid #FECACA', borderRadius: 8, fontWeight: 600, fontSize: 12.5, cursor: 'pointer' }}
          >
            Escalate to Crisis
          </button>
        </div>

        {/* Privacy notice */}
        <div style={{ padding: '12px 14px', background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 8, fontSize: 11.5, color: '#64748B', lineHeight: 1.5 }}>
          Confidential. Records are encrypted per SIBM data policy.
        </div>
      </aside>
    </div>
  );
}
