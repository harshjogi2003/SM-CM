import { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';

const RISK_STYLE = {
  low:      { bg: '#ECFDF5', color: '#059669', label: 'Low Risk' },
  moderate: { bg: '#FFFBEB', color: '#D97706', label: 'Moderate' },
  high:     { bg: '#FEF2F2', color: '#DC2626', label: 'High Risk' },
  crisis:   { bg: '#7F1D1D', color: '#FCA5A5', label: 'Crisis' },
};
const STATUS_STYLE = {
  active:   { bg: '#EFF6FF', color: '#2563EB', label: 'Active' },
  on_hold:  { bg: '#FFFBEB', color: '#D97706', label: 'On Hold' },
  closed:   { bg: '#F1F5F9', color: '#64748B', label: 'Closed' },
};

const inputStyle = {
  width: '100%', padding: '8px 11px', borderRadius: 7,
  border: '1.5px solid #E2E8F0', fontSize: 12.5, boxSizing: 'border-box',
  background: '#fff', color: '#0F172A', outline: 'none',
};
const labelStyle = {
  display: 'block', fontSize: 11.5, fontWeight: 700, color: '#64748B',
  textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 5,
};

export default function Counselling() {
  const { apiFetch, toast } = useApp();
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('active');
  const [editing, setEditing] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try { setCases(await apiFetch('/counselling')); }
    catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const saveEdit = async (id) => {
    setSaving(true);
    try {
      await apiFetch(`/counselling/${id}`, { method: 'PATCH', body: JSON.stringify(editForm) });
      toast('Case updated');
      setEditing(null);
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setSaving(false); }
  };

  const filtered = filter === 'all' ? cases : cases.filter(c => c.status === filter);

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Counselling Cases</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Active and historical counselling case management</div>
        </div>
      </div>

      {/* Stats strip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 20 }}>
        {[
          { label: 'Active',       val: cases.filter(c => c.status === 'active').length,                              color: '#2563EB', bg: '#EFF6FF' },
          { label: 'On Hold',      val: cases.filter(c => c.status === 'on_hold').length,                             color: '#D97706', bg: '#FFFBEB' },
          { label: 'Closed',       val: cases.filter(c => c.status === 'closed').length,                              color: '#059669', bg: '#ECFDF5' },
          { label: 'High / Crisis',val: cases.filter(c => ['high','crisis'].includes(c.risk_level)).length,           color: '#DC2626', bg: '#FEF2F2' },
        ].map(s => (
          <div key={s.label} style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, padding: '14px 18px' }}>
            <div style={{ fontSize: 11.5, color: '#94A3B8', fontWeight: 600, marginBottom: 6 }}>{s.label}</div>
            <div style={{ fontSize: 26, fontWeight: 800, color: s.color, letterSpacing: '-0.02em' }}>{s.val}</div>
          </div>
        ))}
      </div>

      {/* Filter chips */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
        {[
          { key: 'active',  label: 'Active' },
          { key: 'on_hold', label: 'On Hold' },
          { key: 'closed',  label: 'Closed' },
          { key: 'all',     label: 'All' },
        ].map(t => (
          <button
            key={t.key} onClick={() => setFilter(t.key)}
            style={{
              padding: '6px 14px', borderRadius: 20, fontSize: 12.5, fontWeight: 600, cursor: 'pointer', border: 'none',
              background: filter === t.key ? '#0F172A' : '#F1F5F9',
              color: filter === t.key ? '#fff' : '#64748B',
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ padding: 40, color: '#94A3B8', fontSize: 13, textAlign: 'center' }}>Loading cases...</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#94A3B8' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>—</div>
          <div style={{ fontWeight: 600, fontSize: 14 }}>No {filter} counselling cases</div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filtered.map(c => {
            const rs = RISK_STYLE[c.risk_level] || RISK_STYLE.low;
            const ss = STATUS_STYLE[c.status] || STATUS_STYLE.active;
            return (
              <div key={c.id} style={{
                background: '#fff', border: '1px solid #E2E8F0',
                borderLeft: c.risk_level === 'crisis' || c.risk_level === 'high' ? '4px solid #DC2626' : '4px solid transparent',
                borderRadius: 10, overflow: 'hidden',
              }}>
                <div style={{ padding: '16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6, flexWrap: 'wrap' }}>
                      <span style={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>{c.student_name}</span>
                      <span style={{ fontSize: 12, color: '#94A3B8' }}>{c.s_id}</span>
                      {c.year && <span style={{ fontSize: 12, color: '#94A3B8' }}>{c.year}</span>}
                      <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 600, background: ss.bg, color: ss.color }}>{ss.label}</span>
                      <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 600, background: rs.bg, color: rs.color }}>{rs.label}</span>
                    </div>
                    <div style={{ fontSize: 12.5, color: '#64748B', marginBottom: 4 }}>
                      Counsellor: <strong style={{ color: '#374151' }}>{c.counsellor}</strong>
                      &nbsp;·&nbsp; Sessions: <strong style={{ color: '#374151' }}>{c.sessions_completed}</strong>
                      {c.next_session && <>&nbsp;·&nbsp; Next: <strong style={{ color: '#374151' }}>{c.next_session}</strong></>}
                    </div>
                    {c.concern && (
                      <div style={{ fontSize: 12.5, color: '#374151', marginTop: 3 }}>
                        Concern: {c.concern}
                      </div>
                    )}
                    {c.notes && (
                      <div style={{ marginTop: 8, padding: '8px 12px', background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 7, fontSize: 12.5, color: '#374151' }}>
                        {c.notes}
                      </div>
                    )}
                  </div>
                  <button
                    onClick={() => {
                      setEditing(editing === c.id ? null : c.id);
                      setEditForm({ status: c.status, risk_level: c.risk_level, sessions_completed: c.sessions_completed, next_session: c.next_session || '', notes: c.notes || '', counsellor: c.counsellor });
                    }}
                    style={{ padding: '6px 14px', background: '#EFF6FF', color: '#2563EB', border: '1px solid #BFDBFE', borderRadius: 7, fontSize: 12.5, fontWeight: 600, cursor: 'pointer', marginLeft: 16, flexShrink: 0 }}
                  >
                    {editing === c.id ? 'Cancel' : 'Edit'}
                  </button>
                </div>

                {/* Edit panel */}
                {editing === c.id && (
                  <div style={{ borderTop: '1px solid #E2E8F0', padding: '16px 20px', background: '#F8FAFC' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 12 }}>
                      <div>
                        <label style={labelStyle}>Status</label>
                        <select value={editForm.status} onChange={e => setEditForm(f => ({ ...f, status: e.target.value }))} style={inputStyle}>
                          <option value="active">Active</option>
                          <option value="on_hold">On Hold</option>
                          <option value="closed">Closed</option>
                        </select>
                      </div>
                      <div>
                        <label style={labelStyle}>Risk Level</label>
                        <select value={editForm.risk_level} onChange={e => setEditForm(f => ({ ...f, risk_level: e.target.value }))} style={inputStyle}>
                          <option value="low">Low</option>
                          <option value="moderate">Moderate</option>
                          <option value="high">High</option>
                          <option value="crisis">Crisis</option>
                        </select>
                      </div>
                      <div>
                        <label style={labelStyle}>Sessions</label>
                        <input type="number" min="0" value={editForm.sessions_completed} onChange={e => setEditForm(f => ({ ...f, sessions_completed: parseInt(e.target.value) || 0 }))} style={inputStyle} />
                      </div>
                      <div>
                        <label style={labelStyle}>Next Session</label>
                        <input type="date" value={editForm.next_session} onChange={e => setEditForm(f => ({ ...f, next_session: e.target.value }))} style={inputStyle} />
                      </div>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '2fr 3fr', gap: 12, marginBottom: 14 }}>
                      <div>
                        <label style={labelStyle}>Counsellor</label>
                        <input value={editForm.counsellor} onChange={e => setEditForm(f => ({ ...f, counsellor: e.target.value }))} style={inputStyle} />
                      </div>
                      <div>
                        <label style={labelStyle}>Case Notes</label>
                        <input value={editForm.notes} onChange={e => setEditForm(f => ({ ...f, notes: e.target.value }))} placeholder="Session notes..." style={inputStyle} />
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button
                        onClick={() => saveEdit(c.id)} disabled={saving}
                        style={{ padding: '8px 18px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 7, fontSize: 12.5, fontWeight: 700, cursor: 'pointer' }}
                      >
                        {saving ? 'Saving...' : 'Save Changes'}
                      </button>
                      <button onClick={() => setEditing(null)} style={{ padding: '8px 14px', background: '#fff', color: '#374151', border: '1px solid #E2E8F0', borderRadius: 7, fontSize: 12.5, cursor: 'pointer' }}>
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
