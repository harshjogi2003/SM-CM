import { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';

const DEFAULT_SETTINGS = {
  maxSessionsPerStudent: 10,
  sessionDurationMins: 45,
  autoFollowUpDays: 7,
  crisisAutoAlert: true,
  allowAnonymous: true,
  notifyParents: false,
  notifyFaculty: false,
  consentRequired: true,
  waitlistEnabled: true,
};

const inputStyle = { padding: '8px 12px', borderRadius: 7, border: '1.5px solid #E2E8F0', fontSize: 13, background: '#fff', color: '#0F172A', outline: 'none' };

export default function CounsellingSetup() {
  const { apiFetch, toast } = useApp();
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [counsellors, setCounsellors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    try {
      const providers = await apiFetch('/masters/providers');
      setCounsellors(providers.filter(p => p.type === 'counsellor' || p.specialty?.toLowerCase().includes('counsell')));
    } catch { /* fallback empty */ }
    finally { setLoading(false); }
  }, [apiFetch]);

  useEffect(() => { load(); }, [load]);

  const handleSave = async () => {
    setSaving(true);
    try {
      // Save each setting key/value pair
      await Promise.all(Object.entries(settings).map(([key, val]) =>
        apiFetch('/settings', { method: 'PATCH', body: JSON.stringify({ key: `counselling_${key}`, value: String(val) }) })
      ));
      toast('Counselling settings saved');
    } catch (e) { toast(e.message || 'Error saving settings', 'error'); }
    finally { setSaving(false); }
  };

  const toggle = (key) => setSettings(prev => ({ ...prev, [key]: !prev[key] }));

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif', maxWidth: 920 }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Counselling Setup</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Configure counselling service policies, staff and session parameters</div>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          style={{ padding: '9px 18px', background: saving ? '#A7F3D0' : '#059669', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: saving ? 'not-allowed' : 'pointer' }}
        >
          {saving ? 'Saving...' : 'Save Settings'}
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
        {/* Session parameters */}
        <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, padding: '22px' }}>
          <div style={{ fontWeight: 800, fontSize: 14, color: '#0F172A', marginBottom: 18, letterSpacing: '-0.01em' }}>Session Parameters</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div>
              <label style={{ display: 'block', fontSize: 12.5, fontWeight: 600, color: '#374151', marginBottom: 6 }}>Max Sessions per Student</label>
              <input
                type="number" min={1} max={50}
                value={settings.maxSessionsPerStudent}
                onChange={e => setSettings(p => ({ ...p, maxSessionsPerStudent: Number(e.target.value) }))}
                style={{ ...inputStyle, width: 100 }}
              />
              <div style={{ fontSize: 11.5, color: '#94A3B8', marginTop: 4 }}>Manual review required beyond this limit</div>
            </div>
            <div>
              <label style={{ display: 'block', fontSize: 12.5, fontWeight: 600, color: '#374151', marginBottom: 6 }}>Default Session Duration</label>
              <select
                value={settings.sessionDurationMins}
                onChange={e => setSettings(p => ({ ...p, sessionDurationMins: Number(e.target.value) }))}
                style={{ ...inputStyle, width: 140 }}
              >
                {[30, 45, 60, 90].map(d => <option key={d} value={d}>{d} minutes</option>)}
              </select>
            </div>
            <div>
              <label style={{ display: 'block', fontSize: 12.5, fontWeight: 600, color: '#374151', marginBottom: 6 }}>Auto Follow-up (days after session)</label>
              <input
                type="number" min={1}
                value={settings.autoFollowUpDays}
                onChange={e => setSettings(p => ({ ...p, autoFollowUpDays: Number(e.target.value) }))}
                style={{ ...inputStyle, width: 100 }}
              />
            </div>
          </div>
        </div>

        {/* Privacy & Alerts */}
        <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, padding: '22px' }}>
          <div style={{ fontWeight: 800, fontSize: 14, color: '#0F172A', marginBottom: 18, letterSpacing: '-0.01em' }}>Privacy &amp; Notifications</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {[
              { key: 'crisisAutoAlert', label: 'Auto-alert staff on crisis concerns', sub: 'Immediately notify all counselling staff' },
              { key: 'allowAnonymous',  label: 'Allow anonymous submissions',         sub: 'Students can hide their identity' },
              { key: 'consentRequired', label: 'Require student consent form',        sub: 'Signed consent before first session' },
              { key: 'waitlistEnabled', label: 'Enable waitlist when fully booked',   sub: 'Students join waitlist if all slots are filled' },
              { key: 'notifyParents',   label: 'Notify parent / guardian',            sub: 'Only for students under 18 in crisis' },
              { key: 'notifyFaculty',   label: 'Notify faculty advisor',              sub: 'For academic impact cases with student consent' },
            ].map(({ key, label, sub }) => (
              <label key={key} style={{ display: 'flex', alignItems: 'flex-start', gap: 12, cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={settings[key]}
                  onChange={() => toggle(key)}
                  style={{ width: 15, height: 15, marginTop: 2, cursor: 'pointer' }}
                />
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#0F172A' }}>{label}</div>
                  <div style={{ fontSize: 12, color: '#64748B', marginTop: 1 }}>{sub}</div>
                </div>
              </label>
            ))}
          </div>
        </div>
      </div>

      {/* Counselling staff */}
      <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, padding: '22px' }}>
        <div style={{ fontWeight: 800, fontSize: 14, color: '#0F172A', marginBottom: 18, letterSpacing: '-0.01em' }}>Counselling Staff</div>
        {loading ? (
          <div style={{ color: '#94A3B8', fontSize: 13 }}>Loading...</div>
        ) : counsellors.length === 0 ? (
          <div style={{ color: '#94A3B8', fontSize: 13 }}>No counsellors configured. Add providers in the Providers section.</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {/* Header row */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 150px 120px 100px', gap: 14, padding: '8px 12px', background: '#F8FAFC', borderRadius: '8px 8px 0 0', borderBottom: '1.5px solid #E2E8F0' }}>
              {['Name', 'Specialty', 'Phone', 'Status'].map(h => (
                <span key={h} style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{h}</span>
              ))}
            </div>
            {counsellors.map((c, i) => (
              <div key={c.id} style={{ display: 'grid', gridTemplateColumns: '1fr 150px 120px 100px', gap: 14, padding: '12px 12px', borderBottom: i < counsellors.length - 1 ? '1px solid #F1F5F9' : 'none', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#7C3AED', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 12, color: '#fff', flexShrink: 0 }}>
                    {(c.name || 'C').charAt(0)}
                  </div>
                  <span style={{ fontWeight: 600, fontSize: 13, color: '#0F172A' }}>{c.name}</span>
                </div>
                <span style={{ fontSize: 12.5, color: '#64748B' }}>{c.specialty || '—'}</span>
                <span style={{ fontSize: 12.5, color: '#64748B' }}>{c.phone || '—'}</span>
                <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 700, background: c.active !== 0 ? '#ECFDF5' : '#F1F5F9', color: c.active !== 0 ? '#059669' : '#64748B', display: 'inline-block' }}>
                  {c.active !== 0 ? 'Active' : 'Inactive'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
