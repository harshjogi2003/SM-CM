import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const STATUS_STYLE = {
  upcoming:    { bg: '#EFF6FF', color: '#2563EB', label: 'Waiting' },
  in_progress: { bg: '#FFFBEB', color: '#D97706', label: 'In Progress' },
  completed:   { bg: '#ECFDF5', color: '#059669', label: 'Done' },
  cancelled:   { bg: '#F1F5F9', color: '#94A3B8', label: 'Cancelled' },
};

function Card({ children, style }) {
  return (
    <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, ...style }}>
      {children}
    </div>
  );
}

function SectionHeader({ title, action, onAction }) {
  return (
    <div style={{ padding: '14px 18px', borderBottom: '1px solid #F1F5F9', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <span style={{ fontWeight: 700, fontSize: 13, color: '#0F172A' }}>{title}</span>
      {action && <button onClick={onAction} style={{ background: 'none', border: 'none', color: '#2563EB', fontWeight: 600, fontSize: 12, cursor: 'pointer', padding: 0 }}>{action}</button>}
    </div>
  );
}

export default function Dashboard() {
  const { apiFetch, toast } = useApp();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [queue, setQueue] = useState([]);
  const [concerns, setConcerns] = useState([]);
  const [pendingCerts, setPendingCerts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        setStats(await apiFetch('/stats'));
        setQueue((await apiFetch('/queue')).slice(0, 6));
        setConcerns((await apiFetch('/concerns')).filter(x => x.status === 'pending').slice(0, 4));
        setPendingCerts((await apiFetch('/certificates')).filter(x => x.status === 'pending').slice(0, 4));
      } catch (e) {
        toast(e.message, 'error');
      } finally {
        setLoading(false);
      }
    })();
  }, [apiFetch, toast]);

  if (loading) return (
    <div style={{ padding: 40, display: 'flex', alignItems: 'center', gap: 12, color: '#64748B', fontSize: 13 }}>
      <div style={{ width: 20, height: 20, border: '2px solid #E2E8F0', borderTopColor: '#2563EB', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
      Loading dashboard...
    </div>
  );

  const KPI = [
    { label: 'Total Students',     val: stats?.totalStudents,     color: '#2563EB',  bg: '#EFF6FF',  path: null },
    { label: 'In Queue Today',      val: queue.length,             color: '#7C3AED',  bg: '#F5F3FF',  path: '/queue' },
    { label: 'Pending Certificates',val: stats?.pendingCerts,      color: '#D97706',  bg: '#FFFBEB',  path: '/certificates' },
    { label: 'Active Counselling',  val: stats?.activeCases,       color: '#059669',  bg: '#ECFDF5',  path: '/counselling' },
    { label: 'Open Concerns',       val: stats?.openConcerns,      color: '#DC2626',  bg: '#FEF2F2',  path: '/raise-concern' },
    {
      label: 'Active Crisis',
      val: stats?.activeCrisisCases || 0,
      color: (stats?.activeCrisisCases || 0) > 0 ? '#DC2626' : '#059669',
      bg: (stats?.activeCrisisCases || 0) > 0 ? '#FEF2F2' : '#ECFDF5',
      path: '/cases',
      crisis: (stats?.activeCrisisCases || 0) > 0,
    },
  ];

  const today = new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Page header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>
            Clinical Dashboard
          </h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>{today}</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={() => navigate('/walkin')}
            style={{ padding: '8px 16px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, fontSize: 12.5, cursor: 'pointer' }}
          >
            + Walk-in
          </button>
          <button
            onClick={() => window.location.reload()}
            style={{ padding: '8px 16px', background: '#F1F5F9', color: '#475569', border: '1px solid #E2E8F0', borderRadius: 8, fontWeight: 600, fontSize: 12.5, cursor: 'pointer' }}
          >
            Refresh
          </button>
        </div>
      </div>

      {/* KPI grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6,1fr)', gap: 12, marginBottom: 24 }}>
        {KPI.map(k => (
          <div
            key={k.label}
            onClick={() => k.path && navigate(k.path)}
            style={{
              background: '#fff',
              border: k.crisis ? '1.5px solid #FCA5A5' : '1px solid #E2E8F0',
              borderRadius: 10, padding: '16px 16px', cursor: k.path ? 'pointer' : 'default',
              transition: 'box-shadow .15s',
            }}
            onMouseEnter={e => k.path && (e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,.08)')}
            onMouseLeave={e => (e.currentTarget.style.boxShadow = 'none')}
          >
            <div style={{ fontSize: 11, color: '#94A3B8', fontWeight: 600, marginBottom: 10, lineHeight: 1.3 }}>{k.label}</div>
            <div style={{ fontSize: 26, fontWeight: 800, color: k.color, letterSpacing: '-0.02em' }}>{k.val ?? '—'}</div>
            {k.path && <div style={{ fontSize: 11, color: k.color, marginTop: 6, fontWeight: 600, opacity: 0.8 }}>View →</div>}
          </div>
        ))}
      </div>

      {/* Crisis banner */}
      {(stats?.activeCrisisCases || 0) > 0 && (
        <div
          onClick={() => navigate('/cases?filter=crisis')}
          style={{
            background: '#FEF2F2', border: '1.5px solid #FECACA', borderRadius: 10,
            padding: '14px 20px', marginBottom: 20, display: 'flex', alignItems: 'center',
            gap: 14, cursor: 'pointer',
          }}
        >
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#DC2626', flexShrink: 0 }} />
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 13, color: '#DC2626' }}>
              {stats.activeCrisisCases} Active Crisis Case{stats.activeCrisisCases > 1 ? 's' : ''}
            </div>
            <div style={{ fontSize: 12, color: '#B91C1C', marginTop: 2 }}>Immediate review required — click to open cases</div>
          </div>
          <span style={{ fontSize: 12, color: '#DC2626', fontWeight: 600 }}>Review →</span>
        </div>
      )}

      {/* Two-column layout */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 20 }}>
        {/* Live Queue */}
        <Card>
          <SectionHeader title="Live Queue" action="Full Queue →" onAction={() => navigate('/queue')} />
          <div style={{ padding: '10px 0' }}>
            {queue.length === 0 ? (
              <div style={{ padding: '28px 20px', textAlign: 'center', color: '#94A3B8', fontSize: 13 }}>
                Queue is empty
              </div>
            ) : queue.map((q, i) => {
              const ss = STATUS_STYLE[q.status] || STATUS_STYLE.upcoming;
              return (
                <div key={q.id} style={{
                  display: 'flex', alignItems: 'center', gap: 14, padding: '10px 18px',
                  borderBottom: i < queue.length - 1 ? '1px solid #F8FAFC' : 'none',
                }}>
                  <div style={{ width: 28, height: 28, borderRadius: '50%', background: ss.bg, color: ss.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 11, flexShrink: 0 }}>
                    {q.is_walkin ? `W${q.token_number || i + 1}` : `${i + 1}`}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 600, fontSize: 13, color: '#0F172A', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{q.student_name}</div>
                    <div style={{ fontSize: 11.5, color: '#64748B', marginTop: 1 }}>
                      {q.service}
                      {q.is_walkin && <span style={{ marginLeft: 6, background: '#FFFBEB', color: '#D97706', padding: '0px 5px', borderRadius: 4, fontSize: 10, fontWeight: 700 }}>WALK-IN</span>}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 8, flexShrink: 0, alignItems: 'center' }}>
                    <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600, background: ss.bg, color: ss.color }}>
                      {ss.label}
                    </span>
                    {!q.is_walkin && (
                      <button
                        onClick={() => navigate(`/consultation/${q.id}`)}
                        style={{ padding: '5px 12px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 6, fontSize: 11.5, fontWeight: 600, cursor: 'pointer' }}
                      >
                        Consult
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Pending actions column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Pending Certificates */}
          <Card>
            <SectionHeader
              title={`Pending Certificates ${pendingCerts.length > 0 ? `(${pendingCerts.length})` : ''}`}
              action="Review all →"
              onAction={() => navigate('/certificates')}
            />
            <div style={{ padding: '8px 0' }}>
              {pendingCerts.length === 0 ? (
                <div style={{ padding: '14px 18px', fontSize: 12.5, color: '#94A3B8' }}>No pending certificates</div>
              ) : pendingCerts.map((c, i) => (
                <div key={c.id} style={{
                  padding: '10px 18px',
                  borderBottom: i < pendingCerts.length - 1 ? '1px solid #F8FAFC' : 'none',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                }}>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 12.5, color: '#0F172A' }}>{c.student_name}</div>
                    <div style={{ fontSize: 11.5, color: '#64748B', marginTop: 1 }}>{c.type}</div>
                  </div>
                  <button
                    onClick={() => navigate('/certificates')}
                    style={{ padding: '4px 10px', background: '#FFFBEB', color: '#D97706', border: '1px solid #FDE68A', borderRadius: 6, fontSize: 11.5, cursor: 'pointer', fontWeight: 600 }}
                  >
                    Review
                  </button>
                </div>
              ))}
            </div>
          </Card>

          {/* Open Concerns */}
          <Card>
            <SectionHeader
              title={`Open Concerns ${concerns.length > 0 ? `(${concerns.length})` : ''}`}
              action="View all →"
              onAction={() => navigate('/raise-concern')}
            />
            <div style={{ padding: '8px 0' }}>
              {concerns.length === 0 ? (
                <div style={{ padding: '14px 18px', fontSize: 12.5, color: '#94A3B8' }}>No open concerns</div>
              ) : concerns.map((c, i) => (
                <div key={c.id} style={{
                  padding: '10px 18px',
                  borderBottom: i < concerns.length - 1 ? '1px solid #F8FAFC' : 'none',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 600, fontSize: 12.5, color: '#0F172A', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {c.anonymous ? 'Anonymous' : c.student_name}
                    </div>
                    <div style={{ fontSize: 11.5, color: '#64748B', marginTop: 1 }}>{c.type}</div>
                  </div>
                  <span style={{
                    padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600, flexShrink: 0, marginLeft: 8,
                    background: c.priority === 'high' ? '#FEF2F2' : c.priority === 'moderate' ? '#FFFBEB' : '#F1F5F9',
                    color: c.priority === 'high' ? '#DC2626' : c.priority === 'moderate' ? '#D97706' : '#64748B',
                  }}>
                    {c.priority}
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
