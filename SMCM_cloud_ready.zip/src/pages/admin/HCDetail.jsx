import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const DEFAULT_SCHEDULE = DAYS.map(d => ({ day: d, open: d !== 'Sat' ? '08:00' : '10:00', close: d !== 'Sat' ? '20:00' : '17:00', isOpen: true }));
const TABS = ['Overview', 'Schedule', 'Rules'];

const inputStyle = { padding: '8px 12px', borderRadius: 7, border: '1.5px solid #E2E8F0', fontSize: 13, background: '#fff', color: '#0F172A', outline: 'none', boxSizing: 'border-box' };

export default function HCDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { apiFetch, toast } = useApp();
  const [hc, setHc] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('Overview');
  const [schedule, setSchedule] = useState(DEFAULT_SCHEDULE);
  const [editSchedule, setEditSchedule] = useState(false);
  const [rules, setRules] = useState({ linkCampus: true, deptAccess: false, autoNotify: true, limitPerStudent: 3 });

  useEffect(() => {
    apiFetch('/masters/centres')
      .then(data => {
        const found = data.find(c => String(c.id) === String(id));
        setHc(found || null);
      })
      .catch(e => toast(e.message, 'error'))
      .finally(() => setLoading(false));
  }, [id, apiFetch, toast]);

  if (loading) return <div style={{ padding: 40, color: '#94A3B8', fontSize: 13, fontFamily: 'system-ui' }}>Loading...</div>;
  if (!hc) return (
    <div style={{ padding: 40, fontFamily: 'system-ui' }}>
      <div style={{ fontWeight: 700, color: '#DC2626', marginBottom: 12 }}>Health Centre not found</div>
      <button onClick={() => navigate('/health-centres')} style={{ padding: '8px 16px', background: '#F1F5F9', border: 'none', borderRadius: 7, cursor: 'pointer', fontSize: 13 }}>Back to Health Centres</button>
    </div>
  );

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif', maxWidth: 900 }}>
      {/* Back */}
      <button
        onClick={() => navigate('/health-centres')}
        style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', color: '#64748B', cursor: 'pointer', fontSize: 13, fontWeight: 600, marginBottom: 18, padding: 0 }}
      >
        ← Back to Health Centres
      </button>

      {/* Header */}
      <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, padding: '22px', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 18 }}>
        <div style={{ width: 52, height: 52, borderRadius: 13, background: '#EFF6FF', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, color: '#2563EB', fontWeight: 900, flexShrink: 0 }}>+</div>
        <div style={{ flex: 1 }}>
          <h1 style={{ fontSize: 18, fontWeight: 800, color: '#0F172A', margin: '0 0 6px', letterSpacing: '-0.01em' }}>{hc.name}</h1>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
            {hc.location && <span style={{ fontSize: 12.5, color: '#64748B' }}>{hc.location}</span>}
            {hc.type && <span style={{ padding: '2px 9px', borderRadius: 20, background: '#EFF6FF', color: '#2563EB', fontSize: 11.5, fontWeight: 700 }}>{hc.type}</span>}
            <span style={{ padding: '2px 9px', borderRadius: 20, background: hc.active !== 0 ? '#ECFDF5' : '#F1F5F9', color: hc.active !== 0 ? '#059669' : '#64748B', fontSize: 11.5, fontWeight: 700 }}>
              {hc.active !== 0 ? 'Active' : 'Inactive'}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, borderBottom: '1.5px solid #E2E8F0', paddingBottom: 0 }}>
        {TABS.map(t => (
          <button
            key={t} onClick={() => setActiveTab(t)}
            style={{ padding: '9px 18px', border: 'none', background: 'none', cursor: 'pointer', fontWeight: 700, fontSize: 13, color: activeTab === t ? '#2563EB' : '#64748B', borderBottom: activeTab === t ? '2px solid #2563EB' : '2px solid transparent', marginBottom: -1.5, transition: 'all .15s' }}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Overview */}
      {activeTab === 'Overview' && (
        <div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, padding: '20px' }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 14 }}>Contact & Hours</div>
              {[
                { icon: '→', label: 'Phone', val: hc.phone || '—' },
                { icon: '→', label: 'Email', val: hc.email || '—' },
                { icon: '→', label: 'Hours', val: hc.timing || '—' },
                { icon: '→', label: 'Walk-in', val: hc.walk_in_enabled ? 'Allowed' : 'By Appointment Only' },
              ].map(row => (
                <div key={row.label} style={{ display: 'flex', gap: 10, paddingBottom: 10, marginBottom: 10, borderBottom: '1px solid #F1F5F9' }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: '#94A3B8', width: 70, flexShrink: 0 }}>{row.label}</div>
                  <div style={{ fontSize: 13, color: '#374151' }}>{row.val}</div>
                </div>
              ))}
            </div>
            <div style={{ background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 12, padding: '20px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 14 }}>Quick Info</div>
              <div style={{ fontSize: 13, color: '#374151', lineHeight: 1.7 }}>
                <div>Type: <strong>{hc.type || 'Medical'}</strong></div>
                <div>Location: <strong>{hc.location || '—'}</strong></div>
                <div>Walk-in: <strong>{hc.walk_in_enabled ? 'Yes' : 'No'}</strong></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Schedule */}
      {activeTab === 'Schedule' && (
        <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, padding: '22px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
            <div style={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>Weekly Schedule</div>
            <button
              onClick={() => { if (editSchedule) toast('Schedule saved!'); setEditSchedule(v => !v); }}
              style={{ padding: '7px 16px', background: editSchedule ? '#ECFDF5' : '#F1F5F9', color: editSchedule ? '#059669' : '#374151', border: `1px solid ${editSchedule ? '#A7F3D0' : '#E2E8F0'}`, borderRadius: 7, fontWeight: 600, fontSize: 12.5, cursor: 'pointer' }}
            >
              {editSchedule ? 'Save Schedule' : 'Edit Schedule'}
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {schedule.map((d, i) => (
              <div key={d.day} style={{ display: 'grid', gridTemplateColumns: '60px 80px 1fr', gap: 14, alignItems: 'center', padding: '10px 14px', background: '#F8FAFC', borderRadius: 8 }}>
                <span style={{ fontWeight: 700, fontSize: 13, color: '#0F172A' }}>{d.day}</span>
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: editSchedule ? 'pointer' : 'default', fontSize: 12.5 }}>
                  <input
                    type="checkbox"
                    checked={d.isOpen}
                    disabled={!editSchedule}
                    onChange={() => setSchedule(prev => prev.map((x, j) => j === i ? { ...x, isOpen: !x.isOpen } : x))}
                  />
                  <span style={{ color: d.isOpen ? '#059669' : '#64748B', fontWeight: 600 }}>{d.isOpen ? 'Open' : 'Closed'}</span>
                </label>
                {d.isOpen && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <input type="time" value={d.open} disabled={!editSchedule} onChange={e => setSchedule(prev => prev.map((x, j) => j === i ? { ...x, open: e.target.value } : x))} style={{ ...inputStyle, width: 100 }} />
                    <span style={{ color: '#94A3B8', fontSize: 13 }}>to</span>
                    <input type="time" value={d.close} disabled={!editSchedule} onChange={e => setSchedule(prev => prev.map((x, j) => j === i ? { ...x, close: e.target.value } : x))} style={{ ...inputStyle, width: 100 }} />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Rules */}
      {activeTab === 'Rules' && (
        <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, padding: '22px' }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: '#0F172A', marginBottom: 18 }}>Academic & Access Rules</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {[
              { key: 'linkCampus', label: 'Link to Campus', sub: 'Restrict access to students enrolled at this campus' },
              { key: 'deptAccess', label: 'Department-based Access', sub: 'Allow only specific departments to access certain services' },
              { key: 'autoNotify', label: 'Auto-notify Faculty for Absences', sub: 'Automatically notify faculty advisor when a medical certificate is issued' },
            ].map(({ key, label, sub }) => (
              <div key={key} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', background: '#F8FAFC', borderRadius: 9 }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 13, color: '#0F172A' }}>{label}</div>
                  <div style={{ fontSize: 12, color: '#64748B', marginTop: 2 }}>{sub}</div>
                </div>
                <label style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
                  <input type="checkbox" checked={rules[key]} onChange={e => setRules(p => ({ ...p, [key]: e.target.checked }))} />
                </label>
              </div>
            ))}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', background: '#F8FAFC', borderRadius: 9 }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 13, color: '#0F172A' }}>Service Visits Limit</div>
                <div style={{ fontSize: 12, color: '#64748B', marginTop: 2 }}>Max visits per student per semester</div>
              </div>
              <input type="number" value={rules.limitPerStudent} min={1} max={20} onChange={e => setRules(p => ({ ...p, limitPerStudent: +e.target.value }))} style={{ ...inputStyle, width: 80 }} />
            </div>
          </div>
          <div style={{ marginTop: 18 }}>
            <button onClick={() => toast('Academic rules saved!')} style={{ padding: '9px 20px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
              Save Rules
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
