﻿export default function HealthCentreDetail() {
  return (
    <div style={{ padding: 32 }}>
      <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>HealthCentreDetail</div>
      <div style={{ color: '#6B7280', fontSize: 13 }}>This admin page is under construction.</div>
    </div>
  );
}

