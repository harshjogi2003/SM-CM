import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const TYPE_COLORS = {
  Medical:     { color: '#2563EB', bg: '#EFF6FF' },
  Counselling: { color: '#7C3AED', bg: '#F5F3FF' },
  Dental:      { color: '#0891B2', bg: '#F0FDFA' },
  Emergency:   { color: '#DC2626', bg: '#FEF2F2' },
};

const EMPTY_FORM = { name: '', location: '', phone: '', email: '', timing: '', type: 'Medical', walk_in_enabled: false, active: true };

const inputStyle = {
  width: '100%', padding: '9px 13px', borderRadius: 8,
  border: '1.5px solid #E2E8F0', fontSize: 13, boxSizing: 'border-box',
  background: '#fff', color: '#0F172A', outline: 'none',
};
const labelStyle = { display: 'block', fontSize: 12, fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 5 };

export default function HealthCentres() {
  const navigate = useNavigate();
  const { apiFetch, toast } = useApp();
  const [centres, setCentres] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    try { setCentres(await apiFetch('/masters/centres')); }
    catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const openNew  = () => { setEditItem(null); setForm(EMPTY_FORM); setShowModal(true); };
  const openEdit = (item) => { setEditItem(item); setForm({ ...item }); setShowModal(true); };

  const save = async (e) => {
    e.preventDefault();
    if (!form.name) { toast('Name is required', 'error'); return; }
    setSubmitting(true);
    try {
      if (editItem) {
        await apiFetch(`/masters/centres/${editItem.id}`, { method: 'PATCH', body: JSON.stringify(form) });
        toast('Health centre updated');
      } else {
        await apiFetch('/masters/centres', { method: 'POST', body: JSON.stringify(form) });
        toast('Health centre created');
      }
      setShowModal(false);
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setSubmitting(false); }
  };

  const remove = async (id, name) => {
    if (!window.confirm(`Delete "${name}"? This cannot be undone.`)) return;
    try {
      await apiFetch(`/masters/centres/${id}`, { method: 'DELETE' });
      toast('Health centre deleted');
      load();
    } catch (e) { toast(e.message, 'error'); }
  };

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Health Centres</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Manage campus health facilities and their configurations</div>
        </div>
        <button onClick={openNew} style={{ padding: '9px 18px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
          + Create Health Centre
        </button>
      </div>

      {/* Grid */}
      {loading ? (
        <div style={{ color: '#94A3B8', fontSize: 13 }}>Loading...</div>
      ) : centres.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '48px', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, color: '#94A3B8' }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 8 }}>No health centres configured</div>
          <button onClick={openNew} style={{ padding: '8px 20px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600, fontSize: 13 }}>Create First</button>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))', gap: 16 }}>
          {centres.map(hc => {
            const tc = TYPE_COLORS[hc.type] || { color: '#64748B', bg: '#F1F5F9' };
            return (
              <div
                key={hc.id}
                style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, padding: '20px', cursor: 'pointer', transition: 'box-shadow .15s' }}
                onClick={() => navigate(`/health-centres/${hc.id}`)}
                onMouseEnter={e => { e.currentTarget.style.boxShadow = '0 4px 16px rgba(0,0,0,.08)'; e.currentTarget.style.borderColor = '#2563EB33'; }}
                onMouseLeave={e => { e.currentTarget.style.boxShadow = 'none'; e.currentTarget.style.borderColor = '#E2E8F0'; }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                  <div style={{ width: 40, height: 40, borderRadius: 10, background: tc.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, color: tc.color, fontWeight: 900 }}>+</div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 700, background: hc.active !== 0 ? '#ECFDF5' : '#F1F5F9', color: hc.active !== 0 ? '#059669' : '#64748B' }}>
                      {hc.active !== 0 ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </div>

                <div style={{ fontWeight: 800, fontSize: 14, color: '#0F172A', marginBottom: 3, letterSpacing: '-0.01em' }}>{hc.name}</div>
                {hc.location && <div style={{ fontSize: 12.5, color: '#64748B', marginBottom: 8 }}>{hc.location}</div>}
                {hc.timing && <div style={{ fontSize: 12, color: '#94A3B8', marginBottom: 10 }}>{hc.timing}</div>}

                {hc.type && (
                  <span style={{ display: 'inline-block', padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 700, background: tc.bg, color: tc.color, marginBottom: 12 }}>
                    {hc.type}
                  </span>
                )}

                <div style={{ display: 'flex', gap: 8, paddingTop: 12, borderTop: '1px solid #F1F5F9' }} onClick={e => e.stopPropagation()}>
                  <button
                    onClick={() => openEdit(hc)}
                    style={{ flex: 1, padding: '6px', background: '#F8FAFC', color: '#374151', border: '1px solid #E2E8F0', borderRadius: 7, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => remove(hc.id, hc.name)}
                    style={{ padding: '6px 12px', background: '#FEF2F2', color: '#DC2626', border: '1px solid #FECACA', borderRadius: 7, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 20 }}>
          <div style={{ background: '#fff', borderRadius: 14, width: '100%', maxWidth: 520, padding: '28px', boxShadow: '0 20px 60px rgba(0,0,0,.2)', maxHeight: '90vh', overflowY: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 20 }}>
              <div style={{ fontSize: 17, fontWeight: 800, color: '#0F172A', letterSpacing: '-0.01em' }}>
                {editItem ? 'Edit Health Centre' : 'Create Health Centre'}
              </div>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', border: 'none', fontSize: 22, color: '#94A3B8', cursor: 'pointer', lineHeight: 1 }}>×</button>
            </div>
            <form onSubmit={save}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                <div>
                  <label style={labelStyle}>Name *</label>
                  <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required placeholder="e.g. Main Campus Clinic" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Type</label>
                  <select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))} style={inputStyle}>
                    <option>Medical</option>
                    <option>Counselling</option>
                    <option>Dental</option>
                    <option>Emergency</option>
                  </select>
                </div>
              </div>
              <div style={{ marginBottom: 14 }}>
                <label style={labelStyle}>Location</label>
                <input value={form.location || ''} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} placeholder="e.g. Bavdhan Campus, Block A" style={inputStyle} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                <div>
                  <label style={labelStyle}>Phone</label>
                  <input value={form.phone || ''} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+91 20 0000 0000" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Timing</label>
                  <input value={form.timing || ''} onChange={e => setForm(f => ({ ...f, timing: e.target.value }))} placeholder="e.g. 8 AM – 8 PM" style={inputStyle} />
                </div>
              </div>
              <div style={{ display: 'flex', gap: 16, marginBottom: 22 }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 13 }}>
                  <input type="checkbox" checked={form.walk_in_enabled} onChange={e => setForm(f => ({ ...f, walk_in_enabled: e.target.checked }))} />
                  Walk-in Allowed
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 13 }}>
                  <input type="checkbox" checked={form.active} onChange={e => setForm(f => ({ ...f, active: e.target.checked }))} />
                  Active
                </label>
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button type="button" onClick={() => setShowModal(false)} style={{ flex: 1, padding: '10px', background: '#F1F5F9', color: '#374151', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer', fontSize: 13 }}>Cancel</button>
                <button type="submit" disabled={submitting} style={{ flex: 2, padding: '10px', background: submitting ? '#93C5FD' : '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, cursor: submitting ? 'not-allowed' : 'pointer', fontSize: 13 }}>
                  {submitting ? 'Saving...' : editItem ? 'Save Changes' : 'Create Centre'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
