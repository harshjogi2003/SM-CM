import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const MASTER_CONFIG = {
  centres: {
    label: 'Health Centres',
    apiKey: 'centres',
    columns: [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'location', label: 'Location', type: 'text' },
      { key: 'contact_phone', label: 'Phone', type: 'text' },
      { key: 'active', label: 'Active', type: 'boolean' },
    ],
  },
  services: {
    label: 'Services',
    apiKey: 'services',
    columns: [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'category', label: 'Category', type: 'text' },
      { key: 'default_duration_min', label: 'Duration (min)', type: 'number' },
      { key: 'active', label: 'Active', type: 'boolean' },
    ],
  },
  providers: {
    label: 'Providers',
    apiKey: 'providers',
    columns: [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'specialty', label: 'Specialty', type: 'text' },
      { key: 'centre_id', label: 'Centre ID', type: 'number' },
      { key: 'active', label: 'Active', type: 'boolean' },
    ],
  },
  schedules: {
    label: 'Schedules',
    apiKey: 'schedules',
    columns: [
      { key: 'provider_id', label: 'Provider ID', type: 'number' },
      { key: 'slot_duration_min', label: 'Slot Duration (min)', type: 'number' },
      { key: 'buffer_min', label: 'Buffer (min)', type: 'number' },
    ],
  },
  'triage-rules': {
    label: 'Triage Rules',
    apiKey: 'triage_rules',
    columns: [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'priority', label: 'Priority', type: 'number' },
      { key: 'active', label: 'Active', type: 'boolean' },
    ],
  },
  'certificate-types': {
    label: 'Certificate Types',
    apiKey: 'certificate_types',
    columns: [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'requires_encounter', label: 'Requires Encounter', type: 'boolean' },
      { key: 'default_validity_days', label: 'Validity (days)', type: 'number' },
      { key: 'active', label: 'Active', type: 'boolean' },
    ],
  },
  'concern-categories': {
    label: 'Concern Categories',
    apiKey: 'concern_categories',
    columns: [
      { key: 'name', label: 'Name', type: 'text' },
      { key: 'icon', label: 'Icon', type: 'text' },
      { key: 'default_urgency', label: 'Default Urgency', type: 'text' },
      { key: 'active', label: 'Active', type: 'boolean' },
    ],
  },
  holidays: {
    label: 'Holidays',
    apiKey: 'holidays',
    columns: [
      { key: 'date', label: 'Date', type: 'date' },
      { key: 'name', label: 'Name', type: 'text' },
    ],
  },
  settings: {
    label: 'General Settings',
    apiKey: null, // special: uses /settings endpoint
    isSettings: true,
  },
};

function FieldInput({ col, value, onChange }) {
  if (col.type === 'boolean') {
    return (
      <input type="checkbox" checked={!!value} onChange={e => onChange(e.target.checked)}
        style={{ width: 16, height: 16, cursor: 'pointer' }} />
    );
  }
  if (col.type === 'number') {
    return (
      <input type="number" value={value ?? ''} onChange={e => onChange(e.target.value === '' ? '' : Number(e.target.value))}
        style={{ width: '100%', padding: '8px 10px', borderRadius: 7, border: '1.5px solid #D1D5DB', fontSize: 13, boxSizing: 'border-box' }} />
    );
  }
  if (col.type === 'date') {
    return (
      <input type="date" value={value ?? ''} onChange={e => onChange(e.target.value)}
        style={{ width: '100%', padding: '8px 10px', borderRadius: 7, border: '1.5px solid #D1D5DB', fontSize: 13, boxSizing: 'border-box' }} />
    );
  }
  return (
    <input type="text" value={value ?? ''} onChange={e => onChange(e.target.value)}
      style={{ width: '100%', padding: '8px 10px', borderRadius: 7, border: '1.5px solid #D1D5DB', fontSize: 13, boxSizing: 'border-box' }} />
  );
}

function SettingsForm({ apiFetch, toast }) {
  const [settings, setSettings] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    apiFetch('/settings').then(setSettings).catch(() => {});
  }, [apiFetch]);

  const save = async () => {
    setSaving(true);
    try {
      await apiFetch('/settings', { method: 'PATCH', body: JSON.stringify(settings) });
      toast('Settings saved');
    } catch (e) { toast(e.message, 'error'); }
    finally { setSaving(false); }
  };

  if (!settings) return <div style={{ color: '#6B7280' }}>Loading settings…</div>;

  const flatFields = [
    { key: 'institute_name', label: 'Institute Name' },
    { key: 'office_hours', label: 'Office Hours' },
    { key: 'booking_horizon_days', label: 'Booking Horizon (days)', type: 'number' },
    { key: 'min_lead_time_hours', label: 'Min Lead Time (hours)', type: 'number' },
    { key: 'cancellation_lead_time_hours', label: 'Cancellation Lead Time (hours)', type: 'number' },
  ];

  const ecFields = [
    { key: 'counsellor_oncall', label: 'Counsellor On-Call' },
    { key: 'campus_security', label: 'Campus Security' },
    { key: 'national_mental_health', label: 'National Mental Health' },
  ];

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 20 }}>
        {flatFields.map(f => (
          <div key={f.key}>
            <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 5 }}>{f.label}</label>
            <input
              type={f.type || 'text'}
              value={settings[f.key] ?? ''}
              onChange={e => setSettings(s => ({ ...s, [f.key]: f.type === 'number' ? Number(e.target.value) : e.target.value }))}
              style={{ width: '100%', padding: '9px 12px', borderRadius: 8, border: '1.5px solid #D1D5DB', fontSize: 13, boxSizing: 'border-box' }} />
          </div>
        ))}
      </div>
      <div style={{ fontSize: 13, fontWeight: 700, color: '#0F172A', marginBottom: 10 }}>Emergency Contacts</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14, marginBottom: 20 }}>
        {ecFields.map(f => (
          <div key={f.key}>
            <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 5 }}>{f.label}</label>
            <input type="text" value={settings.emergency_contacts?.[f.key] ?? ''}
              onChange={e => setSettings(s => ({ ...s, emergency_contacts: { ...s.emergency_contacts, [f.key]: e.target.value } }))}
              style={{ width: '100%', padding: '9px 12px', borderRadius: 8, border: '1.5px solid #D1D5DB', fontSize: 13, boxSizing: 'border-box' }} />
          </div>
        ))}
      </div>
      <button onClick={save} disabled={saving}
        style={{ padding: '10px 24px', background: '#EF4444', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
        {saving ? 'Saving…' : 'Save Settings'}
      </button>
    </div>
  );
}

export default function MasterEditor() {
  const { master } = useParams();
  const navigate = useNavigate();
  const { apiFetch, toast } = useApp();

  const config = MASTER_CONFIG[master];

  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [isNew, setIsNew] = useState(false);
  const [saving, setSaving] = useState(false);

  const apiPath = config?.apiKey ? `/masters/${master}` : null;

  const load = useCallback(async () => {
    if (!config || config.isSettings) { setLoading(false); return; }
    setLoading(true);
    try {
      const data = await apiFetch(apiPath);
      setItems(data);
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setLoading(false);
    }
  }, [apiFetch, toast, config, apiPath]);

  useEffect(() => { load(); }, [load]);

  if (!config) {
    return <div style={{ padding: 32, color: '#6B7280' }}>Unknown master: {master}</div>;
  }

  const openNew = () => {
    const blank = {};
    config.columns?.forEach(c => { blank[c.key] = c.type === 'boolean' ? false : c.type === 'number' ? 0 : ''; });
    setEditItem(blank);
    setIsNew(true);
    setDrawerOpen(true);
  };

  const openEdit = (item) => {
    setEditItem({ ...item });
    setIsNew(false);
    setDrawerOpen(true);
  };

  const save = async () => {
    setSaving(true);
    try {
      if (isNew) {
        await apiFetch(apiPath, { method: 'POST', body: JSON.stringify(editItem) });
        toast('Item created');
      } else {
        await apiFetch(`${apiPath}/${editItem.id}`, { method: 'PATCH', body: JSON.stringify(editItem) });
        toast('Item updated');
      }
      setDrawerOpen(false);
      load();
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const softDelete = async (id) => {
    if (!confirm('Deactivate this item?')) return;
    try {
      await apiFetch(`${apiPath}/${id}`, { method: 'DELETE' });
      toast('Item deactivated');
      load();
    } catch (e) { toast(e.message, 'error'); }
  };

  return (
    <div style={{ padding: '24px 28px', maxWidth: 1000 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <button onClick={() => navigate('/config')} style={{ background: 'none', border: 'none', color: '#6B7280', cursor: 'pointer', fontSize: 13, padding: 0 }}>← Configuration</button>
          </div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0 }}>{config.label}</h1>
        </div>
        {!config.isSettings && (
          <button onClick={openNew} style={{ padding: '9px 18px', background: '#EF4444', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>+ Add New</button>
        )}
      </div>

      <div style={{ background: '#fff', border: '1px solid #E5E7EB', borderRadius: 12, padding: '24px' }}>
        {config.isSettings ? (
          <SettingsForm apiFetch={apiFetch} toast={toast} />
        ) : loading ? (
          <div style={{ color: '#6B7280' }}>Loading…</div>
        ) : items.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px 0', color: '#9CA3AF' }}>
            <div style={{ fontSize: 32, marginBottom: 10 }}>📋</div>
            <div style={{ fontWeight: 600, marginBottom: 10 }}>No items configured</div>
            <button onClick={openNew} style={{ padding: '8px 20px', background: '#EF4444', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600 }}>Add First Item</button>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: '#F8FAFC' }}>
                  <th style={{ padding: '10px 14px', textAlign: 'left', fontSize: 12, fontWeight: 700, color: '#374151', borderBottom: '1px solid #E5E7EB' }}>ID</th>
                  {config.columns.map(c => (
                    <th key={c.key} style={{ padding: '10px 14px', textAlign: 'left', fontSize: 12, fontWeight: 700, color: '#374151', borderBottom: '1px solid #E5E7EB' }}>{c.label}</th>
                  ))}
                  <th style={{ padding: '10px 14px', textAlign: 'right', fontSize: 12, fontWeight: 700, color: '#374151', borderBottom: '1px solid #E5E7EB' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {items.map(item => (
                  <tr key={item.id} style={{ borderBottom: '1px solid #F1F5F9' }}
                    onMouseEnter={e => e.currentTarget.style.background = '#F8FAFC'}
                    onMouseLeave={e => e.currentTarget.style.background = 'none'}>
                    <td style={{ padding: '10px 14px', fontSize: 12, color: '#9CA3AF' }}>{item.id}</td>
                    {config.columns.map(c => (
                      <td key={c.key} style={{ padding: '10px 14px', fontSize: 13, color: '#0F172A' }}>
                        {c.type === 'boolean'
                          ? (item[c.key] ? <span style={{ color: '#059669', fontWeight: 600, fontSize: 12 }}>Yes</span> : <span style={{ color: '#9CA3AF', fontSize: 12 }}>No</span>)
                          : String(item[c.key] ?? '—')}
                      </td>
                    ))}
                    <td style={{ padding: '10px 14px', textAlign: 'right' }}>
                      <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                        <button onClick={() => openEdit(item)}
                          style={{ padding: '5px 12px', background: '#EFF6FF', color: '#2563EB', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Edit</button>
                        <button onClick={() => softDelete(item.id)}
                          style={{ padding: '5px 12px', background: '#FEF2F2', color: '#DC2626', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Deactivate</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Side drawer */}
      {drawerOpen && editItem && (
        <>
          <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.3)', zIndex: 900 }} onClick={() => setDrawerOpen(false)} />
          <div style={{ position: 'fixed', top: 0, right: 0, bottom: 0, width: 400, background: '#fff', boxShadow: '-4px 0 20px rgba(0,0,0,.15)', zIndex: 1000, display: 'flex', flexDirection: 'column', transition: 'transform .2s' }}>
            <div style={{ padding: '20px 24px', borderBottom: '1px solid #E5E7EB', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontWeight: 700, fontSize: 15, color: '#0F172A' }}>{isNew ? 'Add New Item' : 'Edit Item'}</div>
              <button onClick={() => setDrawerOpen(false)} style={{ background: 'none', border: 'none', fontSize: 20, cursor: 'pointer', color: '#6B7280' }}>×</button>
            </div>
            <div style={{ flex: 1, overflowY: 'auto', padding: '20px 24px' }}>
              {config.columns?.map(col => (
                <div key={col.key} style={{ marginBottom: 14 }}>
                  <label style={{ fontSize: 12.5, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 5 }}>{col.label}</label>
                  <FieldInput
                    col={col}
                    value={editItem[col.key]}
                    onChange={val => setEditItem(prev => ({ ...prev, [col.key]: val }))}
                  />
                </div>
              ))}
            </div>
            <div style={{ padding: '16px 24px', borderTop: '1px solid #E5E7EB', display: 'flex', gap: 10 }}>
              <button onClick={() => setDrawerOpen(false)} style={{ flex: 1, padding: '10px', background: '#F3F4F6', color: '#374151', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>Cancel</button>
              <button onClick={save} disabled={saving} style={{ flex: 1, padding: '10px', background: '#EF4444', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, cursor: 'pointer' }}>
                {saving ? 'Saving…' : 'Save'}
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
