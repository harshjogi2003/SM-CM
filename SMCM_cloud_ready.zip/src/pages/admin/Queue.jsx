import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { urgencyColor, urgencyLabel, urgencyBg, urgencyText } from '../../utils/urgency';

const STATUS_STYLE = {
  upcoming:    { bg: '#EFF6FF', color: '#2563EB', label: 'Waiting' },
  in_progress: { bg: '#FFFBEB', color: '#D97706', label: 'In Progress' },
  completed:   { bg: '#ECFDF5', color: '#059669', label: 'Done' },
  cancelled:   { bg: '#F1F5F9', color: '#94A3B8', label: 'Cancelled' },
  waiting:     { bg: '#EFF6FF', color: '#2563EB', label: 'Waiting' },
  done:        { bg: '#ECFDF5', color: '#059669', label: 'Done' },
};

const FILTERS = ['all', 'waiting', 'in_progress', 'completed'];

export default function Queue() {
  const { apiFetch, toast } = useApp();
  const navigate = useNavigate();
  const [queue, setQueue] = useState([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(null);
  const [filter, setFilter] = useState('all');

  const load = useCallback(async () => {
    setLoading(true);
    try { setQueue(await apiFetch('/queue')); }
    catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const updateStatus = async (id, status, isWalkin) => {
    setUpdating(id);
    try {
      const endpoint = isWalkin ? `/walk-in/${id}` : `/appointments/${id}`;
      await apiFetch(endpoint, { method: 'PATCH', body: JSON.stringify({ status }) });
      toast(status === 'in_progress' ? 'Consultation started' : 'Status updated');
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setUpdating(null); }
  };

  const counts = {
    total:       queue.length,
    in_progress: queue.filter(q => q.status === 'in_progress').length,
    waiting:     queue.filter(q => q.status === 'upcoming' || q.status === 'waiting').length,
    urgent:      queue.filter(q => (q.urgency || 1) >= 3).length,
  };

  const filtered = filter === 'all' ? queue
    : filter === 'waiting' ? queue.filter(q => q.status === 'upcoming' || q.status === 'waiting')
    : queue.filter(q => q.status === filter);

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Live Request Queue</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Today's appointments and walk-in visits</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => navigate('/walkin')} style={{ padding: '8px 16px', background: '#F8FAFC', color: '#475569', border: '1px solid #E2E8F0', borderRadius: 8, fontWeight: 600, fontSize: 12.5, cursor: 'pointer' }}>
            + Walk-in
          </button>
          <button onClick={load} style={{ padding: '8px 16px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, fontSize: 12.5, cursor: 'pointer' }}>
            Refresh
          </button>
        </div>
      </div>

      {/* Stats strip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 20 }}>
        {[
          { label: 'In Queue',    val: counts.total,       color: '#2563EB', bg: '#EFF6FF' },
          { label: 'In Progress', val: counts.in_progress, color: '#D97706', bg: '#FFFBEB' },
          { label: 'Waiting',     val: counts.waiting,     color: '#059669', bg: '#ECFDF5' },
          { label: 'Urgent',      val: counts.urgent,      color: '#DC2626', bg: '#FEF2F2' },
        ].map(s => (
          <div key={s.label} style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, padding: '14px 18px' }}>
            <div style={{ fontSize: 11.5, color: '#94A3B8', fontWeight: 600, marginBottom: 6 }}>{s.label}</div>
            <div style={{ fontSize: 28, fontWeight: 800, color: s.color, letterSpacing: '-0.02em' }}>{s.val}</div>
          </div>
        ))}
      </div>

      {/* Filter chips */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {FILTERS.map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            style={{
              padding: '6px 14px', borderRadius: 20, fontSize: 12.5, fontWeight: 600, cursor: 'pointer', border: 'none',
              background: filter === f ? '#0F172A' : '#F1F5F9',
              color: filter === f ? '#fff' : '#64748B',
              transition: 'all .12s',
            }}
          >
            {f === 'all' ? 'All' : f === 'in_progress' ? 'In Progress' : f.charAt(0).toUpperCase() + f.slice(1)}
            {f === 'all' && ` (${counts.total})`}
            {f === 'in_progress' && ` (${counts.in_progress})`}
            {f === 'waiting' && ` (${counts.waiting})`}
          </button>
        ))}
      </div>

      {/* Queue list */}
      {loading ? (
        <div style={{ padding: 40, color: '#94A3B8', fontSize: 13, textAlign: 'center' }}>Loading queue...</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#94A3B8' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>—</div>
          <div style={{ fontWeight: 600, fontSize: 14 }}>{filter === 'all' ? 'Queue is empty' : `No ${filter === 'in_progress' ? 'in-progress' : filter} items`}</div>
          <div style={{ fontSize: 12.5, marginTop: 4 }}>No patients currently in this category</div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {filtered.map((q, i) => {
            const isWalkin = q.is_walkin || false;
            const ss = STATUS_STYLE[q.status] || STATUS_STYLE.upcoming;
            const uLevel = q.urgency || 1;
            return (
              <div key={q.id} style={{
                background: '#fff', border: '1px solid #E2E8F0',
                borderLeft: `4px solid ${uLevel >= 3 ? urgencyColor(uLevel) : ss.color}`,
                borderRadius: 10, padding: '16px 20px',
                display: 'flex', alignItems: 'center', gap: 16,
              }}>
                {/* Number / token */}
                <div style={{
                  width: 34, height: 34, borderRadius: '50%', background: ss.bg, color: ss.color,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 12, flexShrink: 0,
                }}>
                  {isWalkin ? `W${q.token_number || '?'}` : `${i + 1}`}
                </div>

                {/* Patient info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4, flexWrap: 'wrap' }}>
                    <span style={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>{q.student_name}</span>
                    <span style={{ fontSize: 12, color: '#94A3B8' }}>{q.s_id}</span>
                    {q.year && <span style={{ fontSize: 12, color: '#94A3B8' }}>{q.year}</span>}
                    <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600, background: ss.bg, color: ss.color }}>{ss.label}</span>
                    {isWalkin && <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 10, fontWeight: 700, background: '#FFFBEB', color: '#D97706' }}>WALK-IN</span>}
                    {uLevel >= 2 && (
                      <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 10, fontWeight: 700, background: urgencyBg(uLevel), color: urgencyText(uLevel) }}>
                        {urgencyLabel(uLevel)}
                      </span>
                    )}
                  </div>
                  <div style={{ fontSize: 12.5, color: '#374151', marginBottom: 2 }}>
                    {q.service}{!isWalkin && q.health_centre ? ` · ${q.health_centre}` : ''}
                  </div>
                  {!isWalkin && (
                    <div style={{ fontSize: 11.5, color: '#94A3B8' }}>
                      {q.doctor} · {q.date} at {q.time}
                    </div>
                  )}
                  {isWalkin && (
                    <div style={{ fontSize: 11.5, color: '#94A3B8' }}>
                      Arrived: {new Date(q.created_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  )}
                  {(q.complaint || q.reason) && (
                    <div style={{ fontSize: 11.5, color: '#64748B', marginTop: 3, fontStyle: 'italic' }}>
                      "{q.complaint || q.reason}"
                    </div>
                  )}
                  {q.blood_group && (
                    <div style={{ display: 'flex', gap: 6, marginTop: 5 }}>
                      <span style={{ padding: '1px 7px', background: '#FEF2F2', color: '#DC2626', borderRadius: 4, fontSize: 11, fontWeight: 600 }}>
                        {q.blood_group}
                      </span>
                      {q.allergies && q.allergies !== 'None' && (
                        <span style={{ padding: '1px 7px', background: '#FFFBEB', color: '#D97706', borderRadius: 4, fontSize: 11 }}>
                          Allergy: {q.allergies}
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div style={{ display: 'flex', gap: 8, flexShrink: 0, alignItems: 'center' }}>
                  {!isWalkin && (
                    <button
                      onClick={() => navigate(`/consultation/${q.id}`)}
                      style={{ padding: '7px 16px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 7, fontSize: 12.5, fontWeight: 600, cursor: 'pointer' }}
                    >
                      Consult
                    </button>
                  )}
                  {(q.status === 'upcoming' || q.status === 'waiting') && (
                    <button
                      onClick={() => updateStatus(q.id, 'in_progress', isWalkin)}
                      disabled={updating === q.id}
                      style={{ padding: '7px 14px', background: '#FFFBEB', color: '#D97706', border: '1px solid #FDE68A', borderRadius: 7, fontSize: 12.5, fontWeight: 600, cursor: 'pointer' }}
                    >
                      {updating === q.id ? '...' : 'Mark Active'}
                    </button>
                  )}
                  {q.status === 'in_progress' && (
                    <button
                      onClick={() => updateStatus(q.id, isWalkin ? 'done' : 'completed', isWalkin)}
                      disabled={updating === q.id}
                      style={{ padding: '7px 14px', background: '#ECFDF5', color: '#059669', border: '1px solid #A7F3D0', borderRadius: 7, fontSize: 12.5, fontWeight: 600, cursor: 'pointer' }}
                    >
                      {updating === q.id ? '...' : 'Mark Done'}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
