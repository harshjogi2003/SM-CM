import { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';

export default function Records() {
  const { apiFetch, toast } = useApp();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    apiFetch('/records')
      .then(setRecords)
      .catch(e => toast(e.message, 'error'))
      .finally(() => setLoading(false));
  }, [apiFetch, toast]);

  const filtered = search
    ? records.filter(r =>
        (r.student_name || '').toLowerCase().includes(search.toLowerCase()) ||
        (r.service || '').toLowerCase().includes(search.toLowerCase()) ||
        (r.s_id || '').toLowerCase().includes(search.toLowerCase())
      )
    : records;

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Health Records</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>
            {filtered.length} record{filtered.length !== 1 ? 's' : ''}{search ? ` matching "${search}"` : ' total'}
          </div>
        </div>
        <div style={{ position: 'relative' }}>
          <input
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search student, service..."
            style={{
              padding: '9px 14px 9px 36px', borderRadius: 8, border: '1.5px solid #E2E8F0',
              fontSize: 13, width: 260, background: '#fff', color: '#0F172A', outline: 'none',
            }}
          />
          <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#94A3B8', fontSize: 13 }}>⌕</span>
        </div>
      </div>

      {loading ? (
        <div style={{ padding: 40, color: '#94A3B8', fontSize: 13, textAlign: 'center' }}>Loading records...</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#94A3B8' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>—</div>
          <div style={{ fontWeight: 600, fontSize: 14 }}>{search ? 'No matching records' : 'No records yet'}</div>
        </div>
      ) : (
        <>
          {/* Table header */}
          <div style={{
            display: 'grid', gridTemplateColumns: '2fr 2fr 1fr 2fr 24px',
            gap: 12, padding: '8px 20px', marginBottom: 4,
          }}>
            {['Student', 'Service / Doctor', 'Date', 'Diagnosis', ''].map(h => (
              <div key={h} style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{h}</div>
            ))}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {filtered.map(r => (
              <div key={r.id} style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, overflow: 'hidden' }}>
                {/* Row */}
                <div
                  style={{ display: 'grid', gridTemplateColumns: '2fr 2fr 1fr 2fr 24px', gap: 12, padding: '13px 20px', alignItems: 'center', cursor: 'pointer' }}
                  onClick={() => setExpanded(expanded === r.id ? null : r.id)}
                >
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 13, color: '#0F172A' }}>{r.student_name}</div>
                    <div style={{ fontSize: 11.5, color: '#94A3B8', marginTop: 1 }}>{r.s_id} · {r.year}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 13, color: '#374151' }}>{r.service}</div>
                    {r.doctor && <div style={{ fontSize: 11.5, color: '#94A3B8', marginTop: 1 }}>{r.doctor}</div>}
                  </div>
                  <div style={{ fontSize: 12.5, color: '#64748B' }}>{r.date}</div>
                  <div style={{ fontSize: 12.5, color: '#374151', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {r.diagnosis || '—'}
                  </div>
                  <span style={{ color: '#CBD5E1', fontSize: 12, textAlign: 'right' }}>{expanded === r.id ? '▲' : '▼'}</span>
                </div>

                {/* Expanded detail */}
                {expanded === r.id && (
                  <div style={{ borderTop: '1px solid #F1F5F9', padding: '16px 20px', background: '#F8FAFC' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 }}>
                      {[
                        ['Diagnosis', r.diagnosis],
                        ['Treatment / Plan', r.treatment],
                        ['Prescription', r.prescription],
                        ['Clinical Notes', r.notes],
                        ['Confidentiality', r.confidentiality],
                      ].map(([l, v]) => v ? (
                        <div key={l}>
                          <div style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>{l}</div>
                          <div style={{ fontSize: 13, color: '#374151', lineHeight: 1.5 }}>{v}</div>
                        </div>
                      ) : null)}

                      {r.vitals && Object.keys(r.vitals).length > 0 && (
                        <div>
                          <div style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 6 }}>Vitals</div>
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                            {Object.entries(r.vitals).filter(([, v]) => v).map(([k, v]) => (
                              <span key={k} style={{ padding: '2px 9px', background: '#EFF6FF', color: '#1D4ED8', borderRadius: 5, fontSize: 12, fontWeight: 500 }}>
                                {k}: {v}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
