import { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';

const EMPTY_FORM = { name: '', type: '', distance: '', contact: '', specialties: '' };

const inputStyle = { width: '100%', padding: '9px 13px', borderRadius: 8, border: '1.5px solid #E2E8F0', fontSize: 13, boxSizing: 'border-box', background: '#fff', color: '#0F172A', outline: 'none' };
const labelStyle = { display: 'block', fontSize: 12, fontWeight: 700, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 5 };

export default function ReferralDestinations() {
  const { apiFetch, toast } = useApp();
  const [dests, setDests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    try {
      // Providers table is used as referral destinations
      const data = await apiFetch('/masters/providers');
      setDests(data.filter(p => p.type === 'external' || p.specialty));
    } catch {
      // If no providers, use empty
      setDests([]);
    } finally { setLoading(false); }
  }, [apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const openNew  = () => { setEditItem(null); setForm(EMPTY_FORM); setShowModal(true); };
  const openEdit = (item) => {
    setEditItem(item);
    setForm({
      name: item.name || '',
      type: item.type || '',
      distance: item.distance || '',
      contact: item.contact || item.phone || '',
      specialties: Array.isArray(item.specialty) ? item.specialty.join(', ') : (item.specialty || ''),
    });
    setShowModal(true);
  };

  const save = async (e) => {
    e.preventDefault();
    if (!form.name) { toast('Name is required', 'error'); return; }
    setSubmitting(true);
    try {
      const payload = {
        name: form.name,
        type: 'external',
        specialty: form.specialties,
        phone: form.contact,
        notes: `${form.type} · ${form.distance}`,
      };
      if (editItem) {
        await apiFetch(`/masters/providers/${editItem.id}`, { method: 'PATCH', body: JSON.stringify(payload) });
        toast('Destination updated');
      } else {
        await apiFetch('/masters/providers', { method: 'POST', body: JSON.stringify(payload) });
        toast('Destination added');
      }
      setShowModal(false);
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setSubmitting(false); }
  };

  const remove = async (id, name) => {
    if (!window.confirm(`Delete "${name}"?`)) return;
    try {
      await apiFetch(`/masters/providers/${id}`, { method: 'DELETE' });
      toast('Destination removed');
      load();
    } catch (e) { toast(e.message, 'error'); }
  };

  const parseSpecialties = (val) => {
    if (Array.isArray(val)) return val;
    if (typeof val === 'string') return val.split(',').map(s => s.trim()).filter(Boolean);
    return [];
  };

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Referral Destinations</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Hospitals and external specialists for student referrals</div>
        </div>
        <button onClick={openNew} style={{ padding: '9px 18px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
          + Add Destination
        </button>
      </div>

      {loading ? (
        <div style={{ color: '#94A3B8', fontSize: 13 }}>Loading...</div>
      ) : dests.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '48px', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, color: '#94A3B8' }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 8 }}>No referral destinations configured</div>
          <button onClick={openNew} style={{ padding: '8px 20px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600, fontSize: 13 }}>Add First</button>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(300px,1fr))', gap: 14 }}>
          {dests.map(rd => {
            const specs = parseSpecialties(rd.specialty);
            return (
              <div key={rd.id} style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, padding: '18px 20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 38, height: 38, borderRadius: 9, background: '#EFF6FF', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, color: '#2563EB', fontWeight: 900 }}>+</div>
                    <div>
                      <div style={{ fontWeight: 800, fontSize: 14, color: '#0F172A' }}>{rd.name}</div>
                      {rd.type && <div style={{ fontSize: 12, color: '#64748B' }}>{rd.type}</div>}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button onClick={() => openEdit(rd)} style={{ padding: '4px 10px', background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 6, fontSize: 11.5, fontWeight: 600, cursor: 'pointer', color: '#374151' }}>Edit</button>
                    <button onClick={() => remove(rd.id, rd.name)} style={{ padding: '4px 10px', background: '#FEF2F2', border: '1px solid #FECACA', borderRadius: 6, fontSize: 11.5, fontWeight: 600, cursor: 'pointer', color: '#DC2626' }}>Del</button>
                  </div>
                </div>

                {rd.notes && <div style={{ fontSize: 12.5, color: '#64748B', marginBottom: 6 }}>{rd.notes}</div>}
                {rd.phone && <div style={{ fontSize: 12.5, color: '#374151', marginBottom: 8 }}>Tel: {rd.phone}</div>}

                {specs.length > 0 && (
                  <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                    {specs.map(s => (
                      <span key={s} style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11.5, fontWeight: 600, background: '#EFF6FF', color: '#2563EB' }}>{s}</span>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 20 }}>
          <div style={{ background: '#fff', borderRadius: 14, width: '100%', maxWidth: 460, padding: '28px', boxShadow: '0 20px 60px rgba(0,0,0,.2)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 20 }}>
              <div style={{ fontSize: 17, fontWeight: 800, color: '#0F172A' }}>{editItem ? 'Edit Destination' : 'Add Referral Destination'}</div>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', border: 'none', fontSize: 22, color: '#94A3B8', cursor: 'pointer', lineHeight: 1 }}>×</button>
            </div>
            <form onSubmit={save}>
              <div style={{ marginBottom: 14 }}>
                <label style={labelStyle}>Name *</label>
                <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required placeholder="e.g. Ruby Hall Clinic" style={inputStyle} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                <div>
                  <label style={labelStyle}>Type</label>
                  <input value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))} placeholder="e.g. Multi-specialty Hospital" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Distance</label>
                  <input value={form.distance} onChange={e => setForm(f => ({ ...f, distance: e.target.value }))} placeholder="e.g. 3.2 km" style={inputStyle} />
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                <div>
                  <label style={labelStyle}>Contact</label>
                  <input value={form.contact} onChange={e => setForm(f => ({ ...f, contact: e.target.value }))} placeholder="+91 …" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Specialties (comma-separated)</label>
                  <input value={form.specialties} onChange={e => setForm(f => ({ ...f, specialties: e.target.value }))} placeholder="Cardiology, Neurology" style={inputStyle} />
                </div>
              </div>
              <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
                <button type="button" onClick={() => setShowModal(false)} style={{ flex: 1, padding: '10px', background: '#F1F5F9', color: '#374151', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer', fontSize: 13 }}>Cancel</button>
                <button type="submit" disabled={submitting} style={{ flex: 2, padding: '10px', background: submitting ? '#93C5FD' : '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, cursor: submitting ? 'not-allowed' : 'pointer', fontSize: 13 }}>
                  {submitting ? 'Saving...' : editItem ? 'Save Changes' : 'Add'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
