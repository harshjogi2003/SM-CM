import { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';

const STATUS_STYLE = {
  pending:   { bg: '#FEF3C7', color: '#D97706', label: 'Pending' },
  accepted:  { bg: '#EFF6FF', color: '#2563EB', label: 'Accepted' },
  completed: { bg: '#ECFDF5', color: '#059669', label: 'Completed' },
  cancelled: { bg: '#F1F5F9', color: '#64748B', label: 'Cancelled' },
};

const inputStyle = {
  width: '100%', padding: '9px 12px', borderRadius: 8,
  border: '1.5px solid #E2E8F0', fontSize: 13, boxSizing: 'border-box',
  background: '#fff', color: '#0F172A', outline: 'none',
};
const labelStyle = {
  display: 'block', fontSize: 12, fontWeight: 700, color: '#64748B',
  textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 5,
};

export default function Referrals() {
  const { apiFetch, toast } = useApp();
  const [referrals, setReferrals] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ student_id: '', destination: '', reason: '', from_doctor: '', date: '', notes: '' });
  const [submitting, setSubmitting] = useState(false);
  const [updatingId, setUpdatingId] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [r, s] = await Promise.all([apiFetch('/referrals'), apiFetch('/students')]);
      setReferrals(r); setStudents(s);
    } catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await apiFetch('/referrals', { method: 'POST', body: JSON.stringify(form) });
      toast('Referral issued');
      setShowModal(false);
      setForm({ student_id: '', destination: '', reason: '', from_doctor: '', date: '', notes: '' });
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setSubmitting(false); }
  };

  const updateStatus = async (id, status) => {
    setUpdatingId(id);
    try {
      await apiFetch(`/referrals/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) });
      toast('Referral updated');
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setUpdatingId(null); }
  };

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Referrals</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>External and internal student referral management</div>
        </div>
        <button
          onClick={() => setShowModal(true)}
          style={{ padding: '9px 18px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}
        >
          + New Referral
        </button>
      </div>

      {loading ? (
        <div style={{ padding: 40, color: '#94A3B8', fontSize: 13, textAlign: 'center' }}>Loading referrals...</div>
      ) : referrals.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px 0', color: '#94A3B8' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>—</div>
          <div style={{ fontWeight: 600, fontSize: 14 }}>No referrals yet</div>
        </div>
      ) : (
        <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, overflow: 'hidden' }}>
          {/* Table header */}
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 2fr 1.5fr 2fr 1fr 1.2fr 1.5fr', gap: 12, padding: '10px 20px', background: '#F8FAFC', borderBottom: '1px solid #E2E8F0' }}>
            {['Student','Referred To','From Doctor','Reason','Date','Status','Actions'].map(h => (
              <div key={h} style={{ fontSize: 11, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{h}</div>
            ))}
          </div>

          {referrals.map((r, i) => {
            const ss = STATUS_STYLE[r.status] || STATUS_STYLE.pending;
            return (
              <div key={r.id} style={{
                display: 'grid', gridTemplateColumns: '2fr 2fr 1.5fr 2fr 1fr 1.2fr 1.5fr',
                gap: 12, padding: '13px 20px', borderBottom: i < referrals.length - 1 ? '1px solid #F1F5F9' : 'none',
                alignItems: 'center',
              }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 13, color: '#0F172A' }}>{r.student_name}</div>
                  <div style={{ fontSize: 11.5, color: '#94A3B8', marginTop: 1 }}>{r.s_id}</div>
                </div>
                <div style={{ fontSize: 13, color: '#374151', fontWeight: 600 }}>{r.destination}</div>
                <div style={{ fontSize: 12.5, color: '#64748B' }}>{r.from_doctor}</div>
                <div style={{ fontSize: 12.5, color: '#374151', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.reason}</div>
                <div style={{ fontSize: 12, color: '#94A3B8' }}>{r.date}</div>
                <div>
                  <span style={{ padding: '3px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 600, background: ss.bg, color: ss.color }}>{ss.label}</span>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  {r.status === 'pending' && (
                    <>
                      <button onClick={() => updateStatus(r.id, 'accepted')} disabled={updatingId === r.id} style={{ padding: '5px 10px', background: '#EFF6FF', color: '#2563EB', border: '1px solid #BFDBFE', borderRadius: 6, fontSize: 11.5, cursor: 'pointer', fontWeight: 600 }}>Accept</button>
                      <button onClick={() => updateStatus(r.id, 'cancelled')} disabled={updatingId === r.id} style={{ padding: '5px 10px', background: '#FEF2F2', color: '#DC2626', border: '1px solid #FECACA', borderRadius: 6, fontSize: 11.5, cursor: 'pointer', fontWeight: 600 }}>Cancel</button>
                    </>
                  )}
                  {r.status === 'accepted' && (
                    <button onClick={() => updateStatus(r.id, 'completed')} disabled={updatingId === r.id} style={{ padding: '5px 10px', background: '#ECFDF5', color: '#059669', border: '1px solid #A7F3D0', borderRadius: 6, fontSize: 11.5, cursor: 'pointer', fontWeight: 600 }}>Done</button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* New Referral Modal */}
      {showModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 20 }}>
          <div style={{ background: '#fff', borderRadius: 12, width: '100%', maxWidth: 520, padding: '28px', boxShadow: '0 20px 60px rgba(0,0,0,0.2)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 }}>
              <div style={{ fontSize: 16, fontWeight: 800, color: '#0F172A', letterSpacing: '-0.02em' }}>Issue New Referral</div>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 20, color: '#94A3B8', lineHeight: 1 }}>×</button>
            </div>
            <form onSubmit={submit}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                <div>
                  <label style={labelStyle}>Student *</label>
                  <select required value={form.student_id} onChange={e => setForm(f => ({ ...f, student_id: e.target.value }))} style={inputStyle}>
                    <option value="">Select student...</option>
                    {students.map(s => <option key={s.id} value={s.id}>{s.name} ({s.student_id})</option>)}
                  </select>
                </div>
                <div>
                  <label style={labelStyle}>Referring Doctor *</label>
                  <input required value={form.from_doctor} onChange={e => setForm(f => ({ ...f, from_doctor: e.target.value }))} placeholder="Dr. Name" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Destination *</label>
                  <input required value={form.destination} onChange={e => setForm(f => ({ ...f, destination: e.target.value }))} placeholder="Hospital / Specialist" style={inputStyle} />
                </div>
                <div>
                  <label style={labelStyle}>Date</label>
                  <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} style={inputStyle} />
                </div>
              </div>
              <div style={{ marginBottom: 14 }}>
                <label style={labelStyle}>Reason *</label>
                <textarea required value={form.reason} onChange={e => setForm(f => ({ ...f, reason: e.target.value }))} rows={3} placeholder="Clinical reason for referral..." style={{ ...inputStyle, resize: 'vertical', lineHeight: 1.5 }} />
              </div>
              <div style={{ marginBottom: 20 }}>
                <label style={labelStyle}>Notes</label>
                <input value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Additional notes (optional)" style={inputStyle} />
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button type="button" onClick={() => setShowModal(false)} style={{ flex: 1, padding: '10px', background: '#F1F5F9', color: '#475569', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer' }}>Cancel</button>
                <button type="submit" disabled={submitting} style={{ flex: 1, padding: '10px', background: submitting ? '#93C5FD' : '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, cursor: submitting ? 'not-allowed' : 'pointer' }}>
                  {submitting ? 'Issuing...' : 'Issue Referral'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
