import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { urgencyColor, urgencyLabel, urgencyBg, urgencyText } from '../../utils/urgency';

const STATUS_MAP = {
  waiting:     { label: 'Waiting',     color: '#D97706', bg: '#FFFBEB' },
  in_progress: { label: 'In Progress', color: '#2563EB', bg: '#EFF6FF' },
  completed:   { label: 'Completed',   color: '#059669', bg: '#ECFDF5' },
  upcoming:    { label: 'Upcoming',    color: '#6366F1', bg: '#EEF2FF' },
};

export default function TodaysQueue() {
  const navigate = useNavigate();
  const { apiFetch, toast } = useApp();
  const [queue, setQueue] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  const load = useCallback(async () => {
    try {
      const data = await apiFetch('/queue');
      setQueue(data);
    } catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const filtered = queue.filter(q => {
    if (filter === 'all') return true;
    if (filter === 'crisis') return q.urgency >= 4;
    if (filter === 'urgent') return q.urgency === 3;
    if (filter === 'waiting') return q.status === 'waiting';
    if (filter === 'in_progress') return q.status === 'in_progress';
    return true;
  });

  const counts = {
    all: queue.length,
    crisis: queue.filter(q => q.urgency >= 4).length,
    urgent: queue.filter(q => q.urgency === 3).length,
    waiting: queue.filter(q => q.status === 'waiting').length,
    in_progress: queue.filter(q => q.status === 'in_progress').length,
  };

  const TABS = [
    { key: 'all',         label: 'All' },
    { key: 'crisis',      label: 'Crisis' },
    { key: 'urgent',      label: 'Urgent' },
    { key: 'waiting',     label: 'Waiting' },
    { key: 'in_progress', label: 'In Progress' },
  ];

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif', maxWidth: 1080 }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 22 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Today's Queue</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Live view of all active and pending student visits</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={load}
            style={{ padding: '8px 16px', background: '#F1F5F9', color: '#374151', border: '1px solid #E2E8F0', borderRadius: 8, fontWeight: 600, fontSize: 12.5, cursor: 'pointer' }}
          >
            Refresh
          </button>
          <button
            onClick={() => navigate('/walk-in')}
            style={{ padding: '8px 16px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 12.5, cursor: 'pointer' }}
          >
            + Walk-in
          </button>
        </div>
      </div>

      {/* Stats strip */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap' }}>
        {[
          { label: 'Total',       val: counts.all,         color: '#64748B', bg: '#F8FAFC' },
          { label: 'Crisis',      val: counts.crisis,      color: '#DC2626', bg: '#FEF2F2' },
          { label: 'Urgent',      val: counts.urgent,      color: '#D97706', bg: '#FFFBEB' },
          { label: 'Waiting',     val: counts.waiting,     color: '#2563EB', bg: '#EFF6FF' },
          { label: 'In Progress', val: counts.in_progress, color: '#059669', bg: '#ECFDF5' },
        ].map(s => (
          <div key={s.label} style={{ background: s.bg, border: '1px solid #E2E8F0', borderRadius: 9, padding: '10px 16px', minWidth: 90 }}>
            <div style={{ fontSize: 20, fontWeight: 900, color: s.color, letterSpacing: '-0.02em' }}>{s.val}</div>
            <div style={{ fontSize: 11.5, color: '#64748B', marginTop: 2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 18, background: '#F1F5F9', padding: '4px', borderRadius: 9, width: 'fit-content' }}>
        {TABS.map(t => (
          <button
            key={t.key} onClick={() => setFilter(t.key)}
            style={{ padding: '6px 14px', borderRadius: 7, border: 'none', cursor: 'pointer', fontWeight: 600, fontSize: 12.5, background: filter === t.key ? '#fff' : 'transparent', color: filter === t.key ? '#0F172A' : '#64748B', boxShadow: filter === t.key ? '0 1px 4px rgba(0,0,0,.09)' : 'none' }}
          >
            {t.label}
            <span style={{ marginLeft: 5, padding: '1px 6px', borderRadius: 10, fontSize: 11, background: filter === t.key ? '#EFF6FF' : '#E2E8F0', color: filter === t.key ? '#2563EB' : '#64748B', fontWeight: 700 }}>
              {counts[t.key]}
            </span>
          </button>
        ))}
      </div>

      {/* Queue list */}
      {loading ? (
        <div style={{ color: '#94A3B8', fontSize: 13, padding: '20px 0' }}>Loading queue...</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '48px', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, color: '#94A3B8' }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 4 }}>No queue items match your filters</div>
          <div style={{ fontSize: 12.5 }}>The queue is clear for this filter</div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {filtered.map(q => {
            const sm = STATUS_MAP[q.status] || STATUS_MAP.waiting;
            return (
              <div
                key={q.id}
                style={{
                  background: '#fff', border: '1px solid #E2E8F0',
                  borderLeft: `4px solid ${urgencyColor(q.urgency)}`,
                  borderRadius: 10, padding: '14px 20px',
                  display: 'grid', gridTemplateColumns: '90px 1fr 200px 120px 100px',
                  alignItems: 'center', gap: 16, cursor: 'pointer',
                  transition: 'box-shadow .15s',
                }}
                onClick={() => navigate(`/consultation/${q.id}`)}
                onMouseEnter={e => e.currentTarget.style.boxShadow = '0 4px 14px rgba(0,0,0,.06)'}
                onMouseLeave={e => e.currentTarget.style.boxShadow = 'none'}
              >
                {/* Priority */}
                <div style={{ textAlign: 'center' }}>
                  <span style={{ display: 'inline-block', padding: '3px 9px', borderRadius: 20, fontSize: 11, fontWeight: 700, background: urgencyBg(q.urgency), color: urgencyText(q.urgency) }}>
                    {urgencyLabel(q.urgency)}
                  </span>
                  {q.wait_min > 0 && (
                    <div style={{ fontSize: 11, color: '#94A3B8', marginTop: 4 }}>{q.wait_min}m wait</div>
                  )}
                </div>

                {/* Student */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#EFF6FF', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 13, color: '#2563EB', flexShrink: 0 }}>
                    {(q.student_name || 'S').charAt(0)}
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 13.5, color: '#0F172A' }}>{q.student_name}</div>
                    <div style={{ fontSize: 12, color: '#64748B' }}>{q.student_id}</div>
                    {q.complaint && <div style={{ fontSize: 12, color: '#374151', marginTop: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{q.complaint}</div>}
                  </div>
                </div>

                {/* Service */}
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13, color: '#0F172A' }}>{q.service}</div>
                  {q.health_centre && <div style={{ fontSize: 12, color: '#64748B', marginTop: 2 }}>{q.health_centre}</div>}
                </div>

                {/* Status */}
                <div>
                  <span style={{ padding: '3px 10px', borderRadius: 20, fontSize: 11.5, fontWeight: 700, background: sm.bg, color: sm.color }}>
                    {sm.label}
                  </span>
                  {q.time && <div style={{ fontSize: 11.5, color: '#94A3B8', marginTop: 4 }}>{q.time}</div>}
                </div>

                {/* Action */}
                <div onClick={e => e.stopPropagation()}>
                  <button
                    onClick={() => navigate(`/consultation/${q.id}`)}
                    style={{ padding: '6px 14px', background: '#EFF6FF', color: '#2563EB', border: '1px solid #BFDBFE', borderRadius: 7, fontSize: 12, fontWeight: 700, cursor: 'pointer' }}
                  >
                    {q.status === 'completed' ? 'View' : 'Start'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
