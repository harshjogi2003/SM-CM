import { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';
import { urgencyColor, urgencyLabel, urgencyBg, urgencyText } from '../../utils/urgency';

const STATUS_STYLE = {
  waiting:     { bg: '#EFF6FF', color: '#2563EB', label: 'Waiting' },
  in_progress: { bg: '#FFFBEB', color: '#D97706', label: 'In Progress' },
  done:        { bg: '#ECFDF5', color: '#059669', label: 'Done' },
};

const inputStyle = {
  width: '100%', padding: '9px 13px', borderRadius: 8,
  border: '1.5px solid #E2E8F0', fontSize: 13, boxSizing: 'border-box',
  background: '#fff', color: '#0F172A', outline: 'none',
};
const labelStyle = {
  display: 'block', fontSize: 12, fontWeight: 700, color: '#64748B',
  textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 5,
};

export default function WalkIn() {
  const { apiFetch, toast } = useApp();
  const [students, setStudents] = useState([]);
  const [services, setServices] = useState([]);
  const [walkins, setWalkins] = useState([]);
  const [loadingWalkins, setLoadingWalkins] = useState(true);
  const [form, setForm] = useState({ student_id: '', service_id: '', reason: '', urgency: 1 });
  const [studentSearch, setStudentSearch] = useState('');
  const [showStudentList, setShowStudentList] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [successToken, setSuccessToken] = useState(null);

  const loadData = useCallback(async () => {
    try {
      const st = await apiFetch('/students');
      const sv = await apiFetch('/masters/services');
      const wk = await apiFetch('/walk-in');
      setStudents(st);
      setServices(sv.filter(s => s.active !== 0));
      setWalkins(wk);
    } catch (e) { toast(e.message, 'error'); }
    finally { setLoadingWalkins(false); }
  }, [apiFetch, toast]);

  useEffect(() => { loadData(); }, [loadData]);

  const filteredStudents = students.filter(s =>
    studentSearch && (
      s.name.toLowerCase().includes(studentSearch.toLowerCase()) ||
      (s.student_id || '').toLowerCase().includes(studentSearch.toLowerCase())
    )
  ).slice(0, 6);

  const selectStudent = (student) => {
    setForm(f => ({ ...f, student_id: student.id }));
    setStudentSearch(`${student.name} (${student.student_id})`);
    setShowStudentList(false);
  };

  const submit = async (e) => {
    e.preventDefault();
    if (!form.student_id) { toast('Please select a student', 'error'); return; }
    setSubmitting(true);
    try {
      const result = await apiFetch('/walk-in', {
        method: 'POST',
        body: JSON.stringify({
          student_id: form.student_id,
          service_id: form.service_id ? parseInt(form.service_id) : null,
          service: services.find(s => s.id === parseInt(form.service_id))?.name || 'General Consultation',
          reason: form.reason,
          urgency: parseInt(form.urgency),
        }),
      });
      setSuccessToken(result);
      setForm({ student_id: '', service_id: '', reason: '', urgency: 1 });
      setStudentSearch('');
      loadData();
    } catch (e) { toast(e.message, 'error'); }
    finally { setSubmitting(false); }
  };

  const updateStatus = async (id, status) => {
    try {
      await apiFetch(`/walk-in/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) });
      loadData();
    } catch (e) { toast(e.message, 'error'); }
  };

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif', maxWidth: 940 }}>
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Walk-in Registration</h1>
        <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Register walk-in patients and manage today's queue</div>
      </div>

      {/* Success banner */}
      {successToken && (
        <div style={{ background: '#ECFDF5', border: '1px solid #A7F3D0', borderRadius: 10, padding: '14px 20px', marginBottom: 20, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontWeight: 700, color: '#059669', fontSize: 14 }}>Walk-in registered!</div>
            <div style={{ fontSize: 13, color: '#374151', marginTop: 2 }}>
              Token <strong>#{successToken.token_number}</strong> · {successToken.service} · Patient directed to waiting area
            </div>
          </div>
          <button onClick={() => setSuccessToken(null)} style={{ background: 'none', border: 'none', fontSize: 20, cursor: 'pointer', color: '#94A3B8', lineHeight: 1 }}>×</button>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '400px 1fr', gap: 24 }}>
        {/* Registration form */}
        <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, padding: '22px' }}>
          <div style={{ fontWeight: 800, fontSize: 14, color: '#0F172A', marginBottom: 18 }}>Register New Walk-in</div>
          <form onSubmit={submit}>
            {/* Student search */}
            <div style={{ position: 'relative', marginBottom: 14 }}>
              <label style={labelStyle}>Student *</label>
              <input
                value={studentSearch}
                onChange={e => { setStudentSearch(e.target.value); setShowStudentList(true); setForm(f => ({ ...f, student_id: '' })); }}
                onFocus={() => setShowStudentList(true)}
                placeholder="Search by name or ID..."
                style={inputStyle}
              />
              {showStudentList && filteredStudents.length > 0 && (
                <div style={{ position: 'absolute', top: '100%', left: 0, right: 0, background: '#fff', border: '1px solid #E2E8F0', borderRadius: 8, boxShadow: '0 8px 24px rgba(0,0,0,.1)', zIndex: 100, maxHeight: 200, overflowY: 'auto', marginTop: 2 }}>
                  {filteredStudents.map(s => (
                    <button
                      key={s.id} type="button" onClick={() => selectStudent(s)}
                      style={{ width: '100%', padding: '9px 14px', border: 'none', background: 'none', textAlign: 'left', cursor: 'pointer', fontSize: 13, borderBottom: '1px solid #F1F5F9', transition: 'background .1s' }}
                      onMouseEnter={e => e.currentTarget.style.background = '#F8FAFC'}
                      onMouseLeave={e => e.currentTarget.style.background = 'none'}
                    >
                      <span style={{ fontWeight: 700 }}>{s.name}</span>
                      <span style={{ color: '#64748B', marginLeft: 8, fontSize: 12 }}>{s.student_id} · {s.program}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Service */}
            <div style={{ marginBottom: 14 }}>
              <label style={labelStyle}>Service</label>
              <select value={form.service_id} onChange={e => setForm(f => ({ ...f, service_id: e.target.value }))} style={inputStyle}>
                <option value="">General Consultation (default)</option>
                {services.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>

            {/* Urgency */}
            <div style={{ marginBottom: 14 }}>
              <label style={labelStyle}>Urgency Level</label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 6 }}>
                {[
                  { val: 1, label: 'Routine', color: '#059669' },
                  { val: 2, label: 'Today',   color: '#D97706' },
                  { val: 3, label: 'Urgent',  color: '#EA580C' },
                  { val: 4, label: 'Crisis',  color: '#DC2626' },
                ].map(u => (
                  <button
                    key={u.val} type="button"
                    onClick={() => setForm(f => ({ ...f, urgency: u.val }))}
                    style={{
                      padding: '7px 4px', borderRadius: 7, border: `1.5px solid ${parseInt(form.urgency) === u.val ? u.color : '#E2E8F0'}`,
                      background: parseInt(form.urgency) === u.val ? u.color + '18' : '#fff',
                      color: parseInt(form.urgency) === u.val ? u.color : '#94A3B8',
                      fontSize: 11.5, fontWeight: 700, cursor: 'pointer', textAlign: 'center',
                    }}
                  >
                    {u.val}<br /><span style={{ fontWeight: 500 }}>{u.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Reason */}
            <div style={{ marginBottom: 18 }}>
              <label style={labelStyle}>Complaint / Reason</label>
              <input
                value={form.reason} onChange={e => setForm(f => ({ ...f, reason: e.target.value }))}
                placeholder="Brief description..."
                style={inputStyle}
              />
            </div>

            <button
              type="submit" disabled={submitting}
              style={{ width: '100%', padding: '11px', background: submitting ? '#93C5FD' : '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13.5, cursor: submitting ? 'not-allowed' : 'pointer' }}
            >
              {submitting ? 'Registering...' : 'Register Walk-in'}
            </button>
          </form>
        </div>

        {/* Today's queue */}
        <div>
          <div style={{ fontWeight: 800, fontSize: 14, color: '#0F172A', marginBottom: 14 }}>
            Today's Walk-ins ({walkins.length})
          </div>

          {loadingWalkins ? (
            <div style={{ color: '#94A3B8', fontSize: 13 }}>Loading...</div>
          ) : walkins.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '50px 0', color: '#94A3B8', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10 }}>
              <div style={{ fontSize: 28, marginBottom: 10 }}>—</div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>No walk-ins today</div>
              <div style={{ fontSize: 12.5, marginTop: 4 }}>Register a patient using the form</div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {walkins.map(w => {
                const ss = STATUS_STYLE[w.status] || STATUS_STYLE.waiting;
                return (
                  <div key={w.id} style={{
                    background: '#fff', border: '1px solid #E2E8F0',
                    borderLeft: `4px solid ${urgencyColor(w.urgency)}`,
                    borderRadius: 10, padding: '14px 18px',
                    display: 'flex', alignItems: 'center', gap: 14,
                  }}>
                    {/* Token */}
                    <div style={{ width: 38, height: 38, borderRadius: '50%', background: '#FFFBEB', color: '#D97706', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 13, flexShrink: 0, border: '1.5px solid #FDE68A' }}>
                      #{w.token_number}
                    </div>

                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4, flexWrap: 'wrap' }}>
                        <span style={{ fontWeight: 700, fontSize: 13.5, color: '#0F172A' }}>{w.student_name || 'Student'}</span>
                        <span style={{ fontSize: 12, color: '#94A3B8' }}>{w.s_id}</span>
                        <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11.5, fontWeight: 600, background: ss.bg, color: ss.color }}>{ss.label}</span>
                        <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 700, background: urgencyBg(w.urgency), color: urgencyText(w.urgency) }}>
                          {urgencyLabel(w.urgency)}
                        </span>
                      </div>
                      <div style={{ fontSize: 12.5, color: '#374151' }}>{w.service}</div>
                      {w.reason && <div style={{ fontSize: 12, color: '#64748B', marginTop: 1 }}>{w.reason}</div>}
                      <div style={{ fontSize: 11.5, color: '#94A3B8', marginTop: 2 }}>
                        Arrived: {new Date(w.created_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>

                    <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                      {w.status === 'waiting' && (
                        <button onClick={() => updateStatus(w.id, 'in_progress')} style={{ padding: '6px 12px', background: '#FFFBEB', color: '#D97706', border: '1px solid #FDE68A', borderRadius: 7, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
                          Start
                        </button>
                      )}
                      {w.status === 'in_progress' && (
                        <button onClick={() => updateStatus(w.id, 'done')} style={{ padding: '6px 12px', background: '#ECFDF5', color: '#059669', border: '1px solid #A7F3D0', borderRadius: 7, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>
                          Done
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
