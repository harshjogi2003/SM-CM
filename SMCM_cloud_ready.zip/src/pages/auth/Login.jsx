import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const ROLES = [
  { id: 'admin',   label: 'Administrator', desc: 'Clinical staff & administrators' },
  { id: 'student', label: 'Student',        desc: 'Access your health portal' },
];

const DEMO = {
  admin:   { email: 'admin@sibm.edu',  password: 'admin123'   },
  student: { email: 'rahul@sibm.edu',  password: 'student123' },
};

const FEATURES = [
  { icon: '⚡', title: 'Smart Triage',             desc: 'AI-powered priority routing for every visit' },
  { icon: '🔒', title: 'Confidential Counselling', desc: 'End-to-end private case management' },
  { icon: '📋', title: 'Digital Certificates',     desc: 'Instant medical certificate generation' },
  { icon: '📊', title: 'Clinical Analytics',       desc: 'Population health dashboards & compliance' },
];

export default function Login() {
  const { login, toast } = useApp();
  const navigate = useNavigate();
  const [role, setRole] = useState('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPw, setShowPw] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('http://localhost:3000/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), password }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Invalid credentials'); setLoading(false); return; }
      if (data.user.role !== role) {
        setError(`This account is a ${data.user.role} account. Please select the correct role above.`);
        setLoading(false); return;
      }
      login(data.user);
      toast(`Welcome back, ${data.user.name.split(' ')[0]}!`);
      navigate(data.user.role === 'admin' ? '/dashboard' : '/student/dashboard');
    } catch {
      setError('Cannot connect to server. Please ensure the backend is running on port 3000.');
      setLoading(false);
    }
  };

  const fillDemo = () => {
    setEmail(DEMO[role].email);
    setPassword(DEMO[role].password);
    setError('');
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Left branding panel */}
      <div style={{
        width: 400, flexShrink: 0,
        background: 'linear-gradient(160deg, #0F172A 0%, #1E293B 55%, #0F172A 100%)',
        display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
        padding: '44px 36px', color: '#fff', position: 'relative', overflow: 'hidden',
      }}>
        {/* Background accent */}
        <div style={{ position: 'absolute', top: -60, right: -60, width: 220, height: 220, borderRadius: '50%', background: 'rgba(37,99,235,0.12)', pointerEvents: 'none' }} />
        <div style={{ position: 'absolute', bottom: 40, left: -40, width: 160, height: 160, borderRadius: '50%', background: 'rgba(37,99,235,0.08)', pointerEvents: 'none' }} />

        <div style={{ position: 'relative' }}>
          {/* Logo */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 52 }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: '#2563EB', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, flexShrink: 0 }}>
              +
            </div>
            <div>
              <div style={{ fontWeight: 800, fontSize: 18, letterSpacing: '-0.03em', color: '#F8FAFC' }}>SMCM</div>
              <div style={{ fontSize: 11, color: '#64748B', marginTop: 1 }}>Student Medical & Counselling Module</div>
            </div>
          </div>

          <div style={{ fontSize: 11, fontWeight: 700, color: '#2563EB', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 12 }}>SIBM Pune — SMCM v3.0</div>
          <h2 style={{ fontSize: 26, fontWeight: 800, lineHeight: 1.3, marginBottom: 10, color: '#F8FAFC', letterSpacing: '-0.02em' }}>
            Integrated Health &<br />Wellbeing Platform
          </h2>
          <p style={{ fontSize: 13.5, color: '#64748B', marginBottom: 44, lineHeight: 1.6 }}>
            Symbiosis International University's end-to-end student healthcare management system.
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            {FEATURES.map(f => (
              <div key={f.title} style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                <div style={{ width: 34, height: 34, borderRadius: 8, background: 'rgba(37,99,235,0.15)', border: '1px solid rgba(37,99,235,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>
                  {f.icon}
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 13, color: '#E2E8F0', marginBottom: 2 }}>{f.title}</div>
                  <div style={{ fontSize: 12, color: '#475569', lineHeight: 1.4 }}>{f.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ position: 'relative', fontSize: 11, color: '#334155' }}>
          © 2026 SIBM Pune · SMCM v3.0 · Secure Healthcare Portal
        </div>
      </div>

      {/* Right form panel */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#F8FAFC', padding: '40px 48px' }}>
        <div style={{ width: '100%', maxWidth: 400 }}>
          <div style={{ marginBottom: 36 }}>
            <h1 style={{ fontSize: 24, fontWeight: 800, color: '#0F172A', marginBottom: 6, letterSpacing: '-0.02em' }}>
              Sign in to your portal
            </h1>
            <p style={{ color: '#64748B', fontSize: 14 }}>Access your health and wellness resources</p>
          </div>

          {/* Role selector */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 28 }}>
            {ROLES.map(r => (
              <button
                key={r.id} type="button"
                onClick={() => { setRole(r.id); setError(''); setEmail(''); setPassword(''); }}
                style={{
                  padding: '14px 16px', borderRadius: 10, cursor: 'pointer', textAlign: 'left',
                  border: `1.5px solid ${role === r.id ? '#2563EB' : '#E2E8F0'}`,
                  background: role === r.id ? '#EFF6FF' : '#fff',
                  transition: 'all .15s',
                  outline: 'none',
                }}
              >
                <div style={{ fontWeight: 700, fontSize: 13, color: role === r.id ? '#1D4ED8' : '#0F172A', marginBottom: 3 }}>{r.label}</div>
                <div style={{ fontSize: 11.5, color: '#64748B', lineHeight: 1.4 }}>{r.desc}</div>
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit}>
            {/* Email */}
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 6 }}>
                Email Address
              </label>
              <input
                type="email" value={email} onChange={e => setEmail(e.target.value)} required
                placeholder={`e.g. ${DEMO[role].email}`}
                style={{
                  width: '100%', padding: '10px 14px', borderRadius: 8,
                  border: '1.5px solid #E2E8F0', fontSize: 14, boxSizing: 'border-box',
                  background: '#fff', color: '#0F172A', outline: 'none',
                  transition: 'border-color .15s',
                }}
              />
            </div>

            {/* Password */}
            <div style={{ marginBottom: 22 }}>
              <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 6 }}>
                Password
              </label>
              <div style={{ position: 'relative' }}>
                <input
                  type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} required
                  style={{
                    width: '100%', padding: '10px 42px 10px 14px', borderRadius: 8,
                    border: '1.5px solid #E2E8F0', fontSize: 14, boxSizing: 'border-box',
                    background: '#fff', color: '#0F172A', outline: 'none',
                  }}
                />
                <button
                  type="button" onClick={() => setShowPw(p => !p)}
                  style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#94A3B8', fontSize: 13, padding: 0 }}
                >
                  {showPw ? 'Hide' : 'Show'}
                </button>
              </div>
            </div>

            {error && (
              <div style={{ background: '#FEF2F2', border: '1px solid #FECACA', color: '#DC2626', padding: '10px 14px', borderRadius: 8, fontSize: 13, marginBottom: 16, lineHeight: 1.5 }}>
                {error}
              </div>
            )}

            <button
              type="submit" disabled={loading}
              style={{
                width: '100%', padding: '12px', background: loading ? '#93C5FD' : '#2563EB',
                color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 15,
                cursor: loading ? 'not-allowed' : 'pointer', transition: 'background .15s',
                letterSpacing: '-0.01em',
              }}
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          {/* Demo fill */}
          <button
            type="button" onClick={fillDemo}
            style={{
              width: '100%', marginTop: 12, padding: '10px 14px',
              background: '#fff', border: '1.5px dashed #CBD5E1', borderRadius: 8,
              cursor: 'pointer', fontSize: 12.5, color: '#64748B', textAlign: 'center',
              transition: 'all .15s',
            }}
          >
            Fill demo <strong style={{ color: '#2563EB' }}>{role}</strong> credentials
          </button>

          {/* Demo accounts info */}
          <div style={{ marginTop: 24, padding: '14px 16px', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#374151', marginBottom: 10 }}>Demo Accounts</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {[
                { role: 'Admin', email: 'admin@sibm.edu', pw: 'admin123' },
                { role: 'Front Desk', email: 'frontdesk@sibm.edu', pw: 'front123' },
                { role: 'Student', email: 'rahul@sibm.edu', pw: 'student123' },
              ].map(d => (
                <div key={d.email} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11.5, color: '#64748B' }}>
                  <span style={{ fontWeight: 600, color: '#475569', minWidth: 70 }}>{d.role}</span>
                  <span>{d.email}</span>
                  <span style={{ color: '#94A3B8' }}>{d.pw}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
