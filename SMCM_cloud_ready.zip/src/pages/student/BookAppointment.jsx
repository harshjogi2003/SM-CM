import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const TIMES = ['09:00','09:30','10:00','10:30','11:00','11:30','12:00','14:00','14:30','15:00','15:30','16:00','16:30'];

export default function BookAppointment() {
  const { user, apiFetch, toast } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const prefill = location.state || {};

  const [step, setStep] = useState(1);
  const [centres, setCentres] = useState([]);
  const [providers, setProviders] = useState([]);
  const [loadingCentres, setLoadingCentres] = useState(true);
  const [form, setForm] = useState({
    centre: null,
    service: '',
    doctor: '',
    provider_id: null,
    date: '',
    time: '',
    complaint: prefill.complaint || '',
    case_id: prefill.case_id || null,
  });
  const [submitting, setSubmitting] = useState(false);

  // Load centres from API
  useEffect(() => {
    apiFetch('/masters/centres').then(data => {
      setCentres(data.filter(c => c.active));
    }).catch(() => {}).finally(() => setLoadingCentres(false));
  }, [apiFetch]);

  // Load providers when centre changes
  useEffect(() => {
    if (!form.centre) { setProviders([]); return; }
    apiFetch('/masters/providers').then(data => {
      setProviders(data.filter(p => p.centre_id === form.centre && p.active));
    }).catch(() => {});
  }, [form.centre, apiFetch]);

  // Pre-select centre if service_id provided in state
  useEffect(() => {
    if (prefill.service_id && centres.length > 0) {
      const centre = centres.find(c => c.services_offered?.includes(prefill.service_id));
      if (centre) {
        setForm(f => ({ ...f, centre: centre.id }));
        setStep(2);
      }
    }
  }, [prefill.service_id, centres]);

  const selectedCentre = centres.find(c => c.id === form.centre);

  const getCentreServices = (centre) => {
    if (!centre) return [];
    // Map service IDs to names from providers or generic labels
    return centre.services_offered || [];
  };

  const submit = async () => {
    setSubmitting(true);
    try {
      await apiFetch('/appointments', {
        method: 'POST',
        body: JSON.stringify({
          student_id: user.id,
          service: form.service,
          health_centre: selectedCentre?.name,
          doctor: form.doctor,
          provider_id: form.provider_id,
          date: form.date,
          time: form.time,
          complaint: form.complaint,
          case_id: form.case_id,
        }),
      });
      toast('Appointment booked successfully!');
      navigate('/student/appointments');
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const tomorrow = new Date(); tomorrow.setDate(tomorrow.getDate() + 1);
  const minDate = tomorrow.toISOString().split('T')[0];

  return (
    <div style={{ padding: '24px 28px', maxWidth: 720 }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0 }}>Book an Appointment</h1>
        <div style={{ color: '#6B7280', fontSize: 12.5, marginTop: 4 }}>Schedule a visit at any health centre on campus</div>
      </div>

      {/* Pre-fill banner */}
      {prefill.case_id && (
        <div style={{ background: '#EFF6FF', border: '1px solid #BFDBFE', borderRadius: 8, padding: '10px 14px', marginBottom: 16, fontSize: 13, color: '#1D4ED8' }}>
          📂 Booking linked to your care case — information has been pre-filled
        </div>
      )}

      {/* Steps */}
      <div style={{ display: 'flex', gap: 0, marginBottom: 28 }}>
        {['Health Centre', 'Service & Doctor', 'Date & Time', 'Confirm'].map((s, i) => (
          <div key={s} style={{ display: 'flex', alignItems: 'center', flex: 1 }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1 }}>
              <div style={{ width: 30, height: 30, borderRadius: '50%', background: step > i + 1 ? '#059669' : step === i + 1 ? '#2563EB' : '#E5E7EB', color: step >= i + 1 ? '#fff' : '#9CA3AF', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13 }}>
                {step > i + 1 ? '✓' : i + 1}
              </div>
              <div style={{ fontSize: 11, color: step === i + 1 ? '#2563EB' : '#9CA3AF', marginTop: 4, fontWeight: step === i + 1 ? 600 : 400, textAlign: 'center' }}>{s}</div>
            </div>
            {i < 3 && <div style={{ height: 2, flex: 1, background: step > i + 1 ? '#059669' : '#E5E7EB', marginBottom: 18 }} />}
          </div>
        ))}
      </div>

      <div style={{ background: '#fff', border: '1px solid #E5E7EB', borderRadius: 12, padding: '24px' }}>
        {/* Step 1: Choose centre */}
        {step === 1 && (
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, color: '#0F172A', marginBottom: 16 }}>Choose a Health Centre</div>
            {loadingCentres ? (
              <div style={{ color: '#6B7280' }}>Loading health centres…</div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                {centres.map(c => (
                  <button key={c.id} onClick={() => { setForm(f => ({ ...f, centre: c.id, service: '', doctor: '', provider_id: null })); setStep(2); }}
                    style={{ padding: '18px 16px', borderRadius: 10, border: `2px solid ${form.centre === c.id ? '#2563EB' : '#E5E7EB'}`, background: form.centre === c.id ? '#EFF6FF' : '#F8FAFC', cursor: 'pointer', textAlign: 'left' }}>
                    <div style={{ fontSize: 26, marginBottom: 8 }}>🏥</div>
                    <div style={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>{c.name}</div>
                    <div style={{ fontSize: 12, color: '#6B7280', marginTop: 2 }}>{c.location}</div>
                    <div style={{ fontSize: 11.5, color: '#9CA3AF', marginTop: 2 }}>{c.contact_phone}</div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Step 2: Service & Doctor */}
        {step === 2 && selectedCentre && (
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, color: '#0F172A', marginBottom: 16 }}>Select Service & Doctor</div>
            <div style={{ marginBottom: 18 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 8 }}>Service</label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                {providers.length > 0
                  ? [...new Set(providers.flatMap(p => p.service_ids || []))].map(sid => {
                      const serviceName = `Service ${sid}`;
                      return (
                        <button key={sid} onClick={() => setForm(f => ({ ...f, service: serviceName }))}
                          style={{ padding: '10px 14px', borderRadius: 8, border: `2px solid ${form.service === serviceName ? '#2563EB' : '#E5E7EB'}`, background: form.service === serviceName ? '#EFF6FF' : '#fff', cursor: 'pointer', fontSize: 13, fontWeight: 500, color: '#0F172A', textAlign: 'left' }}>
                          {serviceName}
                        </button>
                      );
                    })
                  : ['General Consultation', 'Follow-up', 'Emergency Assessment', 'Screening'].map(s => (
                    <button key={s} onClick={() => setForm(f => ({ ...f, service: s }))}
                      style={{ padding: '10px 14px', borderRadius: 8, border: `2px solid ${form.service === s ? '#2563EB' : '#E5E7EB'}`, background: form.service === s ? '#EFF6FF' : '#fff', cursor: 'pointer', fontSize: 13, fontWeight: 500, color: '#0F172A', textAlign: 'left' }}>
                      {s}
                    </button>
                  ))
                }
              </div>
              {/* Allow free text if none match */}
              <input
                value={form.service}
                onChange={e => setForm(f => ({ ...f, service: e.target.value }))}
                placeholder="Or type a service name…"
                style={{ marginTop: 8, width: '100%', padding: '9px 12px', borderRadius: 8, border: '1.5px solid #D1D5DB', fontSize: 13, boxSizing: 'border-box' }}
              />
            </div>
            <div style={{ marginBottom: 18 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 8 }}>Doctor / Counsellor</label>
              <select value={form.provider_id || ''} onChange={e => {
                const pid = parseInt(e.target.value);
                const prov = providers.find(p => p.id === pid);
                setForm(f => ({ ...f, provider_id: pid || null, doctor: prov?.name || '' }));
              }}
                style={{ width: '100%', padding: '10px 14px', borderRadius: 8, border: '1.5px solid #D1D5DB', fontSize: 13 }}>
                <option value="">Select provider</option>
                {providers.map(p => <option key={p.id} value={p.id}>{p.name} ({p.specialty})</option>)}
              </select>
            </div>
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 8 }}>Brief Complaint / Reason <span style={{ color: '#9CA3AF', fontWeight: 400 }}>(optional)</span></label>
              <textarea value={form.complaint} onChange={e => setForm(f => ({ ...f, complaint: e.target.value }))} rows={3}
                placeholder="Describe your symptoms or reason for visit…"
                style={{ width: '100%', padding: '10px 14px', borderRadius: 8, border: '1.5px solid #D1D5DB', fontSize: 13, resize: 'vertical', boxSizing: 'border-box' }} />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setStep(1)} style={{ padding: '9px 20px', background: '#F3F4F6', color: '#374151', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600, fontSize: 13 }}>← Back</button>
              <button onClick={() => setStep(3)} disabled={!form.service}
                style={{ padding: '9px 20px', background: !form.service ? '#CBD5E1' : '#2563EB', color: '#fff', border: 'none', borderRadius: 8, cursor: !form.service ? 'not-allowed' : 'pointer', fontWeight: 600, fontSize: 13 }}>
                Next →
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Date & Time */}
        {step === 3 && (
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, color: '#0F172A', marginBottom: 16 }}>Choose Date & Time</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 18 }}>
              <div>
                <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 8 }}>Preferred Date</label>
                <input type="date" value={form.date} min={minDate} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                  style={{ width: '100%', padding: '10px 14px', borderRadius: 8, border: '1.5px solid #D1D5DB', fontSize: 13, boxSizing: 'border-box' }} />
              </div>
              <div>
                <label style={{ fontSize: 13, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 8 }}>Preferred Time</label>
                <select value={form.time} onChange={e => setForm(f => ({ ...f, time: e.target.value }))}
                  style={{ width: '100%', padding: '10px 14px', borderRadius: 8, border: '1.5px solid #D1D5DB', fontSize: 13 }}>
                  <option value="">Select time slot</option>
                  {TIMES.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setStep(2)} style={{ padding: '9px 20px', background: '#F3F4F6', color: '#374151', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600, fontSize: 13 }}>← Back</button>
              <button onClick={() => setStep(4)} disabled={!form.date || !form.time}
                style={{ padding: '9px 20px', background: !form.date || !form.time ? '#CBD5E1' : '#2563EB', color: '#fff', border: 'none', borderRadius: 8, cursor: !form.date || !form.time ? 'not-allowed' : 'pointer', fontWeight: 600, fontSize: 13 }}>
                Review →
              </button>
            </div>
          </div>
        )}

        {/* Step 4: Confirm */}
        {step === 4 && (
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, color: '#0F172A', marginBottom: 16 }}>Confirm Appointment</div>
            <div style={{ background: '#F8FAFC', borderRadius: 10, padding: '18px', marginBottom: 20 }}>
              {[
                ['Health Centre', selectedCentre?.name],
                ['Service', form.service],
                ['Doctor', form.doctor || 'To be assigned'],
                ['Date', form.date],
                ['Time', form.time],
                ['Complaint', form.complaint || 'Not specified'],
              ].map(([label, val]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #E5E7EB' }}>
                  <span style={{ fontSize: 13, color: '#6B7280', fontWeight: 500 }}>{label}</span>
                  <span style={{ fontSize: 13, color: '#0F172A', fontWeight: 600, maxWidth: '60%', textAlign: 'right' }}>{val}</span>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setStep(3)} style={{ padding: '9px 20px', background: '#F3F4F6', color: '#374151', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600, fontSize: 13 }}>← Back</button>
              <button onClick={submit} disabled={submitting}
                style={{ padding: '9px 24px', background: submitting ? '#9B1C1C' : '#059669', color: '#fff', border: 'none', borderRadius: 8, cursor: submitting ? 'not-allowed' : 'pointer', fontWeight: 700, fontSize: 13 }}>
                {submitting ? 'Booking…' : '✓ Confirm Booking'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
