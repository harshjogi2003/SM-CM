import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const RISK_STYLE = {
  low:      { bg: '#ECFDF5', color: '#059669', border: '#A7F3D0', label: 'Low Risk' },
  moderate: { bg: '#FFFBEB', color: '#D97706', border: '#FDE68A', label: 'Moderate Risk' },
  high:     { bg: '#FEF2F2', color: '#DC2626', border: '#FECACA', label: 'High Risk' },
  crisis:   { bg: '#7F1D1D', color: '#FEF2F2', border: '#991B1B', label: 'Crisis' },
};

const WELLNESS_RESOURCES = [
  { icon: '◎', title: 'Mindfulness & Meditation', desc: 'Daily guided sessions to reduce stress and improve focus', color: '#7C3AED', bg: '#F5F3FF' },
  { icon: '◷', title: 'Academic Pressure',        desc: 'Time management and study stress strategies',             color: '#2563EB', bg: '#EFF6FF' },
  { icon: '◌', title: 'Social Connections',        desc: 'Building healthy relationships on campus',                color: '#059669', bg: '#ECFDF5' },
  { icon: '~', title: 'Physical Wellbeing',         desc: 'How regular exercise improves mental health',            color: '#D97706', bg: '#FFFBEB' },
];

export default function CounsellingPortal() {
  const { user, apiFetch, toast } = useApp();
  const navigate = useNavigate();
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [concern, setConcern] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try { setCases(await apiFetch(`/counselling?student_id=${user.id}`)); }
    catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [user, apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await apiFetch('/counselling', {
        method: 'POST',
        body: JSON.stringify({ student_id: user.id, concern }),
      });
      toast('Counselling request submitted. You will be assigned a counsellor shortly.');
      setShowForm(false);
      setConcern('');
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setSubmitting(false); }
  };

  const activeCase = cases.find(c => c.status === 'active');

  return (
    <div style={{ padding: '28px 32px', maxWidth: 820, fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Counselling &amp; Wellbeing</h1>
        <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Confidential mental health support — all sessions are private</div>
      </div>

      {/* Privacy banner */}
      <div style={{ background: '#F5F3FF', border: '1px solid #DDD6FE', borderRadius: 9, padding: '12px 16px', fontSize: 12.5, color: '#5B21B6', marginBottom: 22, display: 'flex', gap: 10, alignItems: 'flex-start', lineHeight: 1.5 }}>
        <span style={{ fontWeight: 900, flexShrink: 0 }}>&#x1F512;</span>
        <span><strong>Strictly Confidential:</strong> Counselling sessions and case details are never shared with faculty, parents, or administration without your explicit consent.</span>
      </div>

      {/* Active case card */}
      {activeCase ? (
        <div style={{ background: '#fff', border: '2px solid #DDD6FE', borderRadius: 13, padding: '22px', marginBottom: 22, position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 4, background: 'linear-gradient(90deg, #7C3AED, #5B21B6)' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18, paddingTop: 4 }}>
            <div>
              <div style={{ fontWeight: 800, fontSize: 15, color: '#0F172A', letterSpacing: '-0.01em' }}>Active Counselling Case</div>
              {activeCase.counsellor && (
                <div style={{ fontSize: 12.5, color: '#64748B', marginTop: 3 }}>Assigned to {activeCase.counsellor}</div>
              )}
            </div>
            {activeCase.risk_level && (
              <span style={{ padding: '4px 12px', borderRadius: 20, fontSize: 12, fontWeight: 700, background: RISK_STYLE[activeCase.risk_level]?.bg, color: RISK_STYLE[activeCase.risk_level]?.color, border: `1px solid ${RISK_STYLE[activeCase.risk_level]?.border}` }}>
                {RISK_STYLE[activeCase.risk_level]?.label}
              </span>
            )}
          </div>

          {/* Stats grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 16 }}>
            {[
              { label: 'Sessions Completed', val: activeCase.sessions_completed ?? 0 },
              { label: 'Last Session',        val: activeCase.last_session || 'Not yet' },
              { label: 'Next Session',        val: activeCase.next_session || 'To be scheduled' },
            ].map(({ label, val }) => (
              <div key={label} style={{ background: '#F8FAFC', borderRadius: 9, padding: '12px 14px' }}>
                <div style={{ fontSize: 11, color: '#64748B', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 5 }}>{label}</div>
                <div style={{ fontSize: 14, fontWeight: 800, color: '#0F172A', letterSpacing: '-0.01em' }}>{val}</div>
              </div>
            ))}
          </div>

          {activeCase.concern && (
            <div style={{ background: '#F8FAFC', borderRadius: 9, padding: '12px 16px', marginBottom: 10 }}>
              <div style={{ fontSize: 11, color: '#64748B', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>My Concern</div>
              <div style={{ fontSize: 13, color: '#374151', lineHeight: 1.5 }}>{activeCase.concern}</div>
            </div>
          )}

          {activeCase.notes && (
            <div style={{ background: '#F0FDF4', border: '1px solid #A7F3D0', borderRadius: 9, padding: '11px 16px' }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#059669', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>Counsellor Notes</div>
              <div style={{ fontSize: 13, color: '#374151', lineHeight: 1.5 }}>{activeCase.notes}</div>
            </div>
          )}
        </div>
      ) : !showForm && !loading && (
        /* CTA for new intake */
        <div style={{ background: 'linear-gradient(135deg,#F5F3FF 0%,#EDE9FE 100%)', border: '1px solid #DDD6FE', borderRadius: 13, padding: '36px 32px', textAlign: 'center', marginBottom: 22 }}>
          <div style={{ width: 56, height: 56, borderRadius: 14, background: '#7C3AED', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, margin: '0 auto 16px', color: '#fff', fontWeight: 900 }}>◎</div>
          <div style={{ fontWeight: 800, fontSize: 17, color: '#0F172A', marginBottom: 8, letterSpacing: '-0.01em' }}>Start Your Counselling Journey</div>
          <div style={{ fontSize: 13.5, color: '#64748B', marginBottom: 24, maxWidth: 380, margin: '0 auto 24px', lineHeight: 1.6 }}>
            Talk to a professional counsellor about stress, anxiety, relationships, or anything that's on your mind. It's 100% confidential.
          </div>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap' }}>
            <button
              onClick={() => setShowForm(true)}
              style={{ padding: '11px 24px', background: '#7C3AED', color: '#fff', border: 'none', borderRadius: 9, fontWeight: 700, fontSize: 14, cursor: 'pointer' }}
            >
              Request Counselling
            </button>
            <button
              onClick={() => navigate('/student/crisis')}
              style={{ padding: '11px 24px', background: '#fff', color: '#DC2626', border: '1.5px solid #FECACA', borderRadius: 9, fontWeight: 700, fontSize: 14, cursor: 'pointer' }}
            >
              I Need Help Now
            </button>
          </div>
        </div>
      )}

      {/* Request form */}
      {showForm && (
        <div style={{ background: '#fff', border: '1.5px solid #DDD6FE', borderRadius: 13, padding: '24px', marginBottom: 22 }}>
          <div style={{ fontSize: 15, fontWeight: 800, color: '#0F172A', marginBottom: 4, letterSpacing: '-0.01em' }}>Request a Counselling Session</div>
          <div style={{ fontSize: 13, color: '#64748B', marginBottom: 20 }}>A counsellor will be assigned to you within 24 hours</div>

          <form onSubmit={submit}>
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 12.5, fontWeight: 700, color: '#374151', display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                What would you like to talk about? <span style={{ color: '#94A3B8', fontWeight: 400, textTransform: 'none' }}>(optional)</span>
              </label>
              <textarea
                value={concern}
                onChange={e => setConcern(e.target.value)}
                rows={4}
                placeholder="e.g. Exam stress, relationship issues, feeling low, anxiety..."
                style={{ width: '100%', padding: '10px 14px', borderRadius: 9, border: '1.5px solid #E2E8F0', fontSize: 13, resize: 'vertical', boxSizing: 'border-box', color: '#0F172A', outline: 'none', lineHeight: 1.5 }}
              />
            </div>

            {/* Crisis notice */}
            <div style={{ background: '#FFFBEB', border: '1px solid #FDE68A', borderRadius: 8, padding: '10px 14px', fontSize: 12.5, color: '#92400E', marginBottom: 18, lineHeight: 1.5 }}>
              If you are in immediate distress or having thoughts of self-harm, please call our 24/7 crisis line: <strong>+91-20-1234-5678</strong>
            </div>

            <div style={{ display: 'flex', gap: 10 }}>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                style={{ padding: '9px 20px', background: '#F1F5F9', color: '#374151', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer', fontSize: 13 }}
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                style={{ padding: '9px 24px', background: submitting ? '#A78BFA' : '#7C3AED', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, cursor: submitting ? 'not-allowed' : 'pointer', fontSize: 13 }}
              >
                {submitting ? 'Submitting...' : 'Request Session'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Wellness resources */}
      <div>
        <div style={{ fontSize: 12, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 14 }}>Wellness Resources</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {WELLNESS_RESOURCES.map(r => (
            <div
              key={r.title}
              style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, padding: '16px 18px', display: 'flex', gap: 14, alignItems: 'flex-start', cursor: 'pointer', transition: 'box-shadow .15s' }}
              onMouseEnter={e => { e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,.06)'; e.currentTarget.style.borderColor = r.color + '44'; }}
              onMouseLeave={e => { e.currentTarget.style.boxShadow = 'none'; e.currentTarget.style.borderColor = '#E2E8F0'; }}
            >
              <div style={{ width: 38, height: 38, borderRadius: 9, background: r.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, color: r.color, fontWeight: 900, flexShrink: 0 }}>
                {r.icon}
              </div>
              <div>
                <div style={{ fontWeight: 700, fontSize: 13, color: '#0F172A', marginBottom: 3 }}>{r.title}</div>
                <div style={{ fontSize: 12, color: '#64748B', lineHeight: 1.4 }}>{r.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
