import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

export default function CrisisScreen() {
  const { user, apiFetch } = useApp();
  const navigate = useNavigate();
  const [notified, setNotified] = useState(false);
  const [contacts, setContacts] = useState({});

  useEffect(() => {
    // Prevent back navigation
    window.history.pushState(null, '', window.location.href);
    window.onpopstate = () => window.history.pushState(null, '', window.location.href);

    // Notify backend and get emergency contacts
    if (user) {
      apiFetch('/crisis', { method: 'POST', body: JSON.stringify({ student_id: user.id }) })
        .then(data => { setNotified(true); setContacts(data.emergency_contacts || {}); })
        .catch(() => setNotified(true));
    } else {
      // Try to get settings for emergency contacts without auth
      fetch('http://localhost:3000/api/settings')
        .then(r => r.json())
        .then(s => { setContacts(s.emergency_contacts || {}); })
        .catch(() => {});
      setNotified(true);
    }

    return () => { window.onpopstate = null; };
  }, []);

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'linear-gradient(135deg, #7F1D1D 0%, #DC2626 100%)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', zIndex: 9999, padding: 24, color: '#fff' }}>
      <div style={{ fontSize: 64, marginBottom: 16 }}>🆘</div>
      <h1 style={{ fontSize: 28, fontWeight: 800, textAlign: 'center', marginBottom: 8 }}>You're not alone.</h1>
      <p style={{ fontSize: 16, opacity: .9, textAlign: 'center', maxWidth: 400, marginBottom: 8 }}>Help is on the way.</p>

      {notified ? (
        <div style={{ background: 'rgba(255,255,255,.15)', borderRadius: 8, padding: '8px 16px', marginBottom: 24, fontSize: 13, fontWeight: 600 }}>
          ✓ Support staff have been notified
        </div>
      ) : (
        <div style={{ marginBottom: 24, fontSize: 13 }}>Notifying support staff…</div>
      )}

      <p style={{ fontSize: 13, opacity: .8, textAlign: 'center', maxWidth: 380, marginBottom: 24 }}>
        Stay on this screen. A member of the health team will reach you shortly. You can also call:
      </p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, width: '100%', maxWidth: 360 }}>
        {contacts.counsellor_oncall && (
          <a href={`tel:${contacts.counsellor_oncall.replace(/\s/g, '')}`}
            style={{ background: 'rgba(255,255,255,.15)', border: '2px solid rgba(255,255,255,.3)', borderRadius: 12, padding: '14px 20px', color: '#fff', textDecoration: 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontWeight: 600 }}>
            <span>📞 Counsellor On-Call</span>
            <span style={{ fontSize: 13, opacity: .9 }}>{contacts.counsellor_oncall}</span>
          </a>
        )}
        {contacts.campus_security && (
          <a href={`tel:${contacts.campus_security.replace(/\s/g, '')}`}
            style={{ background: 'rgba(255,255,255,.15)', border: '2px solid rgba(255,255,255,.3)', borderRadius: 12, padding: '14px 20px', color: '#fff', textDecoration: 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontWeight: 600 }}>
            <span>🔒 Campus Security</span>
            <span style={{ fontSize: 13, opacity: .9 }}>{contacts.campus_security}</span>
          </a>
        )}
        {contacts.national_mental_health && (
          <div style={{ background: 'rgba(255,255,255,.1)', borderRadius: 12, padding: '14px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 600 }}>🫂 National Helpline</span>
            <span style={{ fontSize: 13, opacity: .9 }}>{contacts.national_mental_health}</span>
          </div>
        )}
        {/* Fallback contacts if API not loaded */}
        {!contacts.counsellor_oncall && !contacts.campus_security && (
          <>
            <a href="tel:+919876543210"
              style={{ background: 'rgba(255,255,255,.15)', border: '2px solid rgba(255,255,255,.3)', borderRadius: 12, padding: '14px 20px', color: '#fff', textDecoration: 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontWeight: 600 }}>
              <span>📞 Counsellor On-Call</span>
              <span style={{ fontSize: 13, opacity: .9 }}>+91 98765 43210</span>
            </a>
            <a href="tel:+919876543211"
              style={{ background: 'rgba(255,255,255,.15)', border: '2px solid rgba(255,255,255,.3)', borderRadius: 12, padding: '14px 20px', color: '#fff', textDecoration: 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontWeight: 600 }}>
              <span>🔒 Campus Security</span>
              <span style={{ fontSize: 13, opacity: .9 }}>+91 98765 43211</span>
            </a>
            <div style={{ background: 'rgba(255,255,255,.1)', borderRadius: 12, padding: '14px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontWeight: 600 }}>🫂 National Helpline</span>
              <span style={{ fontSize: 13, opacity: .9 }}>iCall: 9152987821</span>
            </div>
          </>
        )}
      </div>

      <button
        onClick={() => navigate('/student/dashboard')}
        style={{ marginTop: 32, background: 'transparent', border: '1px solid rgba(255,255,255,.4)', color: 'rgba(255,255,255,.7)', padding: '8px 20px', borderRadius: 8, cursor: 'pointer', fontSize: 12 }}
      >
        I'm safe — return to dashboard
      </button>
    </div>
  );
}
