import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { urgencyLabel, urgencyBg, urgencyText } from '../../utils/urgency';

const CATEGORIES = [
  { id: 'unwell',       label: "I'm feeling unwell",                desc: 'Fever, pain, injury, or other physical symptoms',      color: '#2563EB', bg: '#EFF6FF' },
  { id: 'mental_health',label: 'I want mental health support',      desc: 'Stress, anxiety, low mood, or emotional support',       color: '#7C3AED', bg: '#F5F3FF' },
  { id: 'certificate',  label: 'I need a certificate or document',  desc: 'Medical fitness, sick leave, or specialist letter',     color: '#059669', bg: '#ECFDF5' },
  { id: 'followup',     label: 'I have a follow-up or screening',   desc: 'Previous visit follow-up or scheduled screening',       color: '#D97706', bg: '#FFFBEB' },
];

const UNWELL_SYMPTOMS = ['Fever', 'Headache', 'Cold / Cough', 'Stomach issues', 'Eye / Ear problems', 'Dental pain', 'Skin issues', 'Injury', 'Other'];
const MH_SYMPTOMS = ['Feeling stressed', 'Feeling anxious', 'Feeling low / sad', 'Sleep problems', 'Relationship issues', 'Academic pressure', 'Other'];

export default function GetHelp() {
  const { user, apiFetch, toast } = useApp();
  const navigate = useNavigate();

  const [step, setStep] = useState(1);
  const [intakeCategory, setIntakeCategory] = useState(null);
  const [symptoms, setSymptoms] = useState([]);
  const [freeText, setFreeText] = useState('');
  const [urgencySelfMark, setUrgencySelfMark] = useState('routine');
  const [certType, setCertType] = useState('');
  const [certTypes, setCertTypes] = useState([]);
  const [routingResult, setRoutingResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [draftBanner, setDraftBanner] = useState(false);

  const DRAFT_KEY = `smcm_intake_${user?.id}`;

  useEffect(() => {
    try {
      const draft = JSON.parse(localStorage.getItem(DRAFT_KEY));
      if (draft && draft.step > 1) setDraftBanner(true);
    } catch { /* ignore */ }
  }, [DRAFT_KEY]);

  useEffect(() => {
    if (step > 1) {
      localStorage.setItem(DRAFT_KEY, JSON.stringify({ step, intakeCategory, symptoms, freeText, urgencySelfMark }));
    }
  }, [step, intakeCategory, symptoms, freeText, urgencySelfMark, DRAFT_KEY]);

  useEffect(() => {
    if (intakeCategory === 'certificate') {
      apiFetch('/masters/certificate-types').then(setCertTypes).catch(() => {});
    }
  }, [intakeCategory, apiFetch]);

  const resumeDraft = () => {
    try {
      const draft = JSON.parse(localStorage.getItem(DRAFT_KEY));
      if (draft) { setStep(draft.step || 1); setIntakeCategory(draft.intakeCategory || null); setSymptoms(draft.symptoms || []); setFreeText(draft.freeText || ''); setUrgencySelfMark(draft.urgencySelfMark || 'routine'); }
    } catch { /* ignore */ }
    setDraftBanner(false);
  };

  const startFresh = () => { localStorage.removeItem(DRAFT_KEY); setDraftBanner(false); };

  const toggleSymptom = (s) => { setSymptoms(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]); };

  const submitIntake = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const result = await apiFetch('/intake', {
        method: 'POST',
        body: JSON.stringify({ student_id: user.id, intake_category: intakeCategory, symptoms, free_text: freeText, urgency_self_mark: urgencySelfMark }),
      });
      if (result.routing?.crisis) { localStorage.removeItem(DRAFT_KEY); navigate('/student/crisis'); return; }
      setRoutingResult(result);
      setStep(4);
      localStorage.removeItem(DRAFT_KEY);
    } catch (e) {
      setError(e.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [user, apiFetch, intakeCategory, symptoms, freeText, urgencySelfMark, DRAFT_KEY, navigate]);

  useEffect(() => {
    if (step === 4 && !routingResult && !loading) submitIntake();
  }, [step]);

  const progressPct = Math.round(((step - 1) / 3) * 100);

  const inputStyle = {
    width: '100%', padding: '9px 13px', borderRadius: 8,
    border: '1.5px solid #E2E8F0', fontSize: 13, boxSizing: 'border-box',
    background: '#fff', color: '#0F172A', outline: 'none', resize: 'vertical', lineHeight: 1.5,
  };

  return (
    <div style={{ padding: '28px 32px', maxWidth: 680, fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Draft banner */}
      {draftBanner && (
        <div style={{ background: '#FFFBEB', border: '1px solid #FDE68A', borderRadius: 10, padding: '12px 16px', marginBottom: 18, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: 13, color: '#92400E' }}>You have an unfinished intake from earlier. Resume?</span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={resumeDraft} style={{ padding: '5px 14px', background: '#D97706', color: '#fff', border: 'none', borderRadius: 6, fontWeight: 600, fontSize: 12, cursor: 'pointer' }}>Resume</button>
            <button onClick={startFresh} style={{ padding: '5px 14px', background: '#F1F5F9', color: '#374151', border: 'none', borderRadius: 6, fontWeight: 600, fontSize: 12, cursor: 'pointer' }}>Start Fresh</button>
          </div>
        </div>
      )}

      {/* Header */}
      <div style={{ marginBottom: 22 }}>
        <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>Get Help</h1>
        <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>We'll guide you to the right care in under 2 minutes</div>
      </div>

      {/* Progress bar */}
      {step < 4 && (
        <div style={{ background: '#E2E8F0', borderRadius: 8, height: 5, marginBottom: 22, overflow: 'hidden' }}>
          <div style={{ background: '#2563EB', height: '100%', width: `${progressPct}%`, borderRadius: 8, transition: 'width 0.3s' }} />
        </div>
      )}

      {/* Step container */}
      <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12, padding: '24px' }}>

        {/* STEP 1 — What do you need? */}
        {step === 1 && (
          <div>
            <div style={{ fontWeight: 800, fontSize: 16, color: '#0F172A', marginBottom: 5, letterSpacing: '-0.01em' }}>What do you need help with today?</div>
            <div style={{ fontSize: 13, color: '#64748B', marginBottom: 20 }}>Choose the option that best describes your situation</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
              {CATEGORIES.map(cat => (
                <button
                  key={cat.id} onClick={() => { setIntakeCategory(cat.id); setStep(2); }}
                  style={{
                    padding: '18px 16px', borderRadius: 10, border: '1.5px solid #E2E8F0',
                    background: '#F8FAFC', cursor: 'pointer', textAlign: 'left', transition: 'all .15s',
                  }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = cat.color; e.currentTarget.style.background = cat.bg; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = '#E2E8F0'; e.currentTarget.style.background = '#F8FAFC'; }}
                >
                  <div style={{ width: 32, height: 32, borderRadius: 8, background: cat.bg, border: `1px solid ${cat.color}33`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 17, marginBottom: 10 }}>
                    {cat.id === 'unwell' ? '~' : cat.id === 'mental_health' ? '◎' : cat.id === 'certificate' ? '◻' : '↺'}
                  </div>
                  <div style={{ fontWeight: 700, fontSize: 13, color: '#0F172A', marginBottom: 3, lineHeight: 1.3 }}>{cat.label}</div>
                  <div style={{ fontSize: 11.5, color: '#64748B', lineHeight: 1.4 }}>{cat.desc}</div>
                </button>
              ))}
            </div>
            {/* Crisis CTA */}
            <button
              onClick={() => navigate('/student/crisis')}
              style={{ width: '100%', padding: '16px 20px', borderRadius: 10, border: '1.5px solid #DC2626', background: '#FEF2F2', cursor: 'pointer', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 16 }}
            >
              <div style={{ width: 36, height: 36, borderRadius: 9, background: '#DC2626', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, color: '#fff', fontWeight: 900, flexShrink: 0 }}>!</div>
              <div>
                <div style={{ fontWeight: 800, fontSize: 14, color: '#DC2626', marginBottom: 2 }}>I need urgent help NOW</div>
                <div style={{ fontSize: 12, color: '#B91C1C' }}>Crisis support — clinical staff will be notified immediately</div>
              </div>
            </button>
          </div>
        )}

        {/* STEP 2 — Details */}
        {step === 2 && (
          <div>
            {intakeCategory === 'unwell' && (
              <>
                <div style={{ fontWeight: 800, fontSize: 15, color: '#0F172A', marginBottom: 5 }}>What symptoms are you experiencing?</div>
                <div style={{ fontSize: 13, color: '#64748B', marginBottom: 16 }}>Select all that apply</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 18 }}>
                  {UNWELL_SYMPTOMS.map(s => (
                    <button key={s} onClick={() => toggleSymptom(s.toLowerCase())}
                      style={{ padding: '6px 14px', borderRadius: 20, border: `1.5px solid ${symptoms.includes(s.toLowerCase()) ? '#2563EB' : '#E2E8F0'}`, background: symptoms.includes(s.toLowerCase()) ? '#EFF6FF' : '#fff', color: symptoms.includes(s.toLowerCase()) ? '#2563EB' : '#374151', fontWeight: 600, fontSize: 12.5, cursor: 'pointer' }}>
                      {s}
                    </button>
                  ))}
                </div>
                <label style={{ display: 'block', fontSize: 12.5, fontWeight: 600, color: '#374151', marginBottom: 6 }}>Tell us more <span style={{ fontWeight: 400, color: '#94A3B8' }}>(optional)</span></label>
                <textarea value={freeText} onChange={e => setFreeText(e.target.value)} rows={3} placeholder="Any other details..." style={inputStyle} />
              </>
            )}

            {intakeCategory === 'mental_health' && (
              <>
                <div style={{ fontWeight: 800, fontSize: 15, color: '#0F172A', marginBottom: 5 }}>What's been on your mind?</div>
                <div style={{ fontSize: 13, color: '#64748B', marginBottom: 16 }}>Select all that apply — this is private and confidential</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 18 }}>
                  {MH_SYMPTOMS.map(s => (
                    <button key={s} onClick={() => toggleSymptom(s.toLowerCase())}
                      style={{ padding: '6px 14px', borderRadius: 20, border: `1.5px solid ${symptoms.includes(s.toLowerCase()) ? '#7C3AED' : '#E2E8F0'}`, background: symptoms.includes(s.toLowerCase()) ? '#F5F3FF' : '#fff', color: symptoms.includes(s.toLowerCase()) ? '#7C3AED' : '#374151', fontWeight: 600, fontSize: 12.5, cursor: 'pointer' }}>
                      {s}
                    </button>
                  ))}
                </div>
                <div style={{ marginBottom: 18 }}>
                  <div style={{ fontSize: 12.5, fontWeight: 600, color: '#374151', marginBottom: 10 }}>How urgently do you need support?</div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {[
                      { val: 'routine', label: 'Can wait a few days', sub: 'Would like to talk soon', color: '#059669' },
                      { val: 'today',   label: 'Need help today',     sub: "I'm struggling and want to be seen today", color: '#D97706' },
                      { val: 'right_now', label: 'Need help RIGHT NOW', sub: 'I am in distress — immediate support', color: '#DC2626', crisis: true },
                    ].map(opt => (
                      <button key={opt.val} onClick={() => { if (opt.crisis) { navigate('/student/crisis'); return; } setUrgencySelfMark(opt.val); }}
                        style={{ padding: '12px 16px', borderRadius: 10, border: `1.5px solid ${urgencySelfMark === opt.val && !opt.crisis ? opt.color : opt.crisis ? '#DC2626' : '#E2E8F0'}`, background: opt.crisis ? '#FEF2F2' : urgencySelfMark === opt.val ? opt.color + '12' : '#fff', cursor: 'pointer', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 12 }}>
                        <div style={{ width: 10, height: 10, borderRadius: '50%', background: opt.color, flexShrink: 0 }} />
                        <div>
                          <div style={{ fontWeight: 700, fontSize: 13, color: opt.crisis ? '#DC2626' : '#0F172A' }}>{opt.label}</div>
                          <div style={{ fontSize: 11.5, color: '#64748B', marginTop: 1 }}>{opt.sub}</div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
                <textarea value={freeText} onChange={e => setFreeText(e.target.value)} rows={2} placeholder="Anything else? (optional)" style={inputStyle} />
              </>
            )}

            {intakeCategory === 'certificate' && (
              <>
                <div style={{ fontWeight: 800, fontSize: 15, color: '#0F172A', marginBottom: 16 }}>What type of document do you need?</div>
                <div style={{ marginBottom: 14 }}>
                  <label style={{ display: 'block', fontSize: 12.5, fontWeight: 600, color: '#374151', marginBottom: 6 }}>Certificate type *</label>
                  <select value={certType} onChange={e => setCertType(e.target.value)} style={{ ...inputStyle, resize: 'none' }}>
                    <option value="">Select type...</option>
                    {certTypes.map(ct => <option key={ct.id} value={ct.name}>{ct.name}</option>)}
                  </select>
                </div>
                <textarea value={freeText} onChange={e => setFreeText(e.target.value)} rows={3} placeholder="Why do you need this certificate?" style={inputStyle} />
              </>
            )}

            {intakeCategory === 'followup' && (
              <>
                <div style={{ fontWeight: 800, fontSize: 15, color: '#0F172A', marginBottom: 16 }}>Tell us about your follow-up</div>
                <textarea value={freeText} onChange={e => setFreeText(e.target.value)} rows={4}
                  placeholder="Describe what you're following up on — previous visit, pending test results, screening..." style={inputStyle} />
              </>
            )}

            <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
              <button onClick={() => setStep(1)} style={{ padding: '9px 20px', background: '#F1F5F9', color: '#374151', border: 'none', borderRadius: 8, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>Back</button>
              <button onClick={() => { if (intakeCategory === 'mental_health') setStep(4); else setStep(3); }}
                style={{ padding: '9px 20px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>
                Continue
              </button>
            </div>
          </div>
        )}

        {/* STEP 3 — Urgency */}
        {step === 3 && (
          <div>
            <div style={{ fontWeight: 800, fontSize: 15, color: '#0F172A', marginBottom: 5 }}>How urgently do you need care?</div>
            <div style={{ fontSize: 13, color: '#64748B', marginBottom: 20 }}>This helps us prioritise your care appropriately</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 20 }}>
              {[
                { val: 'routine',   label: 'Routine — can wait a few days',    sub: 'No immediate concern',                        color: '#059669', bg: '#ECFDF5' },
                { val: 'today',     label: 'Today — need to be seen today',    sub: "I'm unwell and want same-day care",           color: '#D97706', bg: '#FFFBEB' },
                { val: 'right_now', label: 'Right now — immediate help needed', sub: 'Emergency or acute condition',               color: '#DC2626', bg: '#FEF2F2', crisis: true },
              ].map(opt => (
                <button key={opt.val}
                  onClick={() => { if (opt.crisis) { navigate('/student/crisis'); return; } setUrgencySelfMark(opt.val); setStep(4); }}
                  style={{ padding: '14px 18px', borderRadius: 10, border: `1.5px solid ${opt.color}44`, background: opt.bg, cursor: 'pointer', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 14 }}>
                  <div style={{ width: 12, height: 12, borderRadius: '50%', background: opt.color, flexShrink: 0 }} />
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 13.5, color: opt.crisis ? '#DC2626' : '#0F172A' }}>{opt.label}</div>
                    <div style={{ fontSize: 12, color: '#64748B', marginTop: 2 }}>{opt.sub}</div>
                  </div>
                </button>
              ))}
            </div>
            <button onClick={() => setStep(2)} style={{ padding: '9px 20px', background: '#F1F5F9', color: '#374151', border: 'none', borderRadius: 8, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>Back</button>
          </div>
        )}

        {/* STEP 4 — Result */}
        {step === 4 && (
          <div>
            {loading && (
              <div style={{ textAlign: 'center', padding: '48px 0' }}>
                <div style={{ width: 36, height: 36, border: '3px solid #E2E8F0', borderTopColor: '#2563EB', borderRadius: '50%', margin: '0 auto 16px', animation: 'spin 0.8s linear infinite' }} />
                <div style={{ fontWeight: 700, color: '#374151', marginBottom: 4 }}>Reviewing your information...</div>
                <div style={{ fontSize: 13, color: '#64748B' }}>Finding the right care for you</div>
              </div>
            )}

            {error && !loading && (
              <div style={{ background: '#FEF2F2', border: '1px solid #FECACA', borderRadius: 8, padding: '12px 16px', color: '#991B1B', fontSize: 13, marginBottom: 16, lineHeight: 1.5 }}>
                {error}
                <button onClick={submitIntake} style={{ marginLeft: 10, background: 'none', border: 'none', color: '#991B1B', fontWeight: 600, cursor: 'pointer', textDecoration: 'underline', fontSize: 13 }}>Try again</button>
              </div>
            )}

            {routingResult && !loading && (
              <>
                <div style={{ textAlign: 'center', marginBottom: 22 }}>
                  <div style={{ width: 48, height: 48, borderRadius: '50%', background: '#ECFDF5', border: '2px solid #A7F3D0', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, margin: '0 auto 12px', color: '#059669', fontWeight: 900 }}>✓</div>
                  <div style={{ fontWeight: 800, fontSize: 16, color: '#0F172A', letterSpacing: '-0.01em' }}>Based on what you described:</div>
                </div>
                <div style={{ background: '#F0FDF4', border: '1.5px solid #A7F3D0', borderRadius: 12, padding: '20px', marginBottom: 18, textAlign: 'center' }}>
                  <div style={{ fontWeight: 800, fontSize: 16, color: '#0F172A', marginBottom: 5, letterSpacing: '-0.01em' }}>
                    {routingResult.service?.name || 'General Consultation'}
                  </div>
                  {routingResult.centre && (
                    <div style={{ fontSize: 13, color: '#64748B', marginBottom: 10 }}>{routingResult.centre.name} · {routingResult.centre.location}</div>
                  )}
                  <span style={{ display: 'inline-block', padding: '4px 14px', borderRadius: 20, background: urgencyBg(routingResult.routing?.urgency || 1), color: urgencyText(routingResult.routing?.urgency || 1), fontWeight: 700, fontSize: 12 }}>
                    {urgencyLabel(routingResult.routing?.urgency || 1)} Priority
                  </span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <button
                    onClick={() => navigate('/student/book', { state: { service_id: routingResult.routing?.route_to_service_id, complaint: freeText, case_id: routingResult.case?.id } })}
                    style={{ padding: '12px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13.5, cursor: 'pointer' }}
                  >
                    Book Appointment
                  </button>
                  <button onClick={() => navigate('/student/cases')}
                    style={{ padding: '11px', background: '#F8FAFC', color: '#374151', border: '1px solid #E2E8F0', borderRadius: 8, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>
                    View My Cases
                  </button>
                  <button onClick={() => navigate('/student/dashboard')}
                    style={{ padding: '8px', background: 'none', border: 'none', color: '#94A3B8', fontSize: 12.5, cursor: 'pointer', textDecoration: 'underline' }}>
                    Talk to front desk instead
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
