import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const STATUS_COLOR = { upcoming: '#2563EB', completed: '#059669', cancelled: '#6B7280', in_progress: '#D97706' };
const STATUS_BG    = { upcoming: '#EFF6FF', completed: '#ECFDF5', cancelled: '#F9FAFB', in_progress: '#FFFBEB' };
const STATUS_BORDER = { upcoming: '#2563EB', completed: '#059669', cancelled: '#CBD5E1', in_progress: '#D97706' };

export default function MyAppointments() {
  const { user, apiFetch, toast } = useApp();
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [cancelling, setCancelling] = useState(null);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const data = await apiFetch(`/appointments?student_id=${user.id}`);
      setAppointments(data);
    } catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [user, apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const cancel = async (id) => {
    if (!window.confirm('Cancel this appointment?')) return;
    setCancelling(id);
    try {
      await apiFetch(`/appointments/${id}`, { method: 'DELETE' });
      toast('Appointment cancelled');
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setCancelling(null); }
  };

  const filtered = filter === 'all' ? appointments : appointments.filter(a => a.status === filter);
  const counts = {
    all: appointments.length,
    upcoming: appointments.filter(a => a.status === 'upcoming').length,
    completed: appointments.filter(a => a.status === 'completed').length,
    cancelled: appointments.filter(a => a.status === 'cancelled').length,
  };

  const TABS = [
    { key: 'all',       label: 'All' },
    { key: 'upcoming',  label: 'Upcoming' },
    { key: 'completed', label: 'Completed' },
    { key: 'cancelled', label: 'Cancelled' },
  ];

  return (
    <div style={{ padding: '28px 32px', maxWidth: 860, fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 22 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>My Appointments</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>View and manage your scheduled visits</div>
        </div>
        <button
          onClick={() => navigate('/student/book')}
          style={{ padding: '9px 18px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}
        >
          + Book New
        </button>
      </div>

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, background: '#F1F5F9', padding: '4px', borderRadius: 9, width: 'fit-content' }}>
        {TABS.map(t => (
          <button
            key={t.key} onClick={() => setFilter(t.key)}
            style={{
              padding: '6px 14px', borderRadius: 7, border: 'none', cursor: 'pointer',
              fontWeight: 600, fontSize: 12.5,
              background: filter === t.key ? '#fff' : 'transparent',
              color: filter === t.key ? '#0F172A' : '#64748B',
              boxShadow: filter === t.key ? '0 1px 4px rgba(0,0,0,.09)' : 'none',
              transition: 'all .15s',
            }}
          >
            {t.label}
            <span style={{
              marginLeft: 6, padding: '1px 6px', borderRadius: 10, fontSize: 11,
              background: filter === t.key ? '#EFF6FF' : '#E2E8F0',
              color: filter === t.key ? '#2563EB' : '#64748B',
              fontWeight: 700,
            }}>
              {counts[t.key]}
            </span>
          </button>
        ))}
      </div>

      {/* Content */}
      {loading ? (
        <div style={{ color: '#94A3B8', fontSize: 13, padding: '20px 0' }}>Loading appointments...</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '52px 0', color: '#94A3B8', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12 }}>
          <div style={{ width: 52, height: 52, borderRadius: '50%', background: '#F1F5F9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, margin: '0 auto 14px', color: '#CBD5E1', fontWeight: 900 }}>◷</div>
          <div style={{ fontWeight: 700, fontSize: 14, color: '#374151', marginBottom: 6 }}>
            No {filter === 'all' ? '' : filter} appointments
          </div>
          <div style={{ fontSize: 12.5, marginBottom: 18 }}>
            {filter === 'cancelled' ? 'No cancelled appointments' : 'Schedule a visit with our health team'}
          </div>
          {filter !== 'cancelled' && (
            <button
              onClick={() => navigate('/student/book')}
              style={{ padding: '8px 20px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600, fontSize: 13 }}
            >
              Book Appointment
            </button>
          )}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {filtered.map(a => (
            <div
              key={a.id}
              style={{
                background: '#fff', border: '1px solid #E2E8F0',
                borderLeft: `4px solid ${STATUS_BORDER[a.status] || '#CBD5E1'}`,
                borderRadius: 10, padding: '16px 20px',
                display: 'flex', alignItems: 'center', gap: 16,
              }}
            >
              {/* Date block */}
              <div style={{
                width: 50, flexShrink: 0, textAlign: 'center',
                background: STATUS_BG[a.status] || '#F8FAFC', borderRadius: 10, padding: '8px 4px',
                border: `1px solid ${STATUS_BG[a.status] || '#E2E8F0'}`,
              }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: STATUS_COLOR[a.status] || '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  {a.date ? new Date(a.date).toLocaleString('en-IN', { month: 'short' }) : '—'}
                </div>
                <div style={{ fontSize: 20, fontWeight: 900, color: '#0F172A', lineHeight: 1.1 }}>
                  {a.date ? new Date(a.date).getDate() : '—'}
                </div>
              </div>

              {/* Main info */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4, flexWrap: 'wrap' }}>
                  <span style={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>{a.service}</span>
                  <span style={{
                    padding: '2px 9px', borderRadius: 20, fontSize: 11, fontWeight: 700,
                    background: STATUS_BG[a.status] || '#F1F5F9',
                    color: STATUS_COLOR[a.status] || '#64748B',
                  }}>
                    {a.status}
                  </span>
                </div>
                <div style={{ fontSize: 12.5, color: '#64748B', marginBottom: 2 }}>
                  {a.health_centre}{a.doctor ? ` · Dr. ${a.doctor}` : ''}
                </div>
                <div style={{ fontSize: 12, color: '#94A3B8' }}>
                  {a.date} at {a.time}
                </div>
                {a.complaint && (
                  <div style={{ fontSize: 12, color: '#374151', marginTop: 4, fontStyle: 'italic' }}>
                    "{a.complaint}"
                  </div>
                )}
              </div>

              {/* Actions */}
              <div style={{ flexShrink: 0 }}>
                {a.status === 'upcoming' && (
                  <button
                    onClick={() => cancel(a.id)}
                    disabled={cancelling === a.id}
                    style={{
                      padding: '6px 14px', background: cancelling === a.id ? '#F1F5F9' : '#FEF2F2',
                      color: '#DC2626', border: '1px solid #FECACA', borderRadius: 7,
                      fontSize: 12.5, fontWeight: 600, cursor: cancelling === a.id ? 'not-allowed' : 'pointer',
                    }}
                  >
                    {cancelling === a.id ? '...' : 'Cancel'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
