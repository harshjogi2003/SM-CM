import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import StatusPill from '../../components/common/StatusPill';
import { urgencyColor, urgencyLabel } from '../../utils/urgency';

const CATEGORY_LABELS = {
  unwell: 'Physical Health',
  mental_health: 'Mental Health',
  certificate: 'Certificate Request',
  followup: 'Follow-up',
  crisis: 'Crisis',
  general: 'General',
};

const TIMELINE_ICONS = {
  intake_submitted: '📝',
  triaged: '🎯',
  appointment_booked: '📅',
  appointment_completed: '✅',
  certificate_issued: '📋',
  crisis_triggered: '🆘',
  crisis_resolved: '✅',
  admin_note: '💬',
  default: '🔹',
};

function formatDate(ts) {
  if (!ts) return '';
  return new Date(ts).toLocaleString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export default function MyCases() {
  const { user, apiFetch, toast } = useApp();
  const navigate = useNavigate();
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState({});

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const data = await apiFetch(`/cases/student/${user.id}`);
      setCases(data);
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setLoading(false);
    }
  }, [user, apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const toggleExpand = (id) => setExpanded(prev => ({ ...prev, [id]: !prev[id] }));

  return (
    <div style={{ padding: '24px 28px', maxWidth: 800 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0 }}>My Care Requests</h1>
          <div style={{ color: '#6B7280', fontSize: 12.5, marginTop: 4 }}>Track your care journey from intake to resolution</div>
        </div>
        <button onClick={() => navigate('/student/get-help')} style={{ padding: '9px 18px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>+ Get Help</button>
      </div>

      {loading ? (
        <div style={{ color: '#6B7280', padding: '32px 0' }}>Loading your cases…</div>
      ) : cases.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '64px 0', color: '#9CA3AF' }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>📂</div>
          <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 8 }}>No care requests yet</div>
          <div style={{ fontSize: 13, marginBottom: 20 }}>Tap "Get Help" to start and we'll guide you to the right care.</div>
          <button onClick={() => navigate('/student/get-help')} style={{ padding: '9px 20px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 600, fontSize: 13, cursor: 'pointer' }}>Get Help Now</button>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {cases.map(c => {
            const uColor = urgencyColor(c.urgency);
            const catLabel = CATEGORY_LABELS[c.intake_summary?.intake_category] || 'General';
            const isOpen = expanded[c.id];
            return (
              <div key={c.id} style={{ background: '#fff', border: '1px solid #E5E7EB', borderLeft: `4px solid ${uColor}`, borderRadius: 10, overflow: 'hidden' }}>
                <div style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 14 }}>
                  {/* Urgency dot */}
                  <div style={{ width: 10, height: 10, borderRadius: '50%', background: uColor, flexShrink: 0 }} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', marginBottom: 4 }}>
                      <span style={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>{catLabel}</span>
                      <StatusPill status={c.current_status} />
                      <span style={{ fontSize: 11, color: '#9CA3AF' }}>Case #{c.id}</span>
                    </div>
                    <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
                      <span style={{ fontSize: 12, color: '#6B7280' }}>Created: {new Date(c.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                      {c.next_action?.label && (
                        <span style={{ fontSize: 12, color: '#374151', fontWeight: 500 }}>Next: {c.next_action.label}</span>
                      )}
                      <span style={{ fontSize: 12, color: uColor, fontWeight: 600 }}>{urgencyLabel(c.urgency)} priority</span>
                    </div>
                  </div>
                  <button onClick={() => toggleExpand(c.id)}
                    style={{ padding: '5px 12px', background: '#F8FAFC', border: '1px solid #E5E7EB', borderRadius: 6, fontSize: 12, color: '#374151', cursor: 'pointer', fontWeight: 600, flexShrink: 0 }}>
                    {isOpen ? 'Hide' : 'View Timeline ▼'}
                  </button>
                </div>

                {isOpen && (
                  <div style={{ borderTop: '1px solid #F1F5F9', padding: '16px 20px' }}>
                    {c.timeline?.length > 0 ? (
                      <>
                        <div style={{ fontSize: 12, fontWeight: 700, color: '#374151', marginBottom: 12, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Timeline</div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                          {c.timeline.map((evt, i) => (
                            <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                              <div style={{ flexShrink: 0, width: 28, height: 28, borderRadius: '50%', background: '#F1F5F9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, marginTop: 2 }}>
                                {TIMELINE_ICONS[evt.type] || TIMELINE_ICONS.default}
                              </div>
                              <div>
                                <div style={{ fontSize: 13, fontWeight: 500, color: '#0F172A' }}>{evt.summary}</div>
                                <div style={{ fontSize: 11.5, color: '#9CA3AF', marginTop: 2 }}>{formatDate(evt.ts)}</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </>
                    ) : (
                      <div style={{ color: '#9CA3AF', fontSize: 13 }}>No timeline events yet.</div>
                    )}
                    <div style={{ marginTop: 16, padding: '10px 14px', background: '#F8FAFC', border: '1px solid #E5E7EB', borderRadius: 8, fontSize: 12, color: '#6B7280', display: 'flex', alignItems: 'center', gap: 6 }}>
                      🔒 Clinical notes and session details are private and not shown here.
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
