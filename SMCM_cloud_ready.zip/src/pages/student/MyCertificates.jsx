import { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';

const STATUS_STYLE = {
  active:   { bg: '#D1FAE5', color: '#059669', border: '#A7F3D0', label: 'Active' },
  pending:  { bg: '#FEF3C7', color: '#D97706', border: '#FDE68A', label: 'Pending' },
  expired:  { bg: '#F1F5F9', color: '#64748B', border: '#E2E8F0', label: 'Expired' },
  rejected: { bg: '#FEF2F2', color: '#DC2626', border: '#FECACA', label: 'Rejected' },
  approved: { bg: '#DBEAFE', color: '#2563EB', border: '#BFDBFE', label: 'Approved' },
};

export default function MyCertificates() {
  const { user, apiFetch, toast } = useApp();
  const [certs, setCerts] = useState([]);
  const [certTypes, setCertTypes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ type: '', cert_type_id: '', reason: '' });
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [certsData, types] = await Promise.all([
        apiFetch(`/certificates?student_id=${user.id}`),
        apiFetch('/masters/certificate-types'),
      ]);
      setCerts(certsData);
      setCertTypes(types.filter(t => t.active !== 0));
    } catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [user, apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await apiFetch('/certificates', {
        method: 'POST',
        body: JSON.stringify({
          student_id: user.id,
          type: form.type,
          cert_type_id: form.cert_type_id ? parseInt(form.cert_type_id) : null,
          reason: form.reason,
        }),
      });
      toast('Certificate request submitted. Admin will review shortly.');
      setShowModal(false);
      setForm({ type: '', cert_type_id: '', reason: '' });
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setSubmitting(false); }
  };

  const pending = certs.filter(c => c.status === 'pending').length;
  const active  = certs.filter(c => c.status === 'active').length;

  return (
    <div style={{ padding: '28px 32px', maxWidth: 820, fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 22 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>My Certificates</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Request and track your medical certificates and documents</div>
        </div>
        <button
          onClick={() => setShowModal(true)}
          style={{ padding: '9px 18px', background: '#059669', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}
        >
          + Request Certificate
        </button>
      </div>

      {/* Stats strip */}
      {certs.length > 0 && (
        <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
          {[
            { label: 'Total Requested', val: certs.length, color: '#64748B', bg: '#F8FAFC' },
            { label: 'Active',          val: active,        color: '#059669', bg: '#ECFDF5' },
            { label: 'Pending Review',  val: pending,       color: '#D97706', bg: '#FFFBEB' },
          ].map(s => (
            <div key={s.label} style={{ background: s.bg, border: '1px solid #E2E8F0', borderRadius: 10, padding: '12px 18px', minWidth: 120 }}>
              <div style={{ fontSize: 22, fontWeight: 900, color: s.color, letterSpacing: '-0.02em' }}>{s.val}</div>
              <div style={{ fontSize: 11.5, color: '#64748B', marginTop: 3 }}>{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Content */}
      {loading ? (
        <div style={{ color: '#94A3B8', fontSize: 13, padding: '20px 0' }}>Loading certificates...</div>
      ) : certs.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '52px 24px', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12 }}>
          <div style={{ width: 52, height: 52, borderRadius: 12, background: '#ECFDF5', border: '1px solid #A7F3D0', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, margin: '0 auto 14px', color: '#059669', fontWeight: 900 }}>◻</div>
          <div style={{ fontWeight: 700, fontSize: 14, color: '#374151', marginBottom: 6 }}>No certificates yet</div>
          <div style={{ fontSize: 12.5, color: '#94A3B8', marginBottom: 20 }}>Request a medical certificate from the health team</div>
          <button
            onClick={() => setShowModal(true)}
            style={{ padding: '9px 20px', background: '#059669', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 700, fontSize: 13 }}
          >
            Request Now
          </button>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          {certs.map(c => {
            const s = STATUS_STYLE[c.status] || STATUS_STYLE.pending;
            return (
              <div key={c.id} style={{ background: '#fff', border: `1.5px solid ${c.status === 'active' ? '#A7F3D0' : '#E2E8F0'}`, borderRadius: 12, padding: '20px', overflow: 'hidden', position: 'relative' }}>
                {/* Top accent */}
                <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 3, background: s.color }} />

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12, paddingTop: 4 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 9, background: s.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, color: s.color, fontWeight: 900 }}>◻</div>
                  <span style={{ padding: '3px 10px', borderRadius: 20, fontSize: 11.5, fontWeight: 700, background: s.bg, color: s.color, border: `1px solid ${s.border}` }}>
                    {s.label}
                  </span>
                </div>

                <div style={{ fontWeight: 800, fontSize: 14, color: '#0F172A', marginBottom: 4, letterSpacing: '-0.01em' }}>{c.type}</div>

                {c.reason && (
                  <div style={{ fontSize: 12.5, color: '#64748B', marginBottom: 8, lineHeight: 1.4 }}>{c.reason}</div>
                )}

                <div style={{ fontSize: 11.5, color: '#94A3B8', marginBottom: 6 }}>
                  Requested: {new Date(c.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                </div>

                {c.ref && (
                  <div style={{ fontSize: 11.5, color: '#64748B', marginBottom: 6 }}>
                    Ref: <strong style={{ color: '#0F172A', fontFamily: 'monospace' }}>{c.ref}</strong>
                  </div>
                )}

                {c.issued_on && (
                  <div style={{ fontSize: 11.5, color: '#059669', fontWeight: 600 }}>
                    Issued: {c.issued_on}{c.valid_until ? ` · Valid until: ${c.valid_until}` : ''}
                  </div>
                )}

                {c.status === 'pending' && (
                  <div style={{ marginTop: 10, fontSize: 12, color: '#D97706', background: '#FFFBEB', padding: '7px 11px', borderRadius: 7, border: '1px solid #FDE68A' }}>
                    Under review — admin will process shortly
                  </div>
                )}

                {c.admin_notes && (
                  <div style={{ marginTop: 8, fontSize: 12, color: '#374151', background: '#F8FAFC', padding: '7px 11px', borderRadius: 7, border: '1px solid #E2E8F0' }}>
                    <span style={{ fontWeight: 700, color: '#64748B', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Note: </span>{c.admin_notes}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Request Modal */}
      {showModal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(15,23,42,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: 20 }}>
          <div style={{ background: '#fff', borderRadius: 14, width: '100%', maxWidth: 460, padding: '28px', boxShadow: '0 20px 60px rgba(0,0,0,.2)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
              <div style={{ fontSize: 17, fontWeight: 800, color: '#0F172A', letterSpacing: '-0.01em' }}>Request a Certificate</div>
              <button onClick={() => setShowModal(false)} style={{ background: 'none', border: 'none', fontSize: 22, color: '#94A3B8', cursor: 'pointer', lineHeight: 1, padding: 0 }}>×</button>
            </div>
            <div style={{ fontSize: 13, color: '#64748B', marginBottom: 22 }}>Your request will be reviewed by the medical team within 24 hours</div>

            <form onSubmit={submit}>
              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 12.5, fontWeight: 700, color: '#374151', display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Certificate Type *</label>
                <select
                  required
                  value={form.cert_type_id}
                  onChange={e => {
                    const ct = certTypes.find(t => String(t.id) === e.target.value);
                    setForm(f => ({ ...f, cert_type_id: e.target.value, type: ct?.name || '' }));
                  }}
                  style={{ width: '100%', padding: '10px 14px', borderRadius: 8, border: '1.5px solid #E2E8F0', fontSize: 13, background: '#fff', color: '#0F172A', outline: 'none' }}
                >
                  <option value="">Select type...</option>
                  {certTypes.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>

              <div style={{ marginBottom: 22 }}>
                <label style={{ fontSize: 12.5, fontWeight: 700, color: '#374151', display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Reason / Purpose *</label>
                <textarea
                  required
                  value={form.reason}
                  onChange={e => setForm(f => ({ ...f, reason: e.target.value }))}
                  rows={3}
                  placeholder="Briefly describe why you need this certificate..."
                  style={{ width: '100%', padding: '10px 14px', borderRadius: 8, border: '1.5px solid #E2E8F0', fontSize: 13, resize: 'vertical', boxSizing: 'border-box', color: '#0F172A', outline: 'none', lineHeight: 1.5 }}
                />
              </div>

              <div style={{ display: 'flex', gap: 10 }}>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  style={{ flex: 1, padding: '11px', background: '#F1F5F9', color: '#374151', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer', fontSize: 13 }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  style={{ flex: 2, padding: '11px', background: submitting ? '#6EE7B7' : '#059669', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, cursor: submitting ? 'not-allowed' : 'pointer', fontSize: 13 }}
                >
                  {submitting ? 'Submitting...' : 'Submit Request'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
