import { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';

export default function MyRecords() {
  const { user, apiFetch, toast } = useApp();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    if (!user) return;
    apiFetch(`/records?student_id=${user.id}`)
      .then(setRecords)
      .catch(e => toast(e.message, 'error'))
      .finally(() => setLoading(false));
  }, [user, apiFetch, toast]);

  return (
    <div style={{ padding: '28px 32px', maxWidth: 800, fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>My Health Records</h1>
        <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Your complete medical history — confidential and secure</div>
      </div>

      {/* Confidentiality notice */}
      <div style={{ background: '#EFF6FF', border: '1px solid #BFDBFE', borderRadius: 9, padding: '10px 16px', fontSize: 12.5, color: '#1D4ED8', marginBottom: 20, display: 'flex', gap: 10, alignItems: 'center' }}>
        <span style={{ fontWeight: 900, fontSize: 14 }}>&#x1F512;</span>
        <span>All records are encrypted and confidential. Only authorised medical staff can access your records.</span>
      </div>

      {loading ? (
        <div style={{ color: '#94A3B8', fontSize: 13, padding: '20px 0' }}>Loading records...</div>
      ) : records.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '52px 24px', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12 }}>
          <div style={{ width: 52, height: 52, borderRadius: 12, background: '#F1F5F9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, margin: '0 auto 14px', color: '#CBD5E1', fontWeight: 900 }}>◻</div>
          <div style={{ fontWeight: 700, fontSize: 14, color: '#374151', marginBottom: 4 }}>No health records yet</div>
          <div style={{ fontSize: 12.5, color: '#94A3B8' }}>Your records will appear here after your first visit</div>
        </div>
      ) : (
        <>
          {/* Records count */}
          <div style={{ fontSize: 12, color: '#64748B', marginBottom: 14, fontWeight: 600 }}>
            {records.length} record{records.length !== 1 ? 's' : ''} found
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {records.map((r, idx) => (
              <div
                key={r.id}
                style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, overflow: 'hidden' }}
              >
                {/* Row header */}
                <div
                  style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer', userSelect: 'none' }}
                  onClick={() => setExpanded(expanded === r.id ? null : r.id)}
                >
                  {/* Timeline dot / index */}
                  <div style={{
                    width: 38, height: 38, borderRadius: '50%', flexShrink: 0,
                    background: '#EFF6FF', border: '1.5px solid #BFDBFE',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontWeight: 800, fontSize: 13, color: '#2563EB',
                  }}>
                    {records.length - idx}
                  </div>

                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3, flexWrap: 'wrap' }}>
                      <span style={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>{r.service}</span>
                      <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11.5, fontWeight: 600, background: '#ECFDF5', color: '#059669' }}>Completed</span>
                    </div>
                    <div style={{ fontSize: 12.5, color: '#64748B' }}>
                      {r.doctor ? `Dr. ${r.doctor}` : 'Health Centre'}
                      {r.date ? ` · ${r.date}` : ''}
                    </div>
                    {r.diagnosis && (
                      <div style={{ fontSize: 12, color: '#374151', marginTop: 3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {r.diagnosis}
                      </div>
                    )}
                  </div>

                  <span style={{ color: '#CBD5E1', fontSize: 14, flexShrink: 0, transition: 'transform .15s', transform: expanded === r.id ? 'rotate(180deg)' : 'rotate(0)' }}>
                    ▼
                  </span>
                </div>

                {/* Expanded detail */}
                {expanded === r.id && (
                  <div style={{ borderTop: '1px solid #F1F5F9', padding: '18px 20px', background: '#F8FAFC' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                      <div>
                        <div style={{ fontSize: 11, color: '#64748B', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 5 }}>Diagnosis</div>
                        <div style={{ fontSize: 13, color: '#0F172A', lineHeight: 1.5 }}>{r.diagnosis || '—'}</div>
                      </div>
                      <div>
                        <div style={{ fontSize: 11, color: '#64748B', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 5 }}>Prescription</div>
                        <div style={{ fontSize: 13, color: '#0F172A', lineHeight: 1.5, whiteSpace: 'pre-wrap' }}>{r.prescription || '—'}</div>
                      </div>
                      <div>
                        <div style={{ fontSize: 11, color: '#64748B', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 5 }}>Clinical Notes</div>
                        <div style={{ fontSize: 13, color: '#0F172A', lineHeight: 1.5 }}>{r.notes || '—'}</div>
                      </div>
                      {r.vitals && Object.keys(r.vitals).some(k => r.vitals[k]) && (
                        <div>
                          <div style={{ fontSize: 11, color: '#64748B', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 5 }}>Vitals</div>
                          <div style={{ display: 'flex', gap: 7, flexWrap: 'wrap' }}>
                            {Object.entries(r.vitals).filter(([, v]) => v).map(([k, v]) => (
                              <span
                                key={k}
                                style={{ padding: '3px 9px', background: '#DBEAFE', color: '#1E40AF', borderRadius: 7, fontSize: 12, fontWeight: 600 }}
                              >
                                {k.replace(/_/g, ' ').toUpperCase()}: {v}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
