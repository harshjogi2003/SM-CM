import { useState, useEffect, useCallback } from 'react';
import { useApp } from '../../context/AppContext';

const PRIORITY_STYLE = {
  low:      { bg: '#ECFDF5', color: '#059669', border: '#A7F3D0', label: 'Low' },
  moderate: { bg: '#FFFBEB', color: '#D97706', border: '#FDE68A', label: 'Moderate' },
  high:     { bg: '#FEF2F2', color: '#DC2626', border: '#FECACA', label: 'High' },
};
const STATUS_STYLE = {
  pending:  { bg: '#FEF3C7', color: '#D97706', label: 'Pending' },
  assigned: { bg: '#DBEAFE', color: '#2563EB', label: 'Assigned' },
  reviewed: { bg: '#D1FAE5', color: '#059669', label: 'Reviewed' },
  closed:   { bg: '#F1F5F9', color: '#64748B', label: 'Closed' },
};

export default function RaiseConcern() {
  const { user, apiFetch, toast } = useApp();
  const [concerns, setConcerns] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ type: '', description: '', priority: 'moderate' });
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [concernsData, cats] = await Promise.all([
        apiFetch(`/concerns?student_id=${user.id}`),
        apiFetch('/masters/concern-categories'),
      ]);
      setConcerns(concernsData);
      setCategories(cats.filter(c => c.active !== 0));
    } catch (e) { toast(e.message, 'error'); }
    finally { setLoading(false); }
  }, [user, apiFetch, toast]);

  useEffect(() => { load(); }, [load]);

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await apiFetch('/concerns', {
        method: 'POST',
        body: JSON.stringify({ student_id: user.id, ...form }),
      });
      toast('Concern submitted. We will respond within 24–48 hours.');
      setShowForm(false);
      setForm({ type: '', description: '', priority: 'moderate' });
      load();
    } catch (e) { toast(e.message, 'error'); }
    finally { setSubmitting(false); }
  };

  const open   = concerns.filter(c => !['closed'].includes(c.status)).length;
  const closed = concerns.filter(c => c.status === 'closed').length;

  return (
    <div style={{ padding: '28px 32px', maxWidth: 820, fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>My Concerns</h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>Raise an issue and track its resolution</div>
        </div>
        {!showForm && (
          <button
            onClick={() => setShowForm(true)}
            style={{ padding: '9px 18px', background: '#D97706', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}
          >
            + Raise Concern
          </button>
        )}
      </div>

      {/* Stats strip */}
      {concerns.length > 0 && (
        <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
          {[
            { label: 'Total', val: concerns.length, color: '#64748B', bg: '#F8FAFC' },
            { label: 'Open',  val: open,            color: '#D97706', bg: '#FFFBEB' },
            { label: 'Closed', val: closed,         color: '#059669', bg: '#ECFDF5' },
          ].map(s => (
            <div key={s.label} style={{ background: s.bg, border: '1px solid #E2E8F0', borderRadius: 10, padding: '11px 18px', minWidth: 100 }}>
              <div style={{ fontSize: 21, fontWeight: 900, color: s.color, letterSpacing: '-0.02em' }}>{s.val}</div>
              <div style={{ fontSize: 11.5, color: '#64748B', marginTop: 3 }}>{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Emergency notice */}
      <div style={{ background: '#FEF2F2', border: '1px solid #FECACA', borderRadius: 9, padding: '10px 16px', fontSize: 12.5, color: '#991B1B', marginBottom: 20, display: 'flex', gap: 10, alignItems: 'center' }}>
        <span style={{ fontWeight: 900 }}>!</span>
        <span>In case of emergency or crisis, call immediately: <strong>+91-20-1234-5678</strong></span>
      </div>

      {/* Submit form */}
      {showForm && (
        <div style={{ background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 13, padding: '24px', marginBottom: 22 }}>
          <div style={{ fontSize: 15, fontWeight: 800, color: '#0F172A', marginBottom: 18, letterSpacing: '-0.01em' }}>Report a Concern</div>
          <form onSubmit={submit}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
              {/* Category */}
              <div>
                <label style={{ fontSize: 12.5, fontWeight: 700, color: '#374151', display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Category *</label>
                <select
                  required
                  value={form.type}
                  onChange={e => setForm(f => ({ ...f, type: e.target.value }))}
                  style={{ width: '100%', padding: '10px 14px', borderRadius: 8, border: '1.5px solid #E2E8F0', fontSize: 13, background: '#fff', color: '#0F172A', outline: 'none' }}
                >
                  <option value="">Select category...</option>
                  {categories.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                </select>
              </div>

              {/* Priority */}
              <div>
                <label style={{ fontSize: 12.5, fontWeight: 700, color: '#374151', display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Priority</label>
                <div style={{ display: 'flex', gap: 7 }}>
                  {['low', 'moderate', 'high'].map(p => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setForm(f => ({ ...f, priority: p }))}
                      style={{
                        flex: 1, padding: '8px 6px', borderRadius: 8,
                        border: `1.5px solid ${form.priority === p ? PRIORITY_STYLE[p].color : '#E2E8F0'}`,
                        background: form.priority === p ? PRIORITY_STYLE[p].bg : '#fff',
                        color: form.priority === p ? PRIORITY_STYLE[p].color : '#64748B',
                        cursor: 'pointer', fontSize: 12.5, fontWeight: 700,
                      }}
                    >
                      {PRIORITY_STYLE[p].label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Description */}
            <div style={{ marginBottom: 18 }}>
              <label style={{ fontSize: 12.5, fontWeight: 700, color: '#374151', display: 'block', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Description *</label>
              <textarea
                required
                value={form.description}
                onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                rows={4}
                placeholder="Describe your concern in detail. The more specific you are, the faster we can help..."
                style={{ width: '100%', padding: '10px 14px', borderRadius: 8, border: '1.5px solid #E2E8F0', fontSize: 13, resize: 'vertical', boxSizing: 'border-box', color: '#0F172A', outline: 'none', lineHeight: 1.5 }}
              />
            </div>

            <div style={{ display: 'flex', gap: 10 }}>
              <button
                type="button"
                onClick={() => { setShowForm(false); setForm({ type: '', description: '', priority: 'moderate' }); }}
                style={{ padding: '9px 20px', background: '#F1F5F9', color: '#374151', border: 'none', borderRadius: 8, fontWeight: 600, cursor: 'pointer', fontSize: 13 }}
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                style={{ padding: '9px 24px', background: submitting ? '#FCD34D' : '#D97706', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, cursor: submitting ? 'not-allowed' : 'pointer', fontSize: 13 }}
              >
                {submitting ? 'Submitting...' : 'Submit Concern'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Concerns list */}
      {loading ? (
        <div style={{ color: '#94A3B8', fontSize: 13, padding: '20px 0' }}>Loading concerns...</div>
      ) : concerns.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '52px 24px', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 12 }}>
          <div style={{ width: 52, height: 52, borderRadius: 12, background: '#FFFBEB', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, margin: '0 auto 14px', color: '#D97706', fontWeight: 900 }}>!</div>
          <div style={{ fontWeight: 700, fontSize: 14, color: '#374151', marginBottom: 6 }}>No concerns raised yet</div>
          <div style={{ fontSize: 12.5, color: '#94A3B8' }}>Use the button above to report an issue</div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {concerns.map(c => {
            const ss = STATUS_STYLE[c.status] || STATUS_STYLE.pending;
            const ps = PRIORITY_STYLE[c.priority] || PRIORITY_STYLE.moderate;
            return (
              <div
                key={c.id}
                style={{ background: '#fff', border: '1px solid #E2E8F0', borderLeft: `4px solid ${ps.color}`, borderRadius: 10, padding: '16px 20px' }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                    <span style={{ fontWeight: 700, fontSize: 14, color: '#0F172A' }}>{c.type}</span>
                    <span style={{ padding: '2px 9px', borderRadius: 20, fontSize: 11.5, fontWeight: 700, background: ps.bg, color: ps.color, border: `1px solid ${ps.border}` }}>
                      {ps.label}
                    </span>
                  </div>
                  <span style={{ padding: '3px 10px', borderRadius: 20, fontSize: 11.5, fontWeight: 700, background: ss.bg, color: ss.color, flexShrink: 0 }}>
                    {ss.label}
                  </span>
                </div>

                <div style={{ fontSize: 13, color: '#374151', marginBottom: 6, lineHeight: 1.5 }}>{c.description}</div>

                <div style={{ fontSize: 11.5, color: '#94A3B8' }}>
                  Submitted: {new Date(c.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                </div>

                {c.response && (
                  <div style={{ marginTop: 10, padding: '10px 14px', background: '#F0FDF4', border: '1px solid #A7F3D0', borderRadius: 8 }}>
                    <div style={{ fontSize: 11.5, fontWeight: 700, color: '#059669', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 4 }}>Admin Response</div>
                    <div style={{ fontSize: 13, color: '#374151', lineHeight: 1.5 }}>{c.response}</div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
