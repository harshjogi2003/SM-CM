import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const QUICK = [
  { label: 'Book Appointment', icon: '◷', path: '/student/book', color: '#2563EB', bg: '#EFF6FF' },
  { label: 'Request Certificate', icon: '◻', path: '/student/certificates', color: '#059669', bg: '#ECFDF5' },
  { label: 'Counselling', icon: '◎', path: '/student/counselling', color: '#7C3AED', bg: '#F5F3FF' },
  { label: 'Raise Concern', icon: '!', path: '/student/raise-concern', color: '#D97706', bg: '#FFFBEB' },
];

function Card({ children, style }) {
  return <div style={{ background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, ...style }}>{children}</div>;
}

export default function StudentDashboard() {
  const { user, apiFetch } = useApp();
  const navigate = useNavigate();
  const [data, setData] = useState({ appointments: [], records: [], certificates: [], cases: [] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    (async () => {
      try {
        const appointments = await apiFetch(`/appointments?student_id=${user.id}`);
        const records      = await apiFetch(`/records?student_id=${user.id}`);
        const certificates = await apiFetch(`/certificates?student_id=${user.id}`);
        const cases        = await apiFetch(`/counselling?student_id=${user.id}`);
        setData({ appointments, records, certificates, cases });
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    })();
  }, [user, apiFetch]);

  const upcoming = data.appointments.filter(a => a.status === 'upcoming');
  const activeCerts = data.certificates.filter(c => c.status === 'active');
  const activeCase = data.cases.find(c => c.status === 'active');
  const lastRecord = data.records[0];

  if (loading) return <div style={{ padding: 40, color: '#94A3B8', fontSize: 13, fontFamily: 'system-ui,-apple-system,sans-serif' }}>Loading your health summary...</div>;

  return (
    <div style={{ padding: '28px 32px', fontFamily: 'system-ui,-apple-system,sans-serif', maxWidth: 1080 }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: '#0F172A', margin: 0, letterSpacing: '-0.02em' }}>
            My Health Summary
          </h1>
          <div style={{ color: '#94A3B8', fontSize: 12.5, marginTop: 4 }}>
            {user?.name} · {user?.student_id} · {user?.program}
          </div>
        </div>
        <button
          onClick={() => navigate('/student/get-help')}
          style={{ padding: '9px 18px', background: '#2563EB', color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: 'pointer' }}
        >
          Get Help Now
        </button>
      </div>

      {/* Get Help CTA banner */}
      <div
        onClick={() => navigate('/student/get-help')}
        style={{
          background: 'linear-gradient(135deg, #0F172A 0%, #1E3A5F 50%, #1D4ED8 100%)',
          borderRadius: 12, padding: '22px 28px', cursor: 'pointer', marginBottom: 22, color: '#fff',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          transition: 'opacity .15s',
        }}
        onMouseEnter={e => e.currentTarget.style.opacity = '0.93'}
        onMouseLeave={e => e.currentTarget.style.opacity = '1'}
      >
        <div>
          <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 4, letterSpacing: '-0.02em' }}>Need care or support?</div>
          <div style={{ opacity: 0.7, fontSize: 13, lineHeight: 1.5 }}>We'll guide you to the right help in under 2 minutes. Crisis support available 24/7.</div>
        </div>
        <div style={{ width: 44, height: 44, borderRadius: 10, background: 'rgba(255,255,255,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, flexShrink: 0 }}>
          →
        </div>
      </div>

      {/* Health card */}
      <Card style={{ padding: '16px 22px', marginBottom: 20, borderTop: '3px solid #2563EB' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 18 }}>
          <div>
            <div style={{ fontSize: 11, color: '#94A3B8', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Blood Group</div>
            <div style={{ fontSize: 22, fontWeight: 900, color: '#DC2626', letterSpacing: '-0.02em' }}>{user?.blood_group || '—'}</div>
          </div>
          <div>
            <div style={{ fontSize: 11, color: '#94A3B8', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Last Visit</div>
            {lastRecord ? (
              <>
                <div style={{ fontWeight: 700, fontSize: 13, color: '#0F172A' }}>{lastRecord.date}</div>
                <div style={{ fontSize: 11.5, color: '#64748B', marginTop: 2 }}>{lastRecord.service}</div>
              </>
            ) : <div style={{ fontSize: 13, color: '#94A3B8' }}>No visits yet</div>}
          </div>
          <div>
            <div style={{ fontSize: 11, color: '#94A3B8', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Next Appointment</div>
            {upcoming[0] ? (
              <>
                <div style={{ fontWeight: 700, fontSize: 13, color: '#0F172A' }}>{upcoming[0].date}</div>
                <div style={{ fontSize: 11.5, color: '#64748B', marginTop: 2 }}>{upcoming[0].time} · {upcoming[0].service}</div>
              </>
            ) : <div style={{ fontSize: 13, color: '#94A3B8' }}>None scheduled</div>}
          </div>
          <div>
            <div style={{ fontSize: 11, color: '#94A3B8', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Active Certificates</div>
            {activeCerts.length > 0
              ? activeCerts.slice(0, 2).map(c => <span key={c.id} style={{ display: 'inline-block', padding: '2px 9px', background: '#ECFDF5', color: '#059669', borderRadius: 20, fontSize: 11.5, fontWeight: 600, marginRight: 4, marginBottom: 3 }}>{c.type}</span>)
              : <div style={{ fontSize: 13, color: '#94A3B8' }}>None active</div>}
          </div>
        </div>
      </Card>

      {/* KPI row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 20 }}>
        {[
          { label: 'Total Appointments', val: data.appointments.length, sub: `${upcoming.length} upcoming`, color: '#2563EB', bg: '#EFF6FF' },
          { label: 'Certificates', val: data.certificates.length, sub: `${activeCerts.length} active`, color: '#059669', bg: '#ECFDF5' },
          { label: 'Counselling', val: activeCase ? 'Active' : 'None', sub: activeCase ? `${activeCase.sessions_completed} sessions` : 'No open case', color: '#7C3AED', bg: '#F5F3FF' },
          { label: 'Health Records', val: data.records.length, sub: 'Total visits recorded', color: '#D97706', bg: '#FFFBEB' },
        ].map(k => (
          <Card key={k.label} style={{ padding: '14px 16px' }}>
            <div style={{ fontSize: 11, color: '#94A3B8', fontWeight: 600, marginBottom: 8 }}>{k.label}</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: k.color, letterSpacing: '-0.02em', marginBottom: 2 }}>{k.val}</div>
            <div style={{ fontSize: 11.5, color: '#94A3B8' }}>{k.sub}</div>
          </Card>
        ))}
      </div>

      {/* Two-col grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
        {/* Upcoming appointments */}
        <Card>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid #F1F5F9', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 700, fontSize: 13, color: '#0F172A' }}>Upcoming Appointments</span>
            <button onClick={() => navigate('/student/book')} style={{ padding: '4px 10px', background: '#EFF6FF', color: '#2563EB', border: '1px solid #BFDBFE', borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>+ Book</button>
          </div>
          <div style={{ padding: '10px 18px' }}>
            {upcoming.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '18px 0', color: '#94A3B8', fontSize: 12.5 }}>No upcoming appointments</div>
            ) : upcoming.slice(0, 3).map((a, i) => (
              <div key={a.id} style={{ padding: '10px 12px', borderRadius: 8, border: '1px solid #E2E8F0', borderLeft: '3px solid #2563EB', background: '#F8FAFC', marginBottom: i < 2 ? 8 : 0 }}>
                <div style={{ fontWeight: 700, fontSize: 13, color: '#0F172A' }}>{a.service}</div>
                <div style={{ fontSize: 12, color: '#64748B', marginTop: 2 }}>{a.health_centre}</div>
                <div style={{ fontSize: 11.5, color: '#94A3B8', marginTop: 2 }}>{a.date} at {a.time}</div>
              </div>
            ))}
          </div>
          <div style={{ padding: '10px 18px', borderTop: '1px solid #F1F5F9' }}>
            <button onClick={() => navigate('/student/appointments')} style={{ width: '100%', background: 'none', border: 'none', color: '#2563EB', fontWeight: 600, fontSize: 12.5, cursor: 'pointer', padding: 0 }}>
              View All Appointments →
            </button>
          </div>
        </Card>

        {/* Recent records */}
        <Card>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid #F1F5F9', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 700, fontSize: 13, color: '#0F172A' }}>Recent Health Records</span>
            <button onClick={() => navigate('/student/records')} style={{ background: 'none', border: 'none', color: '#2563EB', fontSize: 12, fontWeight: 600, cursor: 'pointer', padding: 0 }}>View All →</button>
          </div>
          <div style={{ padding: '10px 18px' }}>
            {data.records.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '18px 0', color: '#94A3B8', fontSize: 12.5 }}>No health records yet</div>
            ) : data.records.slice(0, 3).map((r, i) => (
              <div key={r.id} style={{ padding: '10px 12px', borderRadius: 8, border: '1px solid #E2E8F0', background: '#F8FAFC', marginBottom: i < 2 ? 8 : 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
                  <span style={{ fontWeight: 700, fontSize: 13, color: '#0F172A' }}>{r.service}</span>
                  <span style={{ fontSize: 11.5, color: '#94A3B8' }}>{r.date}</span>
                </div>
                <div style={{ fontSize: 12, color: '#64748B' }}>{r.doctor}</div>
                <div style={{ fontSize: 11.5, color: '#374151', marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.diagnosis}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Quick actions */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }}>Quick Actions</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12 }}>
          {QUICK.map(q => (
            <button
              key={q.path} onClick={() => navigate(q.path)}
              style={{
                background: '#fff', border: '1px solid #E2E8F0', borderRadius: 10, padding: '16px 12px',
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, cursor: 'pointer',
                transition: 'all .15s',
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = q.color; e.currentTarget.style.boxShadow = `0 4px 12px rgba(0,0,0,.06)`; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = '#E2E8F0'; e.currentTarget.style.boxShadow = 'none'; }}
            >
              <div style={{ width: 38, height: 38, borderRadius: 9, background: q.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, color: q.color, fontWeight: 900 }}>
                {q.icon}
              </div>
              <span style={{ fontSize: 12.5, fontWeight: 600, color: '#374151', textAlign: 'center', lineHeight: 1.3 }}>{q.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Wellness tip */}
      <div style={{ padding: '14px 20px', background: 'linear-gradient(135deg,#EFF6FF,#F0FDF4)', border: '1px solid #BFDBFE', borderRadius: 10, display: 'flex', gap: 14, alignItems: 'center' }}>
        <div style={{ width: 38, height: 38, borderRadius: 9, background: '#2563EB', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>🌱</div>
        <div>
          <div style={{ fontSize: 12.5, fontWeight: 700, color: '#0F172A', marginBottom: 2 }}>Wellness Tip of the Day</div>
          <div style={{ fontSize: 12.5, color: '#374151', lineHeight: 1.5 }}>
            Take a 5-minute break every hour to stretch. Regular movement boosts focus and reduces exam stress.
            <button onClick={() => navigate('/student/counselling')} style={{ background: 'none', border: 'none', color: '#2563EB', fontWeight: 600, cursor: 'pointer', fontSize: 12.5, marginLeft: 6 }}>
              Explore wellbeing →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
