import { NavLink, Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { useState, useEffect } from 'react';

const NAV = [
  {
    section: 'My Health',
    items: [
      { label: 'Get Help Now',         path: '/student/get-help',      icon: '↗', urgent: true },
      { label: 'My Dashboard',         path: '/student/dashboard',     icon: '▣' },
      { label: 'My Cases',             path: '/student/cases',         icon: '◈' },
      { label: 'Appointments',         path: '/student/appointments',  icon: '◷' },
    ],
  },
  {
    section: 'Records',
    items: [
      { label: 'Health Records',       path: '/student/records',       icon: '≡' },
      { label: 'Certificates',         path: '/student/certificates',  icon: '◻' },
    ],
  },
  {
    section: 'Wellbeing',
    items: [
      { label: 'Counselling',          path: '/student/counselling',   icon: '◎' },
      { label: 'Raise Concern',        path: '/student/raise-concern', icon: '!' },
    ],
  },
];

const BREADCRUMB_MAP = {
  '/student/get-help':      'Get Help',
  '/student/dashboard':     'My Dashboard',
  '/student/cases':         'My Cases',
  '/student/book':          'Book Appointment',
  '/student/appointments':  'My Appointments',
  '/student/records':       'Health Records',
  '/student/certificates':  'Certificates',
  '/student/counselling':   'Counselling & Wellbeing',
  '/student/raise-concern': 'Raise Concern',
};

function getInitials(name = '') {
  return name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
}

export default function StudentLayout() {
  const { user, logout, apiFetch } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const breadcrumb = BREADCRUMB_MAP[location.pathname] || 'Student Portal';
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    apiFetch('/notifications/me').then(ns => setUnreadCount(ns.filter(n => !n.is_read).length)).catch(() => {});
  }, [location.pathname, apiFetch]);

  const S = {
    sidebar: {
      width: 240, flexShrink: 0, background: '#0F172A',
      display: 'flex', flexDirection: 'column', overflowY: 'auto',
    },
    logoBox: {
      padding: '22px 20px 18px', borderBottom: '1px solid rgba(255,255,255,.06)',
    },
    userBox: {
      padding: '14px 20px', borderBottom: '1px solid rgba(255,255,255,.06)',
      display: 'flex', alignItems: 'center', gap: 10,
    },
    avatar: {
      width: 36, height: 36, borderRadius: '50%', background: '#1D4ED8',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontWeight: 700, fontSize: 13, color: '#fff', flexShrink: 0,
    },
    sectionLabel: {
      padding: '10px 20px 4px', fontSize: 10, fontWeight: 700,
      color: '#334155', textTransform: 'uppercase', letterSpacing: '0.08em',
    },
  };

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden', background: '#F8FAFC', fontFamily: 'system-ui,-apple-system,sans-serif' }}>
      {/* Sidebar */}
      <aside style={S.sidebar}>
        {/* Logo */}
        <div style={S.logoBox}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
            <div style={{ width: 38, height: 38, borderRadius: 10, background: '#2563EB', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 900, fontSize: 18, color: '#fff', flexShrink: 0 }}>+</div>
            <div>
              <div style={{ fontWeight: 800, fontSize: 14.5, color: '#F8FAFC', letterSpacing: '-0.03em' }}>SMCM</div>
              <div style={{ fontSize: 10.5, color: '#475569', marginTop: 1 }}>Student Portal · v3.0</div>
            </div>
          </div>
        </div>

        {/* User */}
        {user && (
          <div style={S.userBox}>
            <div style={S.avatar}>{getInitials(user.name)}</div>
            <div style={{ minWidth: 0, flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 12.5, color: '#F1F5F9', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user.name}</div>
              <div style={{ fontSize: 11, color: '#475569', marginTop: 1 }}>
                {user.student_id || 'Student'} · {user.program || ''}
              </div>
            </div>
          </div>
        )}

        {/* Nav */}
        <nav style={{ flex: 1, padding: '8px 0' }}>
          {NAV.map(group => (
            <div key={group.section} style={{ marginBottom: 4 }}>
              <div style={S.sectionLabel}>{group.section}</div>
              {group.items.map(item => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  style={({ isActive }) => ({
                    display: 'flex', alignItems: 'center', gap: 10,
                    padding: '7.5px 20px', fontSize: 13, fontWeight: isActive ? 600 : 400,
                    color: item.urgent ? (isActive ? '#fff' : '#FCA5A5') : (isActive ? '#fff' : '#64748B'),
                    background: item.urgent ? (isActive ? 'rgba(220,38,38,0.25)' : 'rgba(220,38,38,0.08)') : (isActive ? 'rgba(37,99,235,0.18)' : 'transparent'),
                    borderLeft: `3px solid ${item.urgent ? (isActive ? '#DC2626' : 'rgba(220,38,38,0.3)') : (isActive ? '#2563EB' : 'transparent')}`,
                    textDecoration: 'none', transition: 'all .12s',
                  })}
                >
                  <span style={{ fontSize: 14, width: 18, textAlign: 'center', flexShrink: 0, opacity: 0.85 }}>{item.icon}</span>
                  <span style={{ flex: 1 }}>{item.label}</span>
                  {item.urgent && (
                    <span style={{ fontSize: 9, fontWeight: 800, background: '#DC2626', color: '#fff', padding: '1px 5px', borderRadius: 4, letterSpacing: '0.05em' }}>SOS</span>
                  )}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>

        {/* Health tip */}
        <div style={{ margin: '0 14px 14px', padding: '12px 14px', background: 'rgba(37,99,235,0.12)', border: '1px solid rgba(37,99,235,0.2)', borderRadius: 10 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#93C5FD', marginBottom: 4 }}>Health Reminder</div>
          <div style={{ fontSize: 11, color: '#64748B', lineHeight: 1.5 }}>Stay hydrated and maintain regular health check-ups.</div>
        </div>

        {/* Logout */}
        <div style={{ padding: '0 20px 16px' }}>
          <button
            onClick={() => { logout(); navigate('/login'); }}
            style={{
              width: '100%', padding: '8px 14px', background: 'rgba(255,255,255,.05)',
              color: '#64748B', border: '1px solid rgba(255,255,255,.07)', borderRadius: 8,
              cursor: 'pointer', fontSize: 12.5, fontWeight: 600,
              display: 'flex', alignItems: 'center', gap: 8, transition: 'all .15s',
            }}
          >
            <span>←</span> Sign Out
          </button>
        </div>
      </aside>

      {/* Main */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Topbar */}
        <header style={{
          height: 54, background: '#fff', borderBottom: '1px solid #E2E8F0',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0 28px', flexShrink: 0,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
            <span style={{ color: '#94A3B8', fontSize: 12 }}>Student</span>
            <span style={{ color: '#CBD5E1', fontSize: 14 }}>›</span>
            <span style={{ fontWeight: 700, color: '#0F172A', fontSize: 13.5 }}>{breadcrumb}</span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {/* Notification bell */}
            <button
              style={{ position: 'relative', background: 'none', border: '1px solid #E2E8F0', borderRadius: 8, cursor: 'pointer', padding: '6px 10px', color: '#64748B', fontSize: 14 }}
              onClick={() => navigate('/student/dashboard')}
              title="Notifications"
            >
              ◷
              {unreadCount > 0 && (
                <span style={{ position: 'absolute', top: 4, right: 4, width: 7, height: 7, borderRadius: '50%', background: '#EF4444', border: '1.5px solid #fff' }} />
              )}
            </button>

            {user && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 10px', background: '#F8FAFC', border: '1px solid #E2E8F0', borderRadius: 8 }}>
                <div style={{ width: 26, height: 26, borderRadius: '50%', background: '#2563EB', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 10.5, color: '#fff' }}>
                  {getInitials(user.name)}
                </div>
                <span style={{ fontSize: 12.5, fontWeight: 600, color: '#374151' }}>{user.name.split(' ')[0]}</span>
              </div>
            )}
          </div>
        </header>

        {/* Page content */}
        <main style={{ flex: 1, overflowY: 'auto' }}>
          <Outlet />
        </main>
      </div>

      {/* Floating urgent help button */}
      <button
        onClick={() => navigate('/student/get-help')}
        style={{
          position: 'fixed', bottom: 24, right: 24, background: '#DC2626', color: '#fff',
          border: 'none', borderRadius: 50, padding: '12px 22px', fontWeight: 700, fontSize: 13,
          cursor: 'pointer', zIndex: 1000, boxShadow: '0 4px 16px rgba(220,38,38,0.45)',
          display: 'flex', alignItems: 'center', gap: 8, letterSpacing: '-0.01em',
          transition: 'transform .15s, box-shadow .15s',
        }}
      >
        <span style={{ fontSize: 15, fontWeight: 900 }}>+</span> Urgent Help
      </button>
    </div>
  );
}
