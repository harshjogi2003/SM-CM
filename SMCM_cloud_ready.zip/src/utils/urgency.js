export const URGENCY_COLORS = { 0: '#22C55E', 1: '#22C55E', 2: '#F59E0B', 3: '#EF4444', 4: '#DC2626' };
export const URGENCY_LABELS = { 0: 'Routine', 1: 'Routine', 2: 'Today', 3: 'Urgent', 4: 'Crisis' };
export const URGENCY_BG    = { 0: '#F0FDF4', 1: '#F0FDF4', 2: '#FFFBEB', 3: '#FEF2F2', 4: '#7F1D1D' };
export const URGENCY_TEXT  = { 0: '#166534', 1: '#166534', 2: '#92400E', 3: '#991B1B', 4: '#FEF2F2' };
export const urgencyColor = u => URGENCY_COLORS[u] ?? URGENCY_COLORS[1];
export const urgencyLabel = u => URGENCY_LABELS[u] ?? 'Routine';
export const urgencyBg    = u => URGENCY_BG[u]    ?? URGENCY_BG[1];
export const urgencyText  = u => URGENCY_TEXT[u]  ?? URGENCY_TEXT[1];
